const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const moment = require("moment");

const file = require("../services/file");
const tradeTypes = require("../config/tradeTypes");

const { Trade } = require("../models/Trade");
const { Dates } = require("../models/Dates");
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"TRADE","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const trades = await Trade.find({ deleteAt: null });
    for (let trade of trades) {
      let festivalYear;
      if (trade.fyID) {
        festivalYear = await Dates.findById(trade.fyID, "_id festival year");
      }
      if (festivalYear) {
        trade.viewLink = {
          url: `/admin/dates/form?id=${festivalYear.id}`,
          title: `${festivalYear.festival.name} - ${festivalYear.year}`,
        };
      } else {
        trade.viewLink = {};
      }
    }
    return res.view("trades/list", { operationResult, trades });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if(id && !accessManagement.check(req.admin,"TRADE","EDIT")) return res.redirect("/admin/trades?code=-10")
    if(!id && !accessManagement.check(req.admin,"TRADE","ADD")) return res.redirect("/admin/trades?code=-10")
    const trade = await Trade.findByIdAndDeleteAt({ id });
    const festivalYears = await Dates.find({}, "_id festival year");
    if (trade && trade.imgs) {
      for (let img of trade.imgs) {
        img.paramName = "oldFiles_" + img.path.split("/").pop().split(".")[0];
      }
    }

    return res.view("trades/form", {
      operationResult: { code },
      trade,
      festivalYears,
      tradeTypes,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let {
      title,
      fyID,
      type,
      price,
      desc,
      eDate,
      private,
      cName,
      cPhone,
      cEmail,
      active,
    } = req.body;
    if(!accessManagement.check(req.admin,"TRADE","ADD")) return res.redirect("/admin/trades?code=-10")

    active = Boolean(active === "on");
    private = Boolean(private === "on");
    let contact = { name: cName, phone: cPhone, email: cEmail };

    let tradeFromDB = await Trade.create({
      title,
      fyID,
      type,
      price,
      desc,
      eDate:(eDate)?eDate+"z":eDate,
      private,
      contact,
      active,
    });

    let imgs = [];
    if (req.files) {
      file.createDir("tradeImages", { subFolder: tradeFromDB.id });
      imgs = await file.save(
        req.files.filter((file) => file.fieldname === "imgs"),
        "tradeImages",
        { subFolder: tradeFromDB.id }
      );
    }

    tradeFromDB.imgs = imgs;
    tradeFromDB.markModified("imgs");
    await tradeFromDB.save();

    return res.redirect("/admin/trades/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    let {
      id,
      title,
      fyID,
      type,
      price,
      desc,
      eDate,
      private,
      cName,
      cPhone,
      cEmail,
      active,
    } = req.body;
    if(!accessManagement.check(req.admin,"TRADE","EDIT")) return res.redirect("/admin/trades?code=-10")
    if (!id) {
      return res.redirect("/admin/trades/form/?code=-1");
    }

    active = Boolean(active === "on");
    private = Boolean(private === "on");

    let trade = await Trade.findById(id);
    if (!trade) {
      return res.redirect("/admin/trades/form/?code=-2");
    }

    let imgsFromDB = trade.imgs;
    let imgsToDB = [];

    for (let i in imgsFromDB) {
      const imgInDB = imgsFromDB[i];
      const paramName = "oldFiles_" + imgInDB.path.split("/").pop().split(".")[0];
      const imgInReq = req.files.find((file) => file.fieldname === paramName);
      if (imgInReq) {
        // keep this image
        imgsToDB.push(imgInDB);
      } else {
        // delete this image
        await file.delete(imgInDB.path, "tradeImages");
      }
    }

    if (req.files) {
      file.createDir("tradeImages", { subFolder: trade.id });
      let newImgs = await file.save(
        req.files.filter((file) => file.fieldname === "imgs"),
        "tradeImages",
        { subFolder: trade.id }
      );
      imgsToDB = imgsToDB.concat(newImgs);
    }

    trade.imgs = imgsToDB;
    trade.markModified("imgs");
    trade.title = title;
    trade.fyID = fyID;
    trade.type = type;
    trade.price = price;
    trade.desc = desc;
    trade.eDate = (eDate)?eDate+"z":eDate
    trade.private = private;
    trade.contact = { name: cName, phone: cPhone, email: cEmail };

    trade.active = active;
    await trade.save();

    return res.redirect("/admin/trades/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/trades/?code=-1");
    }
    if(!accessManagement.check(req.admin,"TRADE","DELETE")) return res.redirect("/admin/trades?code=-10")
    await Trade.deleteOne({ _id: id });
    return res.redirect("/admin/trades/?code=205");
    // await Trade.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    // return res.redirect(
    //   "/admin/trades/?code=205&undo=" + encodeURIComponent("/admin/trades/undoDelete?id=" + id)
    // );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/trades/?code=-1");
    }

    await Trade.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/trades/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
