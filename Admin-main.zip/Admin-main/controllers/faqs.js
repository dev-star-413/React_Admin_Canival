const express = require("express");
const { Dynamics } = require("../models/Dynamics");
const router = express.Router();

const { Faq } = require("../models/Faq");
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"FAQ","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const faqs = await Faq.find({ deleteAt: null });
    return res.view("faqs/list", { operationResult, faqs });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code } = req.query;
    if(!id && !accessManagement.check(req.admin,"FAQ","ADD")) return res.redirect("/admin/faqs?code=-10")
    if(id &&!accessManagement.check(req.admin,"FAQ","EDIT")) return res.redirect("/admin/faqs?code=-10")

    const faq = await Faq.findByIdAndDeleteAt({ id });
    let categories = await Dynamics.findOne({}, "faqCategories")
    categories = categories.faqCategories
    return res.view("faqs/form", { operationResult: { code }, faq, categories });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", async function (req, res, next) {
  try {
    let { q, a, cat } = req.body;
    if(!accessManagement.check(req.admin,"FAQ","ADD")) return res.redirect("/admin/faqs?code=-10")
    if (!q) {
      return res.redirect("/admin/faqs/form/?code=-1");
    }

    await Faq.create({ q, a, cat });
    return res.redirect("/admin/faqs/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", async function (req, res, next) {
  try {
    let { id, q, a, cat } = req.body;
    if(!accessManagement.check(req.admin,"FAQ","EDIT")) return res.redirect("/admin/faqs?code=-10")
    if (!id || !q) {
      return res.redirect("/admin/faqs/form/?code=-1");
    }

    let faq = await Faq.findById(id);
    if (!faq) {
      return res.redirect("/admin/faqs/form/?code=-2");
    }
    faq.q = q;
    faq.a = a;
    faq.cat = cat;
    await faq.save();

    return res.redirect("/admin/faqs/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"FAQ","DELETE")) return res.redirect("/admin/faqs?code=-10")
    if (!id) {
      return res.redirect("/admin/faqs/?code=-1");
    }

    await Faq.deleteOne({ _id: id });
    return res.redirect("/admin/faqs/?code=205");
    // await Faq.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    // return res.redirect(
    //   "/admin/faqs/?code=205&undo=" + encodeURIComponent("/admin/faqs/undoDelete?id=" + id)
    // );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/faqs/?code=-1");
    }

    await Faq.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/faqs/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
