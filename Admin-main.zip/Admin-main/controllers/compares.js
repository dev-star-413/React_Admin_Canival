const express = require("express");
const router = express.Router();
const { Compares } = require("../models/Compares");
const { BandDate } = require("../models/BandDate");
const { Dates } = require("../models/Dates");
const { Section } = require("../models/Section");
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    var all = await Compares.find();
    if(!accessManagement.check(req.admin,"COMPARE","INDEX")) return res.redirect("/admin?code=-10")
    var compares = [];
    for (let co of all) {
      co = co.toObject();
      let bandA = await BandDate.findById(co.bandDateIdA, "name");
      let bandB = await BandDate.findById(co.bandDateIdB, "name");
      let bandNameA = bandA && bandA.name;
      let bandNameB = bandB && bandB.name;
      let sectionNameA = "";
      let sectionNameB = "";
      if (co.sectionIdA && co.sectionIdB) {
        let secA = await Section.findById(co.sectionIdA, "name");
        let secB = await Section.findById(co.sectionIdB, "name");
        sectionNameA = secA && secA.name;
        sectionNameB = secB && secB.name;
      }
      compares.push({ ...co, bandNameA, bandNameB, sectionNameA, sectionNameB });
    }
    return res.view("compares/list", { compares });
  } catch (error) {
    return next(error, req, res, next);
  }
});
router.get("/form", async function (req, res, next) {
  try {
    var { id } = req.query;
    var compares = {};
    if(id && !accessManagement.check(req.admin,"COMPARE","EDIT")) return res.redirect("/admin/compares?code=-10")
    if(!id && !accessManagement.check(req.admin,"COMPARE","ADD")) return res.redirect("/admin/compares?code=-10")
    if (id) {
      compares = await Compares.findById(id);
      compares = compares.toObject();
    }
    var dates = await Dates.find({}, "year slug festival");

    var years = new Set();
    for (let d of dates) {
      years.add(d.year);
    }
    years = Array.from(years);
    var bands = await BandDate.find({}, "slug name  year dateId isJouvertService isCustomeService");
    var sections = await Section.find({}, "bdId name");

    if (compares && compares._id) {
      let yearA;
      let yearB;
      for (let d of dates) {
        if (d._id == compares.dateIdA) yearA = d.year;
        if (d._id == compares.dateIdB) yearB = d.year;
      }
      compares = { ...compares, yearA, yearB };
    }
    return res.view("compares/form", { years, dates, bands, sections, compares });
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/create", async function (req, res, next) {
  try {
    var params = req.body;
    var { bandDateIdA, bandDateIdB, sectionIdB, sectionIdA, inLanding, inCarnivalPage, dateIdA, dateIdB } = params;
    if (!bandDateIdB || bandDateIdA == "0") return res.redirect("/admin/compares/form");
    inLanding = inLanding ? true : false;
    inCarnivalPage = inCarnivalPage ? true : false;
    var data = {
      dateIdA,
      dateIdB,
      bandDateIdA,
      bandDateIdB,
      sectionIdA,
      sectionIdB,
      inLanding,
      inCarnivalPage,
    };
    if(!accessManagement.check(req.admin,"COMPARE","ADD")) return res.redirect("/admin/compares?code=-10")
    await Compares.create(data);
    return res.redirect("/admin/compares?code=201");
  } catch (error) {
    return next(error, req, res, next);
  }
});
router.post("/update", async function (req, res, next) {
  try {
    var params = req.body;
    var { id } = req.query;
    if(!accessManagement.check(req.admin,"COMPARE","EDIT")) return res.redirect("/admin/compares?code=-10")
    var { bandDateIdA, bandDateIdB, sectionIdB, sectionIdA, dateIdA, dateIdB } = params;
    if (!id) return res.redirect("/admin/compares");
    if (!bandDateIdB || bandDateIdA == "0") return res.redirect(`/admin/compares/form?id=${id}`);
    var inLanding = params.inLanding ? true : false;
    var inCarnivalPage = params.inCarnivalPage ? true : false;
    var compare = await Compares.findById(id);
    if (!compare) return res.redirect("/admin/compares");
    compare.bandDateIdA = bandDateIdA;
    compare.bandDateIdB = bandDateIdB;
    compare.sectionIdB = sectionIdB;
    compare.sectionIdA = sectionIdA;
    compare.dateIdA = dateIdA;
    compare.dateIdB = dateIdB;
    compare.inLanding = inLanding;
    compare.inCarnivalPage = inCarnivalPage;
    await compare.save();
    return res.redirect("/admin/compares?code=201");
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/delete", async function (req, res, next) {
  try {
    var { id } = req.body;
    if(!accessManagement.check(req.admin,"COMPARE","DELETE")) return res.redirect("/admin/compares?code=-10")
    if (!id) return res.redirect("/admin/compares");
    await Compares.deleteOne({ _id: id });
    return res.redirect("/admin/compares?code=201");
  } catch (error) {
    return next(error, req, res, next);
  }
});
module.exports = router;
