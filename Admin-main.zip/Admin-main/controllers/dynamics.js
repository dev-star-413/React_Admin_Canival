const express = require("express");
const {Dynamics} = require("../models/Dynamics");
const {Festival} = require("../models/Festival");
const {City} = require("../models/City");
const {BandDate} = require("../models/BandDate");
const {BandTemp} = require("../models/BandTemp");
const {Line} = require("../models/Line");
const {Faq} = require("../models/Faq");
const {Section} = require("../models/Section");
const {Award} = require("../models/Award");
const router = express.Router();
const accessManagement = require("../services/accessManagement")
router.get("/", async function (req, res, next) {
    try {
        const {code} = req.query;
        if (!accessManagement.check(req.admin, "DYNAMIC", "INDEX")) return res.redirect("/admin?code=-10")
        let operationResult = {code};
        if (!accessManagement.check(req.admin, "DESIGNER", "DELETE")) return res.redirect("/admin/designers?code=-10")
        return res.view("dynamics/form.ejs", {dynamics: await Dynamics.findOne(), operationResult})
    } catch (error) {
        return next(error, req, res, next);
    }
})

router.post("/update", async function (req, res, next) {
    try {
        let {preVal, newVal, key} = req.body;
        const dynamics = await Dynamics.findOne({}, {});
        var subject = dynamics[key];
        if (!Array.isArray(subject)) subject=[subject];
        subject = subject.map((value) => {
            if (value === preVal) return newVal
            else return value
        })
        dynamics[key] = subject;
        await Dynamics.updateMany({}, dynamics);

        if (key === 'festivalTypes' && preVal) {
            await Festival.updateMany({type: preVal}, {type: newVal});

        } else if (key === 'catTags' && preVal) {
            let awards = await Award.find({"cats.tag": preVal});
            for (let award of awards) {
                award.cats = award.cats.map((cat) => {
                    cat.tag = cat.tag.map((tag) => {
                        if (tag === preVal) return newVal;
                        else return tag;
                    })
                    return cat
                })
                await Award.updateOne({_id: award.id}, award);
            }

        } else if (key === 'regions' && preVal) {
            await City.updateMany({region: preVal}, {region: newVal});

        } else if (key === 'themes' && preVal) {
            await BandDate.updateMany({themeType: preVal}, {themeType: newVal});
            await BandTemp.updateMany({themeType: preVal}, {themeType: newVal});

        } else if (key === 'revellers' && preVal) {
            await BandTemp.updateMany({reveller: preVal}, {reveller: newVal});

        } else if (key === 'services' && preVal) {
            await BandDate.updateMany({services: {$all: [preVal]}}, {$set: {'services.$': newVal}});
            await BandTemp.updateMany({services: {$all: [preVal]}}, {$set: {'services.$': newVal}});

        } else if (key === 'jouvertServices' && preVal) {
            await BandDate.updateMany({jouvertServices: {$all: [preVal]}}, {$set: {'jouvertServices.$': newVal}});

        } else if (key === 'childrenServices' && preVal) {
            await BandDate.updateMany({childrenServices: {$all: [preVal]}}, {$set: {'childrenServices.$': newVal}});

        } else if (key === 'styles' && preVal) {
            await Line.updateMany({styles: {$all: [preVal]}}, {$set: {'styles.$': newVal}});

        } else if (key === 'faqCategories' && preVal) {
            await Faq.updateMany({cat: preVal}, {$set: {cat: newVal}});

        } else if (key === 'colors' && preVal) {
            await Section.updateMany({colors: {$all: [preVal]}}, {$set: {'colors.$': newVal}});

        } else if (key === 'premiums' && preVal ) {
            await Section.updateMany({premiums: {$all: [preVal]}}, {$set: {'premiums.$': newVal}});

        }
        return res.json({code: 0, msg: 'success', data: {}});
    } catch (error) {
        console.error(error)
        return res.json({code:2,msg:"something is wrong. please try again."})
    }
})

router.post("/add", async function (req, res, next) {
    try {
        let {value, key} = req.body;
        const dynamics = await Dynamics.findOne({}, {})
        var subject = dynamics[key];
        if(Array.isArray(subject)) {
            var exist=subject.find((v)=>v==value)
            if(!exist) subject.push(value)
        }else  subject = [value];
        dynamics[key] = subject;
        await Dynamics.update({}, dynamics)
        return res.json({code: 0, msg: 'success', data: {}});
    } catch (error) {
        return next(error, req, res, next);
    }
})

router.post("/delete", async function (req, res, next) {
    try {
        let {value, key} = req.body;
        const dynamics = await Dynamics.findOne({}, {})
        var subject = dynamics[key];
        Array.isArray(subject) ? subject = subject.filter((item) => {
            if (item !== value) return item
        }) : {};
        dynamics[key] = subject;
        await Dynamics.update({}, dynamics);

        if (key === 'festivalTypes') {
            await Festival.updateMany({type: value}, {type: null});

        } else if (key === 'catTags') {
            let awards = await Award.find({"cats.tag": value});
            for (let award of awards) {
                award.cats = award.cats.map((cat) => {
                    cat.tag = cat.tag.filter((tag) => {
                        if (tag !== value) return tag;
                        else {}
                    })
                    return cat
                })
                await Award.updateOne({_id: award.id}, award);
            }

        } else if (key === 'regions') {
            await City.updateMany({region: value}, {region: null});

        } else if (key === 'themes') {
            await BandDate.updateMany({themeType: value}, {themeType: null});
            await BandTemp.updateMany({themeType: value}, {themeType: null});

        } else if (key === 'revellers') {
            await BandTemp.updateMany({reveller: value}, {reveller: null});

        } else if (key === 'services') {
            await BandDate.updateMany({services: {$all: [value]}}, {$pull: {'services': value}});
            console.log(await BandTemp.find())
            await BandTemp.updateMany({services: {$all: [value]}}, {$pull: {'services': value}});
            console.log(await BandTemp.find())

        } else if (key === 'jouvertServices') {
            await BandDate.updateMany({jouvertServices: {$all: [value]}}, {$pull: {'jouvertServices': value}});

        } else if (key === 'childrenServices') {
            await BandDate.updateMany({childrenServices: {$all: [value]}}, {$pull: {'childrenServices': value}});

        } else if (key === 'styles') {
            await Line.updateMany({styles: {$all: [value]}}, {$pull: {'styles': value}});

        } else if (key === 'faqCategories') {
            await Faq.updateMany({cat: value}, {$set: {cat: null}});

        } else if (key === 'colors') {
            await Section.updateMany({colors: {$all: [value]}}, {$pull: {'colors': value}});

        } else if (key === 'premiums') {
            await Section.updateMany({premiums: {$all: [value]}}, {$pull: {'premiums': value}});

        } else {
            console.log('[ERROR: key not found]');
        }

        return res.json({code: 0, msg: 'success', data: {}});
    } catch (error) {
        return next(error, req, res, next);
    }
})

router.post("/update/details", async function (req, res, next) {
    try {
        let {bandDateDetails} = req.body;
        await Dynamics.updateOne({}, {bandDateDetails});
        return res.redirect('/admin/dynamics/?code=200')
    } catch (error) {
        return next(error, req, res, next)
    }
})

module.exports = router
