const express = require("express");
const router = express.Router();
const multer = require("multer");
const { Line } = require("../models/Line");
const { Section } = require("../models/Section");
const { Dynamics } = require("../models/Dynamics");
const { CurrencyRate } = require("../models/CurrencyRate");
const file = require("../services/file");
const { BandDate } = require("../models/BandDate");
const upload = multer();
const imagesPrefix = "lineImages";
const {
  lineTypes,
  uploads
} = require("../config")();

router.get("/form", async function (req, res, next) {
  try {
    const { id, sid } = req.query;
    if (!sid) {
      return res.view("index", { operationResult: { code: -1, msg: `No section with id ${sid} found` } })
    }
    let line;
    if (id) {
      line = await Line.findById(id);
      if (!line) return res.view("index", { operationResult: { code: -1, msg: `No line with id ${id} found` } })
      for (let i in line.gallery) {
        line.gallery[i] = line.gallery[i].toObject()
        line.gallery[i].src = uploads.lineImages + "/" + line.gallery[i].path;
      }
    }

    const section = await Section.findById(sid);
    if (!section) {
      return res.view("index", { operationResult: { code: -1, msg: `No section with id ${sid} found` } })
    }
    const band=await BandDate.findById(section.bdId,'name')
    const dynamics = await Dynamics.findOne();
    var currencies=await CurrencyRate.find({},"from")

    return res.view("bandDates/lines", { line, section, lineTypes,band, styles: dynamics.styles,currencies });

  } catch (err) {
    return next(err, req, res, next);
  }
})

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let {
      sId, type, desc, styles, link, galleryLength,
    } = req.body;
    const section = await Section.findById(sId);
    if (!section) {
      return res.view("index", { operationResult: { code: -1, msg: `No section with id ${sid} found` } })
    }
    styles = Array.isArray(styles) ? styles : [styles];
    const lineCreateObj = { sId, type, desc, styles, link };

    lineCreateObj.gallery = [];
    for (let i = 1; i <= galleryLength; i++) {
      const thisFile = req.files.find((file) => file.fieldname === ("gallery_img_" + i));
      if (!req.body["gallery_text_" + i]) {
        return res.view("index", { operationResult: { code: -1, msg: `For each gallery you should enter a title` } })
      }
      if (req.body["gallery_text_" + i] && thisFile) {
        await saveFilePushToGallery(req, i, lineCreateObj.gallery)
      }else{
        lineCreateObj.gallery.push({
          text: req.body["gallery_text_" + i],
          price: (req.body["gallery_price_" + i])?Number(req.body["gallery_price_" + i]):'',
          localPrice: req.body["gallery_localPrice_" + i],
          isAddOn: Boolean(req.body["gallery_isAddOn_" + i]),
          includes: req.body["gallery_includes_" + i]
        })
      }
    }
    await Line.create(lineCreateObj)

    return res.redirect(`/admin/banddates/form?id=${section.bdId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
})

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    let {
      id, sId, type, desc, styles, link, galleryLength
    } = req.body;
    const section = await Section.findById(sId, "_id name");
    if (!section) {
      return res.view("index", { operationResult: { code: -1, msg: `No section with id ${sid} found` } })
    }

    const line = await Line.findById(id);
    if (!line) {
      return res.view("index", { operationResult: { code: -1, msg: `No line with id ${id} found` } })
    }
    line.type = type;
    line.desc = desc;
    line.styles = Array.isArray(styles) ? styles : [styles];
    line.link = link;

    let newGallery = [];
    for (let i = 0; i <= galleryLength; i++) {
      if(!req.body["gallery_text_" + i])continue;

      const thisFile = req.files.find((file) => file.fieldname === ("gallery_img_" + i));
      // if update image of gallery
      if(thisFile){
        if (req.body["gallery_id_" + i]) {
          let oldGalleryRecord = line.gallery.find(item => item._id.toString() === req.body["gallery_id_" + i]).toObject();
          if (oldGalleryRecord && oldGalleryRecord.path) {
            await file.delete(oldGalleryRecord.path, imagesPrefix);
          }
        }
        await saveFilePushToGallery(req, i, newGallery)
      }
      else{
        var obj={}
        if (req.body["gallery_id_" + i]) {
          let oldGalleryRecord = line.gallery.find(item => item._id.toString() === req.body["gallery_id_" + i]).toObject();
          obj={...oldGalleryRecord}
        }
        

        newGallery.push({
          ...obj,
          text: req.body["gallery_text_" + i],
          price: (req.body["gallery_price_" + i])? Number(req.body["gallery_price_" + i]):'',
          localPrice: req.body["gallery_localPrice_" + i],
          isAddOn: Boolean(req.body["gallery_isAddOn_" + i]),
          includes: req.body["gallery_includes_" + i]
        })
      }
    }
    lineGalleryLoop: for (let i = 0; i < line.gallery.length; i++) {
      for (let j = 0; j < galleryLength; j++) {
        if (req.body["gallery_id_" + j] && req.body["gallery_id_" + j] === line.gallery[i]._id.toString()) {
          continue lineGalleryLoop;
        }
      }
      if (line.gallery[i].path) {
        await file.delete(line.gallery[i].path, imagesPrefix);
      }
    }
    line.gallery = newGallery
    line.markModified("gallery")

    await line.save();

    return res.redirect(`/admin/lines/form?id=${id}&sid=${sId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
})

router.get("/delete", async function (req, res, next) {
  try {
    const { id, bdId } = req.query;
    const line = await Line.findById(id);
    if (line && line.gallery && line.gallery[0]) {
      for (let gallery of line.gallery) {
        if (gallery.path) {
          await file.delete(gallery.path, imagesPrefix);
        }
      }
    }
    await Line.deleteOne({ _id: id });
    return res.json({code:0,msg:"success",data:{}})  
  } catch (error) {
    return next(error, req, res, next);
  }
})

async function saveFilePushToGallery(req, i, gallery) {
  let imgs;
  if (req.files) {
    imgs = await file.save(
      req.files.filter((file) => file.fieldname === ("gallery_img_" + i)),
      imagesPrefix
    );
  } else {
    imgs = [];
  }
  gallery.push({
    ...imgs[0],
    text: req.body["gallery_text_" + i],
    price: Number(req.body["gallery_price_" + i]),
    localPrice: req.body["gallery_localPrice_" + i],
    isAddOn: Boolean(req.body["gallery_isAddOn_" + i]),
    includes: req.body["gallery_includes_" + i]
  })
}

module.exports = router;
