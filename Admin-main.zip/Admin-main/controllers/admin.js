const express = require("express");
const { Role } = require("../models/Role");
const router = express.Router();

const { Admin } = require("../models/Admin");
const { hashPassword } = require("../services/auth");
const accessManagement = require("../services/accessManagement");
router.get("/", async function (req, res, next) {
  try {
    // check access admin
    if(! accessManagement.check(req.admin,"ADMIN","INDEX")) return res.redirect("/admin?code=-10")
    const { code } = req.query;
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    var admins = await Admin.find({ deleteAt: null }).lean();
    for(var i in admins){
      let roleID=admins[i].role
      if(roleID) {
        let role=await Role.findById( roleID)
        admins[i].role=role
      }  
    }
    return res.view("admins/list", { operationResult, admins });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code } = req.query;
    if(id && !accessManagement.check(req.admin,"ADMIN","EDIT"))return res.redirect("/admin/admins?code=-10")
    if(! id && ! accessManagement.check(req.admin,"ADMIN","ADD")) return res.redirect("/admin/admins?code=-10")
    const user = await Admin.findById(id);
    let isSuper = false;
    if(req.admin && req.admin.roleObj && req.admin.roleObj.access && req.admin.roleObj.access.includes("SUPER_ADMIN")){
      isSuper = true;
    }

    const roles = await Role.find({ deleteAt: null });
    return res.view("admins/form", { operationResult: { code }, user, roles, isSuper });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", async function (req, res, next) {
  try {
    const { username, password, role, name } = req.body;
    if(! accessManagement.check(req.admin,"ADMIN","ADD")) return res.redirect("/admin/admins/?code=-10")
    if (!username || !password) {
      return res.redirect("/admin/admins/form/?code=-1");
    }
    const hashedPass = hashPassword(password);
    let admin=await Admin.findOne({username})
    if(admin) return res.redirect("/admin/admins/form/?code=-1")
    await Admin.create({ username, password: hashedPass, role, name });
    return res.redirect("/admin/admins/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", async function (req, res, next) {
  try {
    const { id, password, role, name } = req.body;
    if(! accessManagement.check(req.admin,"ADMIN","EDIT")) return res.redirect("/admin/admins?code=-10")
    if (!id) {
      return res.redirect("/admin/admins/form/?code=-1");
    }

    let setObj = { role, name };
    if (password) {
      setObj.password = hashPassword(password);
    }

    await Admin.updateOne({ _id: id }, { $set: setObj });
    return res.redirect("/admin/admins/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(! accessManagement.check(req.admin,"ADMIN","DELETE")) return res.redirect("/admin/admins?code=-10")

    if (!id) {
      return res.redirect("/admin/admins/?code=-1");
    }
    // await Trade.deleteOne({ _id: id });
    await Admin.deleteOne({ _id: id });
    return res.redirect("/admin/admins/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/admins/?code=-1");
    }

    await Admin.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/admins/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
