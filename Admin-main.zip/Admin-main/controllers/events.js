const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const moment = require("moment");
const imagesPrefix = "eventImages";
const file = require("../services/file");
const helpers = require("../services/helpers");
const { City } = require("../models/City");
const { Event } = require("../models/Event");
const { Dates } = require("../models/Dates");
const { uploads } = require("../config")();
const accessManagement=require("../services/accessManagement");
const { Designer } = require("../models/Designer");
const { Band } = require("../models/Band");
const mongoose = require("mongoose");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"EVENT","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const events = await Event.find({ deleteAt: null });
    return res.view("events/list", { operationResult, events });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if(!id && !accessManagement.check(req.admin,"EVENT","ADD")) return res.redirect("/admin/events?code=-10")
    if(id && !accessManagement.check(req.admin,"EVENT","EDIT")) return res.redirect("/admin/events?code=-10")
    const event = await Event.findByIdAndDeleteAt({ id });
    const cities = await City.find({ deleteAt: null }, "_id name region country currency latlng");
    const bands=await Band.find({},'name slug')
    const designers=await Designer.find({},'name slug')
    var watchListTag=[]
    bands.forEach((b)=>watchListTag.push({coll:"Band" ,slug:b.slug,value:b.name,id:b._id}))
    designers.forEach((d)=>watchListTag.push({coll:"Designer",slug:d.slug,value:d.name,id:d._id}))
    if (event && event.imgs) {
      for (let img of event.imgs) {
        img.path = `${uploads.eventImages}/${img.path}`;
      }
    }
    var currencies=new Set()
    cities.map((city)=>{
      if( city.currency) currencies.add(city.currency)
    })
    const festivalYears = await Dates.find({ deleteAt: null }, "_id festival year");
    return res.view("events/form", {
      operationResult: { code },
      event,
      cities,
      festivalYears,
      watchListTag,
      currencies,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let { name, types, cityID, sDate, dId, canceled, eDate,tags,
      vName, vAddress, price, link, pitch, desc, mGenre, frequency, lat, lng , currency } = req.body;
      if(types && !Array.isArray(types)) types=[types]
    if(!accessManagement.check(req.admin,"EVENT","ADD")) return res.redirect("/admin/events?code=-10")
    if (!name) {
      return res.redirect("/admin/events/form/?code=-1");
    }
    const city = await getCity(cityID);

    let imgs = [];
    if (req.files) {
      imgs = await file.save(req.files, imagesPrefix);
    }

    let finalSlug = await helpers.uniqueSlug(Event, name);
    let location = {
      lat, lng
    }
    sDate=(sDate)?sDate+"z":sDate
    eDate=(eDate)?eDate+"z":eDate
    await Event.create(
      {
        name, city, sDate, imgs, dId, canceled: Boolean(canceled == "on"),
        slug: finalSlug, pitch, desc, vName, vAddress, price, link, mGenre, frequency, eDate, location,currency,
        tags:JSON.parse(tags),
        state: {
          by: `${req.admin._id}`,
          name: req.admin.username,
          at: new Date(),
          confirmed: true,
          from: new Date(),
          confirmedBy: `${req.admin._id}`,
        },
        types:types || []
      });
    return res.redirect("/admin/events/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    let { id, name, types, cityID, sDate, dId, canceled,tags,currency,
      vName, vAddress, price, link, pitch, desc, mGenre, frequency, eDate, lat, lng } = req.body;
    if(types && !Array.isArray(types)) types=[types]
    if(!accessManagement.check(req.admin,"EVENT","EDIT")) return res.redirect("/admin/events?code=-10")
    if (!id || !name) {
      return res.redirect("/admin/events/form/?code=-1");
    }
    let event = await Event.findById(id);
    if (!event) {
      return res.redirect("/admin/events/form/?code=-2");
    }
    const eventOldName = event.name;
    let location = {
      lat, lng
    }
    event.location = location
    event.mGenre = mGenre;
    event.frequency = frequency;
    event.price = price;
    event.link = link;
    event.pitch = pitch;
    event.desc = desc;
    event.vName = vName;
    event.vAddress = vAddress;
    event.markModified("imgs");
    event.name = name;
    event.types = types || []
    event.sDate = (sDate)?sDate+"z":sDate

    event.eDate =(eDate)? eDate+"z":eDate
    event.city = await getCity(cityID);
    event.dId = dId;
    event.tags=tags && JSON.parse(tags)
    event.canceled = Boolean(canceled == "on");
    event.currency=currency

    if (eventOldName !== event.name) {
      event.slug = await helpers.uniqueSlug(Event, name);
    }

    // update images
    const imagesLength = event.imgs ? event.imgs.length : 0;
    let splices = 0;
    for (let i = 0; i < imagesLength; i++) {
      if (!req.body[`img${i}`]) {
        await file.delete(event.imgs[i - splices].path, imagesPrefix);
        event.imgs.splice((i - splices), 1);
        splices++;
      }
    }
    const newImages = await file.save(req.files, imagesPrefix);
    event.imgs = event.imgs ? event.imgs.concat(newImages) : newImages;
    await Event.updateOne({ _id: id }, event);

    return res.redirect("/admin/events/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"EVENT","DELETE")) return res.redirect("/admin/events?code=-10")
    if (!id) {
      return res.redirect("/admin/events/?code=-1");
    }
    const eventExists = await Event.findById(id, "_id imgs");
    if (eventExists) {
      if (eventExists.imgs && eventExists.imgs.length) {
        for (let image of eventExists.imgs) {
          await file.delete(image.path, imagesPrefix);
        }
      }
    }
    await Event.deleteOne({ _id: id });
    return res.redirect("/admin/events/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/events/?code=-1");
    }

    await Event.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/events/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/active",async function(req,res,next){
  try {
    var {id,isActive}=req.body
    isActive=!!isActive
    if(!id) return res.json({code:1,msg:"Not found festival date"})
    var update = await Event.updateOne({_id:mongoose.Types.ObjectId(id)},{isActive})
    if(update.n ==0)return res.json({code:2,msg:"Not found festival date"})
    return res.json({code:0,msg:"Success"})
  } catch (error) {
    console.log(error)
    return res.json({code:-1,msg:error.message})
  }
})

module.exports = router;

async function getCity(id) {
  if (!id) return null;
  const city = await City.findByIdAndDeleteAt({ id });
  if (!city) return null;
  return { id: city.id, name: city.name };
}
