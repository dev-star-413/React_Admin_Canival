const express = require("express");
const router = express.Router();

const multer = require("multer");
const { uploads, bandDateScores, sectionTypes, lineTypes } = require("../config")();
const { Band } = require("../models/Band");
const { BandDate } = require("../models/BandDate");
const { Dates } = require("../models/Dates");
const { Designer } = require("../models/Designer");
const { Dynamics } = require("../models/Dynamics");
const { Line } = require("../models/Line");
const { Section } = require("../models/Section");
const { Comment } = require("../models/Comment");
const { deleteBandDateDependencies } = require("../services/deleteDependencies");
const upload = multer();
const fileHandler = require("../services/file");
const { uniqueSlug } = require("../services/helpers");
const imagesPrefix = "bandImages";
const videosPrefix = "videos";
const { Award } = require("../models/Award");
const accessManagement = require("../services/accessManagement");
const { CurrencyRate } = require("../models/CurrencyRate");
var mongoose = require('mongoose');
router.get("/", async function (req, res, next) {
  try {
    const { code } = req.query;
    if (!accessManagement.check(req.admin, "BAND_DATE", "INDEX")) return res.redirect("/admin?code=-10");
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted.`; //`The record has been deleted. <a href="${undo}">Undo</a>`;
    }
    var bandDates = await BandDate.find().sort({ name: 1 }).lean();
    const bands=[]
    for(var b of bandDates){
      let pararde=await Dates.findById(b.dateId,'paradeS')
      if(pararde)  b.parade=pararde.paradeS
      var secList=await Section.find({bdId:b._id.toString()},'types name img average').sort({types:1,name:1})
      var reviews=await Comment.find({docID:b._id.toString(),pId:{$exists:false}},'score.avg')
      var UR={length:0,value:0}//user review calculate the average of all review for that year
      if(reviews[0]){
        const length=reviews.length
        var sum=0
        reviews.forEach((rev)=>sum+=Number(rev.score && rev.score.avg ))
        UR.length=length
        UR.value=Number((sum/length).toFixed(1))
      }
      bands.push({...b,
        id:b._id.toString(),
        parade:pararde?.paradeS,
        secList, 
        ur:UR
      })
    }
    return res.view("bandDates/list", {
      operationResult,
      bandDates: bands,
      bandDateScores,
    });
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if (id && !accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddates?code=-10");
    if (!id && !accessManagement.check(req.admin, "BAND_DATE", "ADD")) return res.redirect("/admin/banddates?code=-10");
    var currencies=await CurrencyRate.find({},"from")
    var bandDate = await BandDate.findById(id);
    const dynamics = await Dynamics.findOne();
    const sections = await Section.find({ bdId: id });
    if (sections && sections[0]) {
      for (let i in sections) {
        let section = sections[i].toObject();

        if (section.img) {
          section.img.src = uploads.sectionImages + "/" + section.img.path;
        }

        if (section.addOns && Array.isArray(section.addOns)) {
          for (let index in section.addOns) {
            if (section.addOns[index].img) {
              section.addOns[index].img = `${uploads.addOnsImages}/${section.addOns[index].img.path}`;
            }
          }
        }
        // generate line images / addons path
        const lines = await Line.find({ sId: section._id });
        for (let counter in lines) {
          let line = lines[counter];
          if (line.addOns) {
            for (let addOn of line.addOns) {
              if (addOn.img) {
                addOn.img = `${uploads.addOnsImages}/${addOn.img.path}`;
              }
            }
          }
          if (line.gallery && line.gallery[0]) {
            for (let galleryImg of line.gallery) {
              galleryImg.src = uploads.lineImages + "/" + galleryImg.path;
            }
          }
          if (line.img) {
            line.img.src = uploads.lineImages + "/" + line.img.path;
          }
          lines[counter] = line;
        }
        // append lines to the section
        sections[i] = { ...section, lines: lines };
      }
    }
    // generate band date video path
    if (bandDate && bandDate.video) {
      bandDate.video.path = `${uploads.videos}/${bandDate.video.path}`;
    }
    var designers = await Designer.find({}, "_id name").sort({ name: 1 });
    var bands = await Band.find({}, "_id name").sort({ name: 1 });
    return res.view("bandDates/form", {
      operationResult: { code },
      bandDate,
      bands,
      carnivals: await Dates.find({}, "_id festival year"),
      themes: dynamics.themes,
      scoreMethods: bandDateScores,
      revellers: dynamics.revellers,
      lineTypes,
      services: dynamics.services,
      jouvertServices: dynamics.jouvertServices,
      childrenServices: dynamics.childrenServices,
      sections,
      sectionTypes,
      designers,
      colors: dynamics.colors,
      premiums: dynamics.premiums,
      brands: dynamics.brands,
      styles: dynamics.styles,
      standards: dynamics.standards,
      addOns: dynamics.addOns,
      bandDateDetails: dynamics.bandDateDetails,
      currencies
    });
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let {
      bandId,
      dateId,
      lDate,
      rdDate,
      preRegisPrice,
      localPrice,
      // price,
      preRegisDeadLine,
      desc,
      deposit,
      themeType,
      theme,
      year,
      reveller,
      locals,
      services,
      jouvertServices,
      isCustomeService,
      isJouvertService,
      sectionOptions,
      resultText,
      reviewText,
      meta,
      link,
      rdCurrency,
      complete,
      isChildrenService,
      childrenServices,
      jouvertTheme,
      jouvertLaunchDate,
      jouvertDeadlineDate,
      childrenTheme,
      childrenLaunchDate,
      childrenDeadlineDate,
      confirm,
      details,
      showAdult,
      showJouvert,
      showChildren,
    } = req.body;
    if (!accessManagement.check(req.admin, "BAND_DATE", "ADD")) return res.redirect("/admin/banddate?code=-10");
    if (bandId && dateId) {
      let band = await Band.findById(bandId);
      var bandLastYear=band.lastYear || 0
      let dateName = await Dates.findById(dateId);
      band = band.name;
      dateName = dateName.festival.name;
      // save video
      let video = req.files.filter((f) => f.fieldname == "video");
      if (video && video.length > 0) {
        video = await fileHandler.save(video, videosPrefix);
        video = video[0];
      } else {
        video = null;
      }
      if (services) {
        services = Array.isArray(services) ? services : [services];
      }
      // save images
      let imgs = req.files.filter((f) => f.fieldname == "imgs");
      if (imgs && imgs.length > 0) {
        imgs = await fileHandler.save(imgs, imagesPrefix);
      } else {
        imgs = null;
      }
      //save jouvert image
      var jImg=req.files.filter((f)=>f.fieldname=='jImg')
      if(jImg && jImg[0]){
        jImg=await fileHandler.save(jImg,imagesPrefix)
        jImg=jImg && jImg[0]
      }else jImg=null

      //save jouvert launch image
      var jlImg=req.files.filter((f)=>f.fieldname=='jlImg')
      if(jlImg && jlImg[0]){
        jlImg=await fileHandler.save(jlImg,imagesPrefix)
        jlImg=jlImg && jlImg[0]
      }else jlImg=null
      
      //save custome image
      var costumeImg=req.files.filter((f)=>f.fieldname=='costumeImg')
      if(costumeImg && costumeImg[0]){
        costumeImg=await fileHandler.save(costumeImg,imagesPrefix)
        costumeImg=costumeImg && costumeImg[0]
      }else costumeImg=null

      //save costume launch image
      var costumeLImg=req.files.filter((f)=>f.fieldname=='costumeLImg')
      if(costumeLImg && costumeLImg[0]){
        costumeLImg=await fileHandler.save(costumeLImg,imagesPrefix)
        costumeLImg=costumeLImg && costumeLImg[0]
      }else costumeLImg=null

      //save main image
      var mainImg=req.files.filter((f)=>f.fieldname=='mainImg')
      if(mainImg && mainImg[0]){
        mainImg=await fileHandler.save(mainImg,imagesPrefix)
        mainImg=mainImg && mainImg[0]
      }else mainImg=null

      //save children image
      var childrenImg=req.files.filter((f)=>f.fieldname=='childrenImg')
      if(childrenImg && childrenImg[0]){
        childrenImg=await fileHandler.save(childrenImg,imagesPrefix)
        childrenImg=childrenImg && childrenImg[0]
      }else childrenImg=null

      //save children image
      var childrenlImg=req.files.filter((f)=>f.fieldname=='childrenlImg')
      if(childrenlImg && childrenlImg[0]){
        childrenlImg=await fileHandler.save(childrenlImg,imagesPrefix)
        childrenlImg=childrenlImg && childrenlImg[0]
      }else childrenlImg=null

      isCustomeService = isCustomeService ? true : false;
      isJouvertService = isJouvertService ? true : false;
      isChildrenService = isChildrenService ? true : false;
      complete = complete ? true : false;
      await BandDate.create({
        dateId,
        bandId,
        name: band,
        dateName,
        lDate: lDate,
        rdDate: rdDate,
        preRegisPrice,
        preRegisDeadLine: preRegisDeadLine,
        localPrice,
        // price,
        desc,
        deposit,
        themeType,
        sectionOptions,
        services,
        theme,
        year,
        resultText,
        reveller,
        locals,
        video,
        imgs,
        jouvertServices,
        isCustomeService,
        isJouvertService,
        reviewText,
        slug: await uniqueSlug(BandDate, `${band} ${year}`),
        meta,
        link,
        jImg,
        jlImg,
        rdCurrency,
        complete,
        isChildrenService,
        childrenServices,
        jouvertTheme,
        childrenTheme,
        jouvertLaunchDate:jouvertLaunchDate ,
        jouvertDeadlineDate:jouvertDeadlineDate ,
        childrenLaunchDate:childrenLaunchDate ,
        childrenDeadlineDate:childrenDeadlineDate,
        mainImg,
        costumeLImg,
        childrenImg,
        childrenlImg,
        costumeImg,
        confirm,
        details,
        showAdult:(showAdult=='on')?true:false,
        showJouvert:(showJouvert=='on')?true:false,
        showChildren:(showChildren=='on')?true:false,
      });
      if(year >bandLastYear) await Band.update({_id:bandId},{lastYear:year})
      return res.redirect("/admin/banddates/?code=201");
    }
    return res.redirect("/admin/banddates/form/?code=-1");
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    var {
      id,
      bandId,
      dateId,
      lDate,
      rdDate,
      preRegisPrice,
      localPrice,
      // price,
      preRegisDeadLine,
      desc,
      deposit,
      themeType,
      sectionOptions,
      theme,
      year,
      reveller,
      resultText,
      locals,
      videoPath,
      services,
      jouvertServices,
      isCustomeService,
      isJouvertService,
      reviewText,
      meta,
      link,
      oldJImg,
      oldJlImg,
      oldMainImg,
      oldCostumeImg,
      oldCostumeLImg,
      oldChildrenImg,
      oldChildrenlImg,
      rdCurrency,
      complete,
      isChildrenService,
      childrenServices,
      jouvertTheme,
      jouvertLaunchDate,
      jouvertDeadlineDate,
      childrenTheme,
      childrenLaunchDate,
      childrenDeadlineDate,
      confirm,
      details,
      showAdult,
      showJouvert,
      showChildren,
    } = req.body;
    const bandDate = await BandDate.findById(id);
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");
    if (id && bandId && dateId && bandDate) {
      let band = await Band.findById(bandId, "_id name video lastYear");
      var bandLastYear=band.lastYear || 0
      let carniv = await Dates.findById(dateId, "_id festival");
      let slug = bandDate.slug;
      const oldSlug = slug;
      let video = bandDate.video;
      let imgs = bandDate.imgs;
      var mainImg=bandDate.mainImg
      var childrenImg=bandDate.childrenImg
      var childrenlImg=bandDate.childrenlImg
      var costumeImg=bandDate.costumeImg
      var costumeLImg=bandDate.costumeLImg
      var jImg=bandDate.jImg
      var jlImg=bandDate.jlImg

      let newVideo = req.files.filter((f) => f.fieldname == "video");
      let newImages = req.files.filter((f) => f.fieldname == "imgs");
      var newJImg = req.files.filter((f) => f.fieldname == "jImg"); 
      var newJlImg = req.files.filter((f) => f.fieldname == "jlImg");
      var newMainImg = req.files.filter((f) => f.fieldname == "mainImg");
      var newChildrenImg = req.files.filter((f) => f.fieldname == "childrenImg"); 
      var newChildrenlImg = req.files.filter((f) => f.fieldname == "childrenlImg");
      var newCostumeImg = req.files.filter((f) => f.fieldname == "costumeImg");
      var newCostumeLImg = req.files.filter((f) => f.fieldname == "costumeLImg");

      if (services) {
        services = Array.isArray(services) ? services : [services];
      }
      // modify slug
      if (band.name != bandDate.name || year != bandDate.year) {
        slug = await uniqueSlug(BandDate, `${band && band.name} ${year}`);
      }
      // update band date video
      if (newVideo && newVideo.length > 0) {
        if (video) {
          await fileHandler.delete(video.path, videosPrefix);
        }
        video = await fileHandler.save(newVideo[0], videosPrefix);
        video = video[0];
      } else if (video && !videoPath) {
        await fileHandler.delete(video.path, videosPrefix);
        video = null;
      }
      // update old images
      // if (imgs && imgs.length > 0) {
      //   const length = imgs.length;
      //   let splices = 0;
      //   for (let index = 0; index < length; index++) {
      //     if (!req.body[`img${index}`]) {
      //       await fileHandler.delete(imgs[index - splices].path, imagesPrefix);
      //       imgs.splice(index - splices, 1);
      //       splices++;
      //     }
      //   }
      // }
      // save new images
      // if (newImages && newImages.length > 0) {
      //   newImages = await fileHandler.save(newImages, imagesPrefix);
      //   imgs = imgs ? imgs.concat(newImages) : newImages;
      // }
      // update  jouvert image
      if((!oldJImg || newJImg && newJImg[0]) && bandDate.jImg && bandDate.jImg.path){
        await fileHandler.delete(bandDate.jImg && bandDate.jImg.path, imagesPrefix);
        jImg=null
      }
      if(newJImg && newJImg[0] ){
        newJImg = await fileHandler.save(newJImg, imagesPrefix);
        jImg=newJImg && newJImg[0]
      }
      // update jouvert launch image
      if((!oldJlImg || newJlImg && newJlImg[0]) && bandDate.jlImg && bandDate.jlImg.path){
        await fileHandler.delete(bandDate.jlImg && bandDate.jlImg.path, imagesPrefix);
        jlImg=null
      }
      if(newJlImg && newJlImg[0] ){
        newJlImg = await fileHandler.save(newJlImg, imagesPrefix);
        jlImg=newJlImg && newJlImg[0]
      }
      // update main image
      if((!oldMainImg || newMainImg && newMainImg[0]) && bandDate.mainImg && bandDate.mainImg.path){
        await fileHandler.delete(bandDate.mainImg && bandDate.mainImg.path, imagesPrefix);
        mainImg=null
      }
      if(newMainImg && newMainImg[0] ){
        newMainImg = await fileHandler.save(newMainImg, imagesPrefix);
        mainImg=newMainImg && newMainImg[0]
      }
      // update costume image
      if((!oldCostumeImg || newCostumeImg && newCostumeImg[0]) && bandDate.costumeImg && bandDate.costumeImg.path){
        await fileHandler.delete(bandDate.costumeImg && bandDate.costumeImg.path, imagesPrefix);
        costumeImg=null
      }
      if(newCostumeImg && newCostumeImg[0] ){
        newCostumeImg = await fileHandler.save(newCostumeImg, imagesPrefix);
        costumeImg=newCostumeImg && newCostumeImg[0]
      }
      // update costume launch image
      if((!oldCostumeLImg || newCostumeLImg && newCostumeLImg[0]) && bandDate.costumeLImg && bandDate.costumeLImg.path){
        await fileHandler.delete(bandDate.costumeLImg && bandDate.costumeLImg.path, imagesPrefix);
        costumeLImg=null
      }
      if(newCostumeLImg && newCostumeLImg[0] ){
        newCostumeLImg = await fileHandler.save(newCostumeLImg, imagesPrefix);
        costumeLImg=newCostumeLImg && newCostumeLImg[0]
      }
      // update children image
      if((!oldChildrenImg || newChildrenImg && newChildrenImg[0]) && bandDate.childrenImg && bandDate.childrenImg.path){
        await fileHandler.delete(bandDate.childrenImg && bandDate.childrenImg.path, imagesPrefix);
        childrenImg=null
      }
      if(newChildrenImg && newChildrenImg[0] ){
        newChildrenImg = await fileHandler.save(newChildrenImg, imagesPrefix);
        childrenImg=newChildrenImg && newChildrenImg[0]
      }
      // update children launch image
      if((!oldChildrenlImg || newChildrenlImg && newChildrenlImg[0]) && bandDate.childrenlImg && bandDate.childrenlImg.path){
        await fileHandler.delete(bandDate.childrenlImg && bandDate.childrenlImg.path, imagesPrefix);
        childrenlImg=null
      }
      if(newChildrenlImg && newChildrenlImg[0] ){
        newChildrenlImg = await fileHandler.save(newChildrenlImg, imagesPrefix);
        childrenlImg=newChildrenlImg && newChildrenlImg[0]
      }
      isCustomeService = isCustomeService ? true : false;
      isJouvertService = isJouvertService ? true : false;
      isChildrenService = isChildrenService ? true : false;
      complete = complete ? true : false;
      if (jouvertServices) {
        jouvertServices = Array.isArray(jouvertServices) ? jouvertServices : [jouvertServices];
      }
      await BandDate.updateOne(
        { _id: id },
        {
          bandId,
          services,
          name: band.name,
          dateName: carniv.festival && carniv.festival.name,
          dateId,
          lDate: lDate,
          slug,
          sectionOptions,
          resultText,
          desc,
          deposit,
          themeType,
          theme,
          year,
          rdDate ,
          preRegisPrice,
          preRegisDeadLine: preRegisDeadLine,
          localPrice,
          // price,
          reveller,
          locals,
          imgs,
          video,
          jouvertServices,
          isCustomeService,
          isJouvertService,
          reviewText,
          meta,
          link,
          jImg,
          jlImg,
          rdCurrency,
          complete:complete,
          mainImg,
          childrenImg,
          childrenlImg,
          costumeImg,
          costumeLImg,
          isChildrenService,
          childrenServices,
          jouvertTheme,
          childrenTheme,
          jouvertLaunchDate:jouvertLaunchDate , 
          jouvertDeadlineDate:jouvertDeadlineDate,
          childrenLaunchDate:childrenLaunchDate,
          childrenDeadlineDate:childrenDeadlineDate,
          confirm,
          details,
          showAdult:(showAdult=='on')?true:false,
          showJouvert:(showJouvert=='on')?true:false,
          showChildren:(showChildren=='on')?true:false,
        }
      );
      if(year >bandLastYear) await Band.update({_id:bandId},{lastYear:year})

      if (oldSlug !== slug) {
        await updateNameAndSlugDependencies(bandDate.id, band.name, slug);
      }

      return res.redirect("/admin/banddates/?code=201");
    }
    return res.redirect("/admin/banddates/form/?code=-1");
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!accessManagement.check(req.admin, "BAND_DATE", "DELETE")) return res.redirect("/admin/banddate?code=-10");
    if (id) {
      await deleteBandDateDependencies(id);
      return res.redirect("/admin/banddates/?code=205");
    }
    return res.redirect("/admin/banddates/?code=-1");
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/score", async function (req, res, next) {
  try {
    var params = req.body;
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");
    var { bandDateId } = params;
    if (!bandDateId) return res.redirect("/admin/banddates?code=-1");
    var band = await BandDate.findById(bandDateId);
    if (!band) return res.redirect("/admin/banddates?code=-1");
    var oldScores = band && band.scores;
    var newScores = [];
    var sum = 0;
    for (var score of bandDateScores) {
      let bandScore = oldScores.find((index) => index.method == score.method);
      if (!bandScore) bandScore = {};
      var input = params[score && score.method];
      bandScore["score"] = input;
      bandScore["method"] = score && score.method;
      bandScore["title"] = score && score.title;
      newScores.push(bandScore);
      sum += parseFloat(input);
    }
    var average = sum / bandDateScores.length;
    let updateBand = await BandDate.findByIdAndUpdate(bandDateId, { scores: newScores, score: average });

    return res.redirect("/admin/banddates?code=200");
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/compare/create", async function (req, res, next) {
  try {
    var { bdId, sections } = req.body;
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");
    const bandDate = await BandDate.findById(bdId, "compares");
    sections = sections.split(",");
    const sectionsData = await Section.find({ _id: sections }, "_id name img");
    if (sectionsData.length > 1) {
      const offset = sectionsData.length - 2;
      sectionsData.splice(2, offset);
      bandDate.compares.push({ sections: sectionsData });
      await BandDate.updateOne({ _id: bdId }, { $set: { compares: bandDate.compares } });
    }
    return res.redirect(`/admin/banddates/form?id=${bdId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/compare/update", async function (req, res, next) {
  try {
    var { bdId, sections, index } = req.body;
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");
    sections = sections.split(",");
    let bandDate = await BandDate.findById(bdId, "compares");
    const sectionsData = await Section.find({ _id: sections }, "_id name img");
    if (sectionsData.length > 1) {
      const offset = sectionsData.length - 2;
      sectionsData.splice(2, offset);
      bandDate.compares[index].sections = sectionsData;
      await BandDate.updateOne({ _id: bdId }, { compares: bandDate.compares });
    }
    return res.redirect(`/admin/banddates/form?id=${bdId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.get("/compare/delete", async function (req, res, next) {
  try {
    const { bdId, index } = req.query;
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");
    const bandDate = await BandDate.findById(bdId, "compares");
    bandDate.compares.splice(index, 1);
    await BandDate.updateOne({ _id: bdId }, { compares: bandDate.compares });
    return res.redirect(`/admin/banddates/form?id=${bdId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
});

// Find Band-dates of one festival-date 
router.post("/filter" ,async function (req,res,next){
  try {
    const {fesId,year}=req.body
    if(!fesId || !year) return res.json({code:-2,msg:"please send festival and year",data:[]})
    const dates=await Dates.find({'festival.id':mongoose.Types.ObjectId(fesId),year:year-1})
    if(!dates || !dates[0]) return res.json({code:0,msg:"Not Found", data:[]})
    const lastDate=dates[0]
    var lastBandDates=await BandDate.find({dateId:lastDate._id},'name   year')
    return res.json({code:0,msg:"Success",data:lastBandDates})
  } catch (error) {
    console.log(error)
    return res.json({code:-1,msg:"Something is wrong."})
  }
})


module.exports = router;

async function updateNameAndSlugDependencies(bandDateID, newBandDateName, newBandDateSlug) {
  try {
    const awards = await Award.find();
    let shouldUpdate = false;
    for (let award of awards) {
      if (Array.isArray(award.cats)) {
        for (let cat of award.cats) {
          if (Array.isArray(cat.positions)) {
            for (let position of cat.positions) {
              if (Array.isArray(position.bands)) {
                for (let band of position.bands) {
                  if (band._id == bandDateID) {
                    band.slug = newBandDateSlug;
                    band.name = newBandDateName;
                    shouldUpdate = true;
                  }
                }
              }
            }
          }
        }
      }

      if (shouldUpdate) {
        award.markModified("cats");
        await award.save();
      }
    }
  } catch (err) {
    throw err;
  }
}
