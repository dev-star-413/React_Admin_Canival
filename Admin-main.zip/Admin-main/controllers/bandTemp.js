const express = require("express");
const router = express.Router();

const multer = require("multer");
const {
    uploads,
    bandDateScores,
    sectionTypes,
    lineTypes
} = require("../config")();
const { Band } = require("../models/Band");
const { BandTemp } = require("../models/BandTemp");
const { BandDate } = require('../models/BandDate');
const { Dates } = require("../models/Dates");
const { Designer } = require("../models/Designer");
const { Dynamics } = require("../models/Dynamics");
const { Line } = require("../models/Line");
const { Section } = require("../models/Section");
const upload = multer();

const fileHandler = require("../services/file");
const { uniqueSlug } = require("../services/helpers");
const accessManagement = require("../services/accessManagement");
const imagesPrefix = "bandImages";
const videosPrefix = "videos";
router.get("/", async function (req, res, next) {
    try {
        const { code } = req.query;
        let operationResult = { code };
        if(!accessManagement.check(req.admin,"BAND_TEMP","INDEX")) return res.redirect("/admin?code=-10")
        if (code == 205) {
            operationResult.msg = `The record has been deleted.`; //`The record has been deleted. <a href="${undo}">Undo</a>`;
        }
        var bandDates = await BandTemp.find()
        return res.view("bandTemps/list", {
            operationResult,
            bandDates: bandDates,
            bandDateScores
        });
    } catch (error) {
        return next(error, req, res, next);
    }
});

router.get("/form", async function (req, res, next) {
    try {
        const { code, id } = req.query;
        if(id && !accessManagement.check(req.admin,"BAND_TEMP","EDIT")) return res.redirect("/admin/bandtemps?code=-10")
        if(!id && !accessManagement.check(req.admin,"BAND_TEMP","ADD")) return res.redirect("/admin/bandtemps?code=-10")
        var bandDate = await BandTemp.findById(id);
        const dynamics = await Dynamics.findOne();
        const sections = await Section.find({ bdId: id });
        // generate section image path
        sections.map(section => {
            if (section.img) {
                section.img = `${uploads.sectionImages}/${section.img.path}`;
            }
        });
        // generate section add on images path
        for (let i in sections) {
            let section = sections[i].toObject();
            if (section.addOns && Array.isArray(section.addOns)) {
                for (let index in section.addOns) {
                    if (section.addOns[index].img) {
                        section.addOns[
                            index
                        ].img = `${uploads.addOnsImages}/${section.addOns[index].img.path}`;
                    }
                }
            }
            // generate line images / addons path
            const lines = await Line.find({ sId: section._id });
            for (let counter in lines) {
                let line = lines[counter];
                if (line.addOns) {
                    for (let addOn of line.addOns) {
                        if (addOn.img) {
                            addOn.img = `${uploads.addOnsImages}/${addOn.img.path}`;
                        }
                    }
                }
                if (line.imgs) {
                    let index = 0;
                    for (let img of line.imgs) {
                        line.imgs[index++] = `${uploads.lineImages}/${img.path}`;
                    }
                }
                lines[counter] = line;
            }
            // append lines to the section
            sections[i] = { ...section, lines: lines };
        }
        // generate band date video path
        if (bandDate && bandDate.video) {
            bandDate.video.path = `${uploads.videos}/${bandDate.video.path}`;
        }
        // generate band date images path
        if (bandDate && bandDate.imgs) {
            bandDate.imgs.map(img => {
                img.path = `${uploads.bandImages}/${img.path}`;
            });
        }
        return res.view("bandTemps/form", {
            operationResult: { code },
            bandDate,
            bands: await Band.find({}, "_id name"),
            carnivals: await Dates.find({}, "_id festival year"),
            themes: dynamics.themes,
            scoreMethods: bandDateScores,
            revellers: dynamics.revellers,
            lineTypes,
            services: dynamics.services,
            sections,
            sectionTypes,
            designers: await Designer.find({}, "_id name"),
            colors: dynamics.colors,
            premiums: dynamics.premiums,
            brands: dynamics.brands,
            styles: dynamics.styles,
            standards: dynamics.standards,
            addOns: dynamics.addOns
        });
    } catch (error) {
        return next(error, req, res, next);
    }
});

router.post("/create", upload.any(), async function (req, res, next) {
    try {
        let {
            bandId,
            dateId,
            lDate,
            rdDate,
            desc,
            deposit,
            themeType,
            theme,
            year,
            reveller,
            locals,
            services,
            sectionOptions,
            resultText
        } = req.body;
        if(!accessManagement.check(req.admin,"BAND_TEMP","ADD")) return res.redirect("/admin/bandtemps?code=-10")
        if (bandId && dateId) {
            let band = await Band.findById(bandId);
            let dateName = await Dates.findById(dateId);
            band = band.name;
            dateName = dateName.festival.name;
            // save video
            let video = req.files.filter(f => f.fieldname == "video");
            if (video && video.length > 0) {
                video = await fileHandler.save(video, videosPrefix);
                video = video[0];
            } else {
                video = null;
            }
            if (services) {
                services = Array.isArray(services) ? services : [services];
            }
            // save images
            let imgs = req.files.filter(f => f.fieldname == "imgs");
            if (imgs && imgs.length > 0) {
                imgs = await fileHandler.save(imgs, imagesPrefix);
            } else {
                imgs = null;
            }
            // get scores
            const scoreData = getScores(req.body);
            await BandTemp.create({
                dateId,
                bandId,
                name: band,
                dateName,
                lDate:(lDate)?lDate+"z":lDate,
                rdDate:(rdDate)?rdDate+"z":rdDate,
                desc,
                deposit,
                themeType,
                sectionOptions,
                services,
                scores: scoreData.scores,
                score: scoreData.average,
                theme,
                year,
                resultText,
                reveller,
                locals,
                video,
                imgs,
                at: new Date(),
                by: req.admin._id.toString(),
                slug: await uniqueSlug(BandDate, `${band} ${year}`)
            });
            return res.redirect("/admin/bandtemps/?code=201");
        }
        return res.redirect("/admin/bandtemps/form/?code=-1");
    } catch (error) {
        return next(error, req, res, next);
    }
});

router.post("/update", upload.any(), async function (req, res, next) {
    try {
        var {
            id,
            bandId,
            dateId,
            lDate,
            rdDate,
            desc,
            deposit,
            themeType,
            sectionOptions,
            theme,
            year,
            reveller,
            resultText,
            locals,
            videoPath,
            services
        } = req.body;
        if(!accessManagement.check(req.admin,"BAND_TEMP","EDIT")) return res.redirect("/admin/bandtemps?code=-10")
        if (id && bandId && dateId && (await BandTemp.findById(id))) {
            let band = await Band.findById(bandId, "_id name video");
            let carniv = await Dates.findById(dateId, "_id festival");
            const bandDate = await BandTemp.findOne({ _id: id });
            let slug = bandDate.slug;
            let video = bandDate.video;
            let imgs = bandDate.imgs;
            let newVideo = req.files.filter(f => f.fieldname == "video");
            let newImages = req.files.filter(f => f.fieldname == "imgs");
            if (services) {
                services = Array.isArray(services) ? services : [services];
            }
            // modify slug
            if (band.name != bandDate.name || year != bandDate.year) {
                slug = await uniqueSlug(BandDate, `${band && band.name}-${year}`);
            }
            // update band date video
            if (newVideo && newVideo.length > 0) {
                if (video) {
                    await fileHandler.delete(video.path, videosPrefix);
                }
                video = await fileHandler.save(newVideo[0], videosPrefix);
                video = video[0];
            } else if (video && !videoPath) {
                await fileHandler.delete(video.path, videosPrefix);
                video = null;
            }
            // update old images
            if (imgs && imgs.length > 0) {
                const length = imgs.length;
                let splices = 0;
                for (let index = 0; index < length; index++) {
                    if (!req.body[`img${index}`]) {
                        await fileHandler.delete(imgs[index - splices].path, imagesPrefix);
                        imgs.splice(index - splices, 1);
                        splices++;
                    }
                }
            }
            // save new images
            if (newImages && newImages.length > 0) {
                newImages = await fileHandler.save(newImages, imagesPrefix);
                imgs = imgs ? imgs.concat(newImages) : newImages;
            }
            // update scores
            const scoreData = getScores(req.body);
            await BandTemp.updateOne(
                { _id: id },
                {
                    bandId,
                    services,
                    name: band.name,
                    dateName: carniv.festival && carniv.festival.name,
                    dateId,
                    lDate:(lDate)?lDate+"z":lDate,
                    slug,
                    sectionOptions,
                    resultText,
                    desc,
                    deposit,
                    themeType,
                    theme,
                    year,
                    rdDate:(rdDate)?rdDate+"z":rdDate,
                    reveller,
                    locals,
                    scores: scoreData.scores,
                    score: scoreData.average,
                    imgs,
                    video
                }
            );
            return res.redirect("/admin/bandtemps/?code=201");
        }
        return res.redirect("/admin/bandtemps/form/?code=-1");
    } catch (error) {
        return next(error, req, res, next);
    }
});

router.get("/delete", async function (req, res, next) {
    try {
        const { id } = req.query;
        if(!accessManagement.check(req.admin,"BAND_TEMP","DELETE")) return res.redirect("/admin/bandtemps?code=-10")
        if (id) {
            const band = await BandTemp.findById(id);
            if (band) {
                // delete video
                if (band.video && band.video.path) {
                    await fileHandler.delete(band.video.path, videosPrefix);
                }
                // delete images
                if (band.imgs && band.imgs.length) {
                    for (let image of band.imgs) {
                        await fileHandler.delete(image.path, imagesPrefix);
                    }
                }
                const sections = await Section.find({ bdId: id }, "_id bdId imgs");
                for (let section of sections) {
                    // delete section gallery images
                    if (section.imgs) {
                        for (let img of section.imgs) {
                            await fileHandler.delete(img.path, "sectionImages");
                        }
                    }
                    // delete line dependencies
                    const lines = await Line.find({ sId: section._id });
                    for (let line of lines) {
                        if (line.addOns) {
                            for (let addOn of line.addOns) {
                                if (addOn.img) {
                                    await fileHandler.delete(addOn.img.path, "addOnsImages");
                                }
                            }
                        }
                    }
                    await Line.deleteMany({ sId: section._id });
                }
                await Section.deleteMany({ bdId: id });
                await BandTemp.deleteOne({ _id: id });
            }
            return res.redirect("/admin/bandtemps/?code=205");
        }
        return res.redirect("/admin/bandtemps/?code=-1");
    } catch (error) {
        return next(error, req, res, next);
    }
});

router.get('/confirm', async function (req, res, next) {
    try {
        const { id } = req.query;
        if(!accessManagement.check(req.admin,"BAND_TEMP","EDIT")) return res.redirect("/admin/bandtemps?code=-10")
        if (id) {
            let band = await BandTemp.findById(id);
            band.confirmedAt = new Date();
            band.confirmed = true;
            band.confirmedBy = req.admin._id.toString();
            const sectionsCount = await Section.find({ bdId: id }, "_id").countDocuments();
            const newBand = await BandDate.create({
                bandId: band.bandId,
                name: band.name,
                dateId: band.dateId,
                dateName: band.dateName,
                year: band.year,
                themeType: band.themeType,
                theme: band.theme,
                lDate: band.lDate,
                rdDate: band.rdDate,
                video: band.video,
                imgs: band.imgs,
                deposit: band.deposit,
                desc: band.desc,
                sectionOptions: null,
                reveller: band.reveller,
                locals: band.locals,
                slug: await uniqueSlug(BandDate, `${band.name}-${band.year}`),
                agree: [],
                resultText: null,
                disagree: [],
                notsure: [],
                likeC: 0,
                commentC: 0,
                comments: [],
                hot: 0,
                scores: [],
                score: 0,
                reviews: [],
                services: band.services,
                sections: sectionsCount,
                createAt: new Date(),
                deleteAt: null,
            });
            
            await Section.updateMany({ bdId: id }, { bdId: newBand._id.toString() })
            await BandTemp.deleteOne({ _id: id });
            return res.redirect("/admin/bandtemps/?code=201");
        }
        return res.redirect("/admin/bandtemps/?code=-1");
    } catch (error) {
        return next(error, req, res, next)
    }
})

router.post("/score", async function (req, res, next) {
    try {
        var params = req.body
        if(!accessManagement.check(req.admin,"BAND_TEMP","EDIT")) return res.redirect("/admin/bandtemps?code=-10")
        var { bandDateId } = params
        if (!bandDateId) return res.redirect("/admin/bandtemps?code=-1")
        var band = await BandTemp.findById(bandDateId)
        if (!band) return res.redirect("/admin/bandtemps?code=-1")
        var oldScores = band && band.scores
        var newScores = []
        var sum = 0
        for (var score of bandDateScores) {
            let bandScore = oldScores.find((index) => index.method == score.method)
            if (!bandScore) bandScore = {}
            var input = params[score && score.method]
            bandScore['score'] = input
            bandScore['method'] = score && score.method
            bandScore['title'] = score && score.title
            newScores.push(bandScore)
            sum += parseFloat(input)
        }
        var average = sum / bandDateScores.length
        let updateBand = await BandTemp.findByIdAndUpdate(bandDateId, { scores: newScores, score: average })

        return res.redirect("/admin/bandtemps?code=200")
    } catch (error) {
        return next(error, req, res, next);
    }
})

function getScores(data) {
    const scores = [];
    let index = 0;
    let sum = 0;
    bandDateScores.map(score => {
        var method = score.method
        if (data[`${method}Score`] || data[`${method}Desc`]) {
            sum += parseFloat(data[`${method}Score`]);
            scores.push({
                method: method,
                title: score && score.title,
                score: data[`${method}Score`],
                desc: data[`${method}Desc`]
            });
        }
        index++;
    });
    const average = sum / index;
    return { scores, average };
}

module.exports = router;
