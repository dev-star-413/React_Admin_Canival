const express = require("express");
const router = express.Router();
const helpers = require("../services/helpers");
const { City } = require("../models/City");
const timeZones = require("../config/timeZones");
const { Blog } = require("../models/Blog");
const { Dynamics } = require("../models/Dynamics");
const { Event } = require("../models/Event");
const { FestivalYear } = require("../models/FestivalYear");
const { Types } = require("mongoose");
const accessManagement=require("../services/accessManagement");
const { EventTemp } = require("../models/EventTemp");
const {getCurrencyRate} =require("../services/helpers");
const {getCountries} =require("../services/helpers");
const { CurrencyRate } = require("../models/CurrencyRate");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if( !accessManagement.check(req.admin,"CITY","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const cities = await City.find({ deleteAt: null });
    return res.view("cities/list", { operationResult, cities });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code } = req.query;
    if(!id && !accessManagement.check(req.admin,"CITY","ADD")) return res.redirect("/admin/cities?code=-10")
    if(id && !accessManagement.check(req.admin,"CITY","EDIT")) return res.redirect("/admin/cities?code=-10")
    const city = await City.findByIdAndDeleteAt({ id });
    const dynamics = await Dynamics.findOne({}, "regions");
    const countries=getCountries()
    var currencies = await CurrencyRate.find({},"from")
    return res.view("cities/form", { operationResult: { code }, city, timeZones, regions: dynamics.regions ,countries, currencies });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", async function (req, res, next) {
  try {
    const { name, region, state, code, tz, lat, lng, currencyCode } = req.body;
    const countries=getCountries()
    var latlng={lat,lng}
    if(!accessManagement.check(req.admin,"CITY","ADD")) return res.redirect("/admin/cities?code=-10")
    if (!name || !region || !state || !code || !tz) {
      return res.redirect("/admin/cities/form/?code=-1");
    }
    let country=countries.find((co)=>co.id===code)
    const finalSlug = await helpers.uniqueSlug(City, name);
    await City.create({
      name,
      region,
      state,
      code: country.id,
      country:country.name,
      tz,
      currencyCode,
      slug: finalSlug,
      latlng,
      currency:country.currencyId
    });
    if(country.currencyId != "USD"){
      var cRate=await CurrencyRate.findOne({from:country.currencyId})
      if(!cRate){
        let rate=await getCurrencyRate(country.currencyId)
        if(rate){
          await CurrencyRate.create({
            country:country.name,
            from:country.currencyId,
            rate,
            symbol:country.currencySymbol
          })
        }
      }
    }
    return res.redirect("/admin/cities/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", async function (req, res, next) {
  try {
    const { id, name, region, state, code, tz , lat, lng, currencyCode } = req.body;
    const countries=getCountries()
    var latlng ={lat,lng}
    if(!accessManagement.check(req.admin,"CITY","EDIT")) return res.redirect("/admin/cities?code=-10")
    if (!id || !name || !region || !state || !code || !tz || !currencyCode) {
      return res.redirect("/admin/cities/form/?code=-1");
    }
    let country=countries.find((co)=>co.id===code)
    let city = await City.findById(id);
    if (!city) {
      return res.redirect("/admin/cities/form/?code=-2");
    }
    const cityOldName = city.name;
    const cityOldRegion = city.region;
    if(country.currencyId != "USD"){
      var cRate=await CurrencyRate.findOne({from:country.currencyId})
      if(!cRate){
        let rate=await getCurrencyRate(country.currencyId)
        if(rate){
          await CurrencyRate.create({
            country:country.name,
            from:country.currencyId,
            rate,
            symbol:country.currencySymbol
          })
        }
      }
    }
    city.name = name;
    city.region = region;
    city.state = state;
    city.code = country.id;
    city.country = country.name;
    city.tz = tz;
    city.currencyCode = currencyCode;
    city.latlng=latlng
    city.currency=country.currencyId
    if (cityOldName !== city.name) {
      city.slug = await helpers.uniqueSlug(City, name);
    }

    await city.save();

    if (cityOldName !== city.name) {
      await updateNameAndSlugDependencies(city.id, city.name, city.slug);
    }
    if (cityOldRegion !== city.region) {
      await updateRegionDependencies(city.id, city.region);
    }

    return res.redirect("/admin/cities/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"CITY","DELETE")) return res.redirect("/admin/cities?code=-10")
    if (!id) {
      return res.redirect("/admin/cities/?code=-1");
    }

    await City.deleteOne({ _id: id });
    return res.redirect("/admin/cities/?code=205");
    await City.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    return res.redirect(
      "/admin/cities/?code=205&undo=" + encodeURIComponent("/admin/cities/undoDelete?id=" + id)
    );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/cities/?code=-1");
    }

    await City.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/cities/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;

async function updateNameAndSlugDependencies(cityID, newCityName, newCitySlug) {
  await Blog.updateMany(
    { "cities._id": Types.ObjectId(cityID) },
    { $set: { "cities.$.name": newCityName, "cities.$.slug": newCitySlug } }
  );
  await Event.updateMany({ "city.id": cityID }, { $set: { "city.name": newCityName } });
  await EventTemp.updateMany({ "city.id": cityID }, { $set: { "city.name": newCityName } });
  await FestivalYear.updateMany({ "city.id": cityID }, { $set: { "city.name": newCityName } });
}

async function updateRegionDependencies(cityID, newRegionName) {
  await FestivalYear.updateMany(
    { "city.id": cityID },
    { $set: { "city.region": newRegionName } }
  );
}
