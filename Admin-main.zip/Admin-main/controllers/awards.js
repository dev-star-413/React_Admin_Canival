const express = require("express");
const router = express.Router();
const { Award } = require("../models/Award");
const { City } = require("../models/City");
const { Dates } = require("../models/Dates");
const multer = require("multer");
const file = require("../services/file");
const { uploads } = require("../config")();
const { uniqueSlug } = require("../services/helpers");
const { Dynamics } = require("../models/Dynamics");
const { BandDate } = require("../models/BandDate");
const { Vote } = require("../models/Vote");
const { Band } = require("../models/Band");
const upload = multer();
const imgaesPrefix = "awardCatImages";
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    const { code } = req.query;
    if(!accessManagement.check(req.admin,"AWARD","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }

    const awards = await Award.find({ deleteAt: null });

    for (let award of awards) {
      let dates = await Dates.findById(award.dId, "festival year");
      if (dates && dates.festival) {
        award.dId = `${dates.festival.name} - ${dates.year}`;
      }
    }

    return res.view("awards/list", { operationResult, awards });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code } = req.query;
    if(id && !accessManagement.check(req.admin,"AWARD","EDIT"))return res.redirect("/admin/awards?code=-10")
    if(! id && ! accessManagement.check(req.admin,"AWARD","ADD")) return res.redirect("/admin/awards?code=-10")
    const award = await Award.findByIdAndDeleteAt({ id });
    var bands = await BandDate.find({ dateId: award ? award.dId : null }, "_id name");
    const cities = await City.find({ deleteAt: null });
    const festivalYears = await Dates.find({ canceled: false }, "festival year");
    var dynamic = await Dynamics.findOne({}, "catTags");
    var catTags = dynamic.catTags;
    if (award && award.cats) {
      award.cats.map((category) => {
        if (category.positions) {
          category.positions.map((position) => {
            if (position.img) {
              position.img.path = `${uploads.awardCatImages}/${position.img.path}`;
            }
          });
        }
      });
    }
    return res.view("awards/form", {
      operationResult: { code },
      award,
      cities,
      festivalYears,
      catTags,
      bands,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.array("imgs"), async function (req, res, next) {
  try {
    let { name, keywords, date, desc, canceled, cReason, cityID, dId } = req.body;
    if(!accessManagement.check(req.admin,"AWARD","ADD")) return res.redirect("/admin/awards?code=-10")
    canceled = Boolean(canceled === "on");
    const city = await getCity(cityID);
    const slug = await uniqueSlug(Award, name);
    const festivalDate = await Dates.findById(dId, "festival");
    if (festivalDate) {
      await Award.create({
        name,
        keywords,
        date:(date)?date+"z":date,
        desc,
        canceled,
        cReason,
        city,
        dId,
        slug,
        fId: festivalDate.festival.id,
      });
    } else {
      await Award.create({ name, keywords, date, desc, canceled, cReason, city, dId, slug });
    }
    return res.redirect("/admin/awards/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    let { id, name, keywords, date, desc, canceled, cReason, cityID, dId } = req.body;
    if(!accessManagement.check(req.admin,"AWARD","EDIT")) return res.redirect("/admin/awards?code=-10")
    if (!id || !dId) {
      return res.redirect("/admin/awards/form/?code=-1");
    }

    let award = await Award.findById(id);
    if (!award) {
      return res.redirect("/admin/awards/form/?code=-2");
    }
    const festivalDate = await Dates.findById(dId, "festival");
    if (festivalDate) {
      award.fId = festivalDate.festival.id;
    } else {
      award.fId = null;
    }

    const city = await getCity(cityID);
    if (name != award.name) {
      award.slug = await uniqueSlug(Award, name);
    }
    award.name = name;
    award.keywords = keywords;
    award.date =(date)? date+"z":date
    award.desc = desc;
    award.canceled = Boolean(canceled === "on");
    award.cReason = cReason;
    award.city = city;
    award.dId = dId;
    award.markModified("cats");
    await award.save();

    return res.redirect(`/admin/awards/form?id=${award._id}&code=200`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"AWARD","DELETE")) return res.redirect("/admin/awards?code=-10")
    const award = await Award.findById(id, "cats");
    if (!award) {
      return res.redirect("/admin/awards/?code=-1");
    }
    for (let cat of award.cats) {
      if (cat.img) {
        await file.delete(cat.img.path, imgaesPrefix);
      }
    }
    await Award.deleteOne({ _id: id });
    await Vote.deleteMany({ docID: id, docType: "award" });
    return res.redirect("/admin/awards/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/awards/?code=-1");
    }

    await Award.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/awards/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/category/create", upload.any(), async function (req, res, next) {
  try {
    let { awardId, title, tag, desc } = req.body;
    const positions = await getPositions(req.body, req.files);
    if(awardId && !accessManagement.check(req.admin,"AWARD","EDIT"))return res.redirect("/admin/awards?code=-10")
    if (!Array.isArray(tag)) tag = Array(tag);
    await Award.updateOne(
      { _id: awardId },
      {
        $push: {
          cats: {
            title,
            tag,
            desc,
            positions,
            agree: 0,
            disagree: 0,
            notsure: 0,
            comments: [],
          },
        },
      }
    );
    return res.redirect(`/admin/awards/form?code=200&id=${awardId}`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/category/update", upload.any(), async function (req, res, next) {
  try {
    var { awardId, index, title, tag, desc } = req.body;
    if(awardId && !accessManagement.check(req.admin,"AWARD","EDIT"))return res.redirect("/admin/awards?code=-10")
    let award = await Award.findById(awardId, "_id cats");
    if (!Array.isArray(tag)) tag = Array(tag);
    if (award) {
      let cats = award.cats;
      if (cats[index]) {
        cats[index].positions = await updatePositions(cats[index].positions, req.body, req.files);
        cats[index].title = title;
        cats[index].tag = tag;
        cats[index].desc = desc;
        await Award.updateOne({ _id: awardId }, { cats });
      }
    }
    return res.redirect(`/admin/awards/form?code=200&id=${awardId}`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/category/delete", async function (req, res, next) {
  try {
    const { id, index } = req.query;
    if(id && !accessManagement.check(req.admin,"AWARD","EDIT"))return res.redirect("/admin/awards?code=-10")
    var categories = await Award.findById(id, "cats");
    categories = categories.cats;
    var category = categories[index];
    if (category) {
      if (category.positions) {
        category.positions.map(async (position) => {
          if (position.img) {
            await file.delete(position.img.path, imgaesPrefix);
          }
        });
      }
      categories.splice(index, 1);
      await Award.updateOne({ _id: id }, { cats: categories });
    }
    return res.redirect(`/admin/awards/form?code=200&id=${id}`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

async function getCity(id) {
  if (!id) return null;
  const city = await City.findByIdAndDeleteAt({ id });
  if (!city) return null;
  return { id: city.id, name: city.name };
}

async function getPositions(data, images) {
  const names = Array.isArray(data.name) ? data.name : [data.name];
  const positions = Array.isArray(data.position) ? data.position : [data.position];
  const bands = Array.isArray(data.bands) ? data.bands : [data.bands];
  const texts = Array.isArray(data.text) ? data.text : [data.text];
  let result = [];
  for (let counter in names) {
    let image;
    if (names[counter] && positions[counter]) {
      if (images[counter]) {
        image = await file.save(images[counter], imgaesPrefix);
      }
      result.push({
        name: names[counter],
        position: positions[counter],
        bands: await BandDate.find({ _id: bands[counter] }, "_id name slug"),
        text: texts[counter],
        img: (image && image[0]) || null,
      });
    }
  }
  result.sort((current, next) => current.position - next.position);
  return result;
}

async function updatePositions(oldData, data, images) {
  const count = oldData && oldData.length;
  let result = [];
  for (let index = 0; index < count; index++) {
    let oldPosition = oldData[index];
    const name = data[`name${index}`];
    const position = data[`position${index}`];
    var bands = Array.isArray(data[`bands${index}`]) ? data[`bands${index}`] : [data[`bands${index}`]];

    const text = data[`text${index}`];

    if (name || position || bands[0]) {
      oldPosition.name = name;
      oldPosition.position = position;
      oldPosition.bands = await BandDate.find({ _id: bands }, "_id name slug");
      oldPosition.text = text;
      let image = images.filter((f) => f.fieldname == `img${index}`);
      if (image.length > 0) {
        if (oldPosition.img) {
          await file.delete(oldPosition.img.path, imgaesPrefix);
        }
        image = await file.save(image, imgaesPrefix);
        oldPosition.img = image[0];
      } else if (oldPosition.img && !data[`imgPath${index}`]) {
        await file.delete(oldPosition.img.path, imgaesPrefix);
        oldPosition.img = null;
      }
      result.push(oldPosition);
    } else if (oldPosition.img) {
      await file.delete(oldPosition.img.path, imgaesPrefix);
    }
  }
  const newPositions = await getPositions(
    data,
    images.filter((f) => f.fieldname == "img")
  );
  result = result.concat(newPositions);
  result.sort((current, next) => current.position - next.position);
  return result;
}

module.exports = router;
