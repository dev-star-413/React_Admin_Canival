const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const file = require("../services/file");
const helpers = require("../services/helpers");
const { Designer } = require("../models/Designer");
const { FestivalYear } = require("../models/FestivalYear");
const { Blog } = require("../models/Blog");
const { City } = require("../models/City");
const { Section } = require("../models/Section");
const { uploads } = require("../config")();
const imagesPrefix = "designerImages";
const { Types } = require("mongoose");
const accessManagement = require("../services/accessManagement");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if (!accessManagement.check(req.admin, "DESIGNER", "INDEX")) return res.redirect("/admin?code=-10");
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const designers = await Designer.find({ deleteAt: null });
    for (let designer of designers) {
      const festivalYear = await FestivalYear.findById(designer.fyID);
      if (festivalYear) {
        designer.viewLink = {
          url: `/admin/festivals/form?id=${festivalYear.festival.id}`,
          title: `${festivalYear.festival.name} - ${festivalYear.year}`,
        };
      } else {
        designer.viewLink = {};
      }
    }
    return res.view("designers/list", { operationResult, designers });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if (id && !accessManagement.check(req.admin, "DESIGNER", "EDIT")) return res.redirect("/admin/designers?code=-10");
    if (!id && !accessManagement.check(req.admin, "DESIGNER", "ADD")) return res.redirect("/admin/designers?code=-10");

    var designer = await Designer.findByIdAndDeleteAt({ id });
    const cities = await City.find({}, "_id name country");
    if (designer && designer.img) {
      designer.img.path = `${uploads.designerImages}/${designer.img.path}`;
    }
    return res.view("designers/form", {
      operationResult: { code },
      designer,
      cities,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    const { name, city, about, coName } = req.body;
    if (!accessManagement.check(req.admin, "DESIGNER", "ADD")) return res.redirect("/admin/designers?code=-10");
    if (!name) {
      return res.redirect("/admin/designers/form/?code=-1");
    }

    let img = req.files;
    if (img && img.length > 0) {
      img = await file.save(img[0], imagesPrefix);
      img = img[0];
    } else {
      img = null;
    }

    await Designer.create({
      name,
      city,
      img,
      about,
      coName,
      slug: await helpers.uniqueSlug(Designer, name),
    });
    return res.redirect("/admin/designers/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    const { id, name, city, about, imgPath, coName } = req.body;
    if (!accessManagement.check(req.admin, "DESIGNER", "EDIT")) return res.redirect("/admin/designers?code=-10");
    if (!id || !name) {
      return res.redirect("/admin/designers/form/?code=-1");
    }

    let designer = await Designer.findById(id);
    if (!designer) {
      return res.redirect("/admin/designers/form/?code=-2");
    }

    if (designer.name != name) {
      designer.slug = await helpers.uniqueSlug(Designer, name);
      await updateNameAndSlugDependencies(designer.id, name, designer.slug);
    }

    // let imgsFromDB = designer.imgs;
    // let imgsToDB = [];

    // for (let i in imgsFromDB) {
    //   const imgInDB = imgsFromDB[i];
    //   const paramName = "oldFiles_" + imgInDB.path.split("/").pop().split(".")[0];
    //   const imgInReq = req.files.find((file) => file.fieldname === paramName);
    //   if (imgInReq) {
    //     // keep this image
    //     imgsToDB.push(imgInDB);
    //   } else {
    //     // delete this image
    //     await file.delete(imgInDB.path, "designerImages");
    //   }
    // }

    // if (req.files) {
    //   let newImgs = await file.save(
    //     req.files.filter((file) => file.fieldname === "imgs"),
    //     "designerImages"
    //   );
    //   imgsToDB = imgsToDB.concat(newImgs);
    // }

    // designer.imgs = imgsToDB;
    // designer.markModified("imgs");
    designer.name = name;
    designer.city = city;
    designer.about = about;
    designer.coName = coName;

    // update designer images
    if (req.files && req.files.length > 0) {
      if (designer.img && designer.img.path) {
        await file.delete(designer.img.path, imagesPrefix);
      }
      let newImage = await file.save(req.files[0], imagesPrefix);
      designer.img = newImage[0];
    } else if (!imgPath && designer.img) {
      await file.delete(designer.img.path, imagesPrefix);
      designer.img = null;
    }

    await designer.save();
    // update designer info in other tables
    // update Designer info in Sections

    return res.redirect("/admin/designers/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!accessManagement.check(req.admin, "DESIGNER", "DELETE")) return res.redirect("/admin/designers?code=-10");
    if (!id) {
      return res.redirect("/admin/designers/?code=-1");
    }

    const designer = await Designer.findOneAndDelete({ _id: id });
    if (designer.img) {
      await file.delete(designer.img.path, imagesPrefix);
    }
    await Section.updateMany({ "designers._id": id }, { $pull: { designers: { _id: designer._id } } });
    await Blog.updateMany({ "designers.id": id }, { $pull: { designers: { id: designer._id } } });
    return res.redirect("/admin/designers/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/designers/?code=-1");
    }

    await Designer.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/designers/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;

async function updateNameAndSlugDependencies(designerID, newDesignerName, newDesignerSlug) {
  await Blog.updateMany(
    { "designers._id": Types.ObjectId(designerID) },
    { $set: { "designers.$.name": newDesignerName, "designers.$.slug": newDesignerSlug } }
  );
  await Section.updateMany(
    { "designers._id": Types.ObjectId(designerID) },
    { $set: { "designers.$.name": newDesignerName, "designers.$.slug": newDesignerSlug } }
  );
}
