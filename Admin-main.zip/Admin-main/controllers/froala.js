const express = require("express");
const multer = require("multer");
const router = express.Router();
const upload = multer();
const file = require("../services/file");
const config = require("../config")();
router.get("/", async function (req, res, next) {
  try {
    let files = await file.readDirectory("other");
    if (files && files[0]) {
      files = files.map((file) => {
        let object = {
          url: config.imgUrl + "other/0/0/c/" + file,
          thumb: config.imgUrl + "other/200/200/c/" + file,
          // name:file
          tag: "floara dance",
        };
        return object;
      });
    }
    return res.json(files);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/upload", upload.any(), async function (req, res, next) {
  try {
    var files = req.files;
    let imgs;
    if (files && files[0]) {
      imgs = await file.save(files, "other");
    }
    //save to data base
    var link = imgs && imgs[0].name;
    link = config.imgUrl + "/other/0/0/c/" + link;
    return res.json({ code: 0, link });
  } catch (err) {
    return next(err, req, res, next);
  }
});
router.post("/remove", async function (req, res, next) {
  try {
    var params = req.body;
    var src = params.src;
    if (!src) return res.json({ code: -1, msg: "other" });
    let nameFile = src.split("/").pop();
    await file.delete(nameFile, "other");
    return res.json({ code: 0, msg: "success" });
  } catch (err) {
    return next(err, req, res, next);
  }
});
module.exports = router;
