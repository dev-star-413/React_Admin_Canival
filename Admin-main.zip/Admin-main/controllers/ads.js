const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const file = require("../services/file");
const { Ad } = require("../models/Ad");
const accessManagement = require("../services/accessManagement");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(! accessManagement.check(req.admin,"ADVERTISMENT","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted.`; //`The record has been deleted. <a href="${undo}">Undo</a>`;
    }
    const ads = await Ad.find({ deleteAt: null });
    return res.view("ads/list", { operationResult, ads });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if(id && !accessManagement.check(req.admin,"ADVERTISMENT","EDIT"))return res.redirect("/admin/ads?code=-10")
    if(! id && ! accessManagement.check(req.admin,"ADVERTISMENT","ADD")) return res.redirect("/admin/ads?code=-10")
    const ad = await Ad.findByIdAndDeleteAt({ id });
    if (ad && ad.imgs) {
      for (let img of ad.imgs) {
        img.paramName = "oldFiles_" + img.path.split("/").pop().split(".")[0];
      }
    }

    return res.view("ads/form", { operationResult: { code }, ad });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let { title, pages,nodes,text,code,startDate,endDate } = req.body;
    if(! accessManagement.check(req.admin,"ADVERTISMENT","ADD")) return res.redirect("/admin/ads?code=-10")
    let imgs = [];
    if (req.files) {
      imgs = await file.save(
        req.files.filter((file) => file.fieldname === "imgs"),
        "adsImages"
      );
    }
    if(nodes && !Array.isArray(nodes) && typeof nodes=='string') nodes=[nodes] 
    if(pages && !Array.isArray(pages) && typeof pages=='string') pages=[pages] 

    await Ad.create({  title, pages,nodes,text,code,startDate,endDate });
    return res.redirect("/admin/ads/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    let { id, title,  pages,nodes,text,code,startDate,endDate } = req.body;
    if(! accessManagement.check(req.admin,"ADVERTISMENT","EDIT")) return res.redirect("/admin/ads?code=-10")
    if (!id) {
      return res.redirect("/admin/ads/form/?code=-1");
    }

    let ad = await Ad.findById(id);
    if (!ad) {
      return res.redirect("/admin/ads/form/?code=-2");
    }

    let imgsFromDB = ad.imgs;
    let imgsToDB = [];

    for (let i in imgsFromDB) {
      const imgInDB = imgsFromDB[i];
      const paramName = "oldFiles_" + imgInDB.path.split("/").pop().split(".")[0];
      const imgInReq = req.files.find((file) => file.fieldname === paramName);
      if (imgInReq) {
        // keep this image
        imgsToDB.push(imgInDB);
      } else {
        // delete this image
        await file.delete(imgInDB.path, "adsImages");
      }
    }

    if (req.files) {
      let newImgs = await file.save(
        req.files.filter((file) => file.fieldname === "imgs"),
        "adsImages"
      );
      imgsToDB = imgsToDB.concat(newImgs);
    }
    if(nodes && !Array.isArray(nodes) && typeof nodes=='string') nodes=[nodes] 
    if(pages && !Array.isArray(pages) && typeof pages=='string') pages=[pages] 
    console.log(pages)
    ad.imgs = imgsToDB;
    ad.title = title;
    ad.pages = pages;
    ad.nodes = nodes;
    ad.text = text;
    ad.code = code;
    ad.startDate = startDate;
    ad.endDate = endDate;

    await ad.save();

    return res.redirect("/admin/ads/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(! accessManagement.check(req.admin,"ADVERTISMENT","DELETE")) return res.redirect("/admin/ads?code=-10")
    if (!id) {
      return res.redirect("/admin/ads/?code=-1");
    }

    await Ad.deleteOne({ _id: id });
    return res.redirect("/admin/ads/?code=205");
    // await Ad.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    // return res.redirect(
    //   "/admin/ads/?code=205&undo=" + encodeURIComponent("/admin/ads/undoDelete?id=" + id)
    // );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/ads/?code=-1");
    }

    await Ad.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/ads/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
