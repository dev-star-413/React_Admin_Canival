const express = require("express");
const router = express.Router();
const config = require("../config")();
const accessManagement=require("../services/accessManagement")
const { User } = require("../models/User");
const { Comment } = require("../models/Comment");
const { BandDate } = require("../models/BandDate");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"USER","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const users = await User.find({ deleteAt: null });
    return res.view("users/list", { config, users });
  } catch (err) {
    console.error(err)
    return next(err, req, res, next);
  }
});

router.get("/verifyorganize", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"USER","VERIFY_ORGANIZER")) return res.redirect("/admin?code=-10")
    var user = await User.findById(id);
    if (!user) return res.json({ code:1,msg:"User not Found!"})
    await User.updateOne({ _id: id }, { $set: { organizeBand:{...user.organizeBand,isVerify:true} } });
    var userComments=await Comment.find({userId:id,collName:"band"})
    if(userComments && userComments[0]){
      for(let com of userComments){
        let bandDates=await BandDate.find({_id:com.docID,bandId:user.organizeBand._id})
        if(bandDates && bandDates[0]) await Comment.updateOne({_id:com._id},{isOrganizer:true})
      }
    }
    user = await User.findById(id);
    return res.json({ code:0,msg:"Verified!", data:user });
  } catch (err) {
    console.error(err)
    return res.json({ code:-1,msg:"Unknowm Error!", data:err });
  }
});

router.get("/removeorganize", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"USER","REMOVE_ORGANIZER")) return res.redirect("/admin?code=-10")
    var user = await User.findById(id);
    if (!user) return res.json({ code:1,msg:"User not Found!"})
    await User.updateOne({ _id: id }, { $unset: { organizeBand:1 } });
    await Comment.update({userId:id,collName:"band"},{$unset:{isOrganizer:1}})
    user = await User.findById(id);
    return res.json({ code:0,msg:"Removed!", data:user });
  } catch (err) {
    console.error(err)
    return res.json({ code:-1,msg:"Unknowm Error!", data:err });
  }
});

module.exports = router;
