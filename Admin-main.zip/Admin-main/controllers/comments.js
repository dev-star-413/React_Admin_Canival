const express = require("express");
const router = express.Router();

const { Comment } = require("../models/Comment");
const { FestivalYear } = require("../models/FestivalYear");
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    const { code, undo, typeFilter } = req.query;
    if(!accessManagement.check(req.admin,"COMMENT","INDEX") ) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been updated.`;
    } else if (code == 206) {
      operationResult.msg = `The record has been featured.`;
    }

    let comments = [];
    if (typeFilter) {
      comments = await Comment.find({ collName: typeFilter, deleteAt: null });
    } else {
      comments = await Comment.find({ deleteAt: null });
    }

    for (let comment of comments) {
      if (comment.collName === "festivalYear") {
        const festivalYear = await FestivalYear.findById(comment.docID);
        comment.viewLink = {
          url: `/admin/festivals/form?id${festivalYear.festival.id}`,
          title: "Festival",
        };
      } else if (comment.collName === "blog") {
        comment.viewLink = {
          url: `/admin/blogs/form?id${comment.docID}`,
          title: "Blog",
        };
      } else if (comment.collName === "band") {
        comment.viewLink = {
          url: `/admin/bands/form?id${comment.docID}`,
          title: "Band",
        };
      } else if (comment.collName === "event") {
        comment.viewLink = {
          url: `/admin/events/form?id${comment.docID}`,
          title: "Event",
        };
      }
    }

    return res.view("comments/list", { operationResult, comments, typeFilter });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/set", async function (req, res, next) {
  try {
    const { id, confirmed, featured } = req.query;
    if(featured && !accessManagement.check(req.admin,"COMMENT","SET_FEATURE") ) return res.redirect("/admin/comments?code=-10")
    if(confirmed && !accessManagement.check(req.admin,"COMMENT","SET_CONFIRM") ) return res.redirect("/admin/comments?code=-10")
    if (!id) {
      return res.redirect("/admin/comments/?code=-1");
    }
    let comment = await Comment.findById(id);
    if (!comment) {
      return res.redirect("/admin/comments/?code=-2");
    }

    if (typeof confirmed === "string") {
      comment.confirmedAt = confirmed === "1" ? new Date() : null;
    }
    if (typeof featured === "string") {
      comment.isFeatured = featured === "1";
    }
    await comment.save();

    return res.redirect("/admin/comments/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
