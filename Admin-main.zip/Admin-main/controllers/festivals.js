const express = require("express");
const router = express.Router();

const helpers = require("../services/helpers");
const { Festival } = require("../models/Festival");
const { Blog } = require("../models/Blog");
const { Dynamics } = require("../models/Dynamics");
const { Dates } = require("../models/Dates");
const { BandDate } = require("../models/BandDate");
const { Types } = require("mongoose");
const { City } = require("../models/City");
const accessManagement= require("../services/accessManagement");
const { uploads } = require("../config")();
const file = require("../services/file");
const multer = require("multer");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"FESTIVAL","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const festivals = await Festival.find({ deleteAt: null }, "name oName active type lPage onTop");
    return res.view("festivals/list", { operationResult, festivals });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code, fesId } = req.query;
    if(id &&!accessManagement.check(req.admin,"FESTIVAL","EDIT")) return res.redirect("/admin/festivals?code=-10")
    if(!id &&!accessManagement.check(req.admin,"FESTIVAL","ADD")) return res.redirect("/admin/festivals?code=-10")
    const festival = await Festival.findByIdAndDeleteAt({ id });
    const types = await Dynamics.findOne({}, "festivalTypes");

    if (festival) {
      for (let item of ['mainImage', 'evenImage', 'paradeImage', 'jouvertImage','childrenImage']) {
        festival[item] && festival[item].path ? festival[item].path = `${uploads.festivalImages}/${festival[item].path}` : {};
      }
    }

    let date = await Dates.findByIdAndDeleteAt({ id });
    var parent = {};
    if (date) {
      if (date.paradeGeo && date.paradeGeo.waypoints) {
          date.paradeWaypoints = [];
          for (let waypoint of date.paradeGeo.waypoints) {
              date.paradeWaypoints.push({
                  lat: waypoint.location[1],
                  lng: waypoint.location[0],
              });
          }
          delete date.paradeGeo;
      }
      if (date.img && date.img.path) {
          date.img.path = `${config.uploads.dateImages}/${date.img.path}`;
      }
      if (date.pImg && date.pImg.path) date.pImg.path = `${config.uploads.dateImages}/${date.pImg.path}`;
      if (date.jImg && date.jImg.path) date.jImg.path = `${config.uploads.dateImages}/${date.jImg.path}`;
    } else if (fesId) {
      parent = await Festival.findById(fesId);
    }

    return res.view("festivals/form", {
      operationResult: { code },
      date,
      cities: await City.find({}, "_id name region country latlng").sort(),
      festival,
      types: types.festivalTypes,
      parent: parent,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", multer().any(), async function (req, res, next) {
  try {
    let {
      name,
      oName,
      desc,
      about,
      history,
      socialK,
      socialV,
      active,
      type,
      meta,
      heading,
      keyWord,
      //-----
      introText,
      city,
      price,
      theme,
      jouvertAddress,
      paradeDesc,
      costume,
      result,
      guide,
      event,
      review,
      whereToStay,
      jouvert,
      childrenParadeAddress,
      childrenDesc,
      paradeLocation,

    } = req.body;

    let {mainImage, evenImage, paradeImage, jouvertImage,childrenImage} = [];
    if (req.files && req.files[0]) {
      mainImage = await file.save(
          req.files.filter((file) => file.fieldname === "mainImage"),
          'festivalImages'
      );
      evenImage = await file.save(
          req.files.filter((file) => file.fieldname === "evenImage"),
          "festivalImages"
      );
      paradeImage = await file.save(
          req.files.filter((file) => file.fieldname === "paradeImage"),
          "festivalImages"
      );
      jouvertImage = await file.save(
          req.files.filter((file) => file.fieldname === "jouvertImage"),
          "festivalImages"
      );
      childrenImage = await file.save(
        req.files.filter((file) => file.fieldname === "childrenImage"),
        "festivalImages"
    );
    }

    mainImage && mainImage[0] ? mainImage = mainImage[0] : {};
    evenImage && evenImage[0] ? evenImage = evenImage[0] : {};
    paradeImage && paradeImage[0] ? paradeImage = paradeImage[0] : {};
    jouvertImage && jouvertImage[0] ? jouvertImage = jouvertImage[0] : {};
    childrenImage && childrenImage[0] ? childrenImage = childrenImage[0] : {};

    if(!accessManagement.check(req.admin,"FESTIVAL","ADD")) return res.redirect("/admin/festivals?code=-10")
    if (!name) {
      return res.redirect("/admin/festivals/form/?code=-1");
    }

    active = Boolean(active === "on");

    const social = getSocial(socialK, socialV);

    const finalSlug = await helpers.uniqueSlug(Festival, name);

    await Festival.create({
      name,
      oName,
      desc,
      about,
      history,
      social,
      type,
      active,
      slug: finalSlug,
      meta,
      heading,
      keyWord,
      //-----
      introText,
      city,
      price,
      theme,
      jouvertAddress,
      paradeDesc,
      costume,
      result,
      guide,
      event,
      review,
      whereToStay,
      mainImage,
      evenImage,
      paradeImage,
      jouvertImage,
      jouvert,
      childrenParadeAddress,
      childrenDesc,
      paradeLocation,
      childrenImage
    });

    return res.redirect("/admin/festivals/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", multer().any(), async function (req, res, next) {
  try {
    let {
      id,
      name,
      oName,
      desc,
      about,
      history,
      socialK,
      socialV,
      type,
      active,
      meta,
      heading,
      keyWord,
      introText,
      city,
      price,
      theme,
      jouvertAddress,
      mainImgPath,
      evenImgPath,
      paradeImgPath,
      jouvertImgPath,
      paradeDesc,
      costume,
      result,
      guide,
      event,
      review,
      whereToStay,
      jouvert,
      childrenParadeAddress,
      childrenDesc,
      paradeLocation,
      childrenImgPath
    } = req.body;
    if(!accessManagement.check(req.admin,"FESTIVAL","EDIT")) return res.redirect("/admin/festivals?code=-10")
    if (!id || !name) {
      return res.redirect("/admin/festivals/form/?code=-1");
    }

    let festival = await Festival.findById(id);
    if (!festival) {
      return res.redirect("/admin/festivals/form/?code=-2");
    }
    const festivalOldName = festival.name;

    active = Boolean(active === "on");

    const social = getSocial(socialK, socialV);

    festival.name = name;
    festival.oName = oName;
    festival.desc = desc;
    festival.about = about;
    festival.history = history;
    festival.social = social;
    festival.markModified("social");
    festival.type = type;
    festival.active = active;
    festival.markModified("features");
    festival.meta = meta;
    festival.heading = heading;
    festival.keyWord = keyWord;
    festival.introText = introText;
    festival.city = city;
    festival.price = price;
    festival.theme = theme;
    festival.jouvertAddress = jouvertAddress;
    festival.paradeDesc=paradeDesc
    festival.costume=costume
    festival.result=result
    festival.guide=guide
    festival.event=event
    festival.review=review
    festival.whereToStay=whereToStay
    festival.jouvert=jouvert
    festival.childrenParadeAddress=childrenParadeAddress
    festival.childrenDesc=childrenDesc
    festival.paradeLocation=paradeLocation

    

    for (let item of [
      {0: 'mainImage', 1: mainImgPath}, {0: 'evenImage', 1: evenImgPath},
      {0: 'paradeImage', 1: paradeImgPath}, {0: 'jouvertImage', 1: jouvertImgPath},
      {0: 'childrenImage', 1: childrenImgPath}
    ]){
      if (!item[1] && festival[item[0]] && festival[item[0]].path) {
        await file.delete(festival[item[0]].path, 'festivalImages')[0];
        festival[item[0]] = null;
      }
      if (req.files && req.files.length > 0) {
        if (req.files.filter((file) => file.fieldname === item[0]).length > 0) {
          festival[item[0]] && festival[item[0]].path ? await file.delete(festival[item[0]].path, 'festivalImages') : {};
          let newImage = await file.save(
              req.files.filter((file) => file.fieldname === item[0]),
              'festivalImages'
          );
          festival[item[0]] = newImage[0];
        }
      }
    }

    if (festivalOldName !== festival.name) {
      festival.slug = await helpers.uniqueSlug(Festival, name);
    }
    await festival.save();

    if (festivalOldName !== festival.name) {
      await updateNameAndSlugDependencies(festival.id, festival.name, festival.slug);
    }

    return res.redirect("/admin/festivals/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"FESTIVAL","DELETE")) return res.redirect("/admin/festivals?code=-10")
    if (!id) {
      return res.redirect("/admin/festivals/?code=-1");
    }

    await Festival.deleteOne({ _id: id });
    return res.redirect("/admin/festivals/?code=205");
    // await Festival.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    // return res.redirect(
    //   "/admin/festivals/?code=205&undo=" +
    //   encodeURIComponent("/admin/festivals/undoDelete?id=" + id)
    // );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/festivals/?code=-1");
    }

    await Festival.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/festivals/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});
router.post("/update/landing-page", async function (req, res, next) {
  try {
    const { id, lPage } = req.body;
    if (!id) {
      return res.json({code:-1,message:"Failed"});
    }
    await Festival.updateOne({ _id: id }, { lPage:lPage });
    return res.json({code:0,msg:"success"});
  } catch (err) {
    return res.json({code:-1,msg:err.message})
  }
});
router.post("/update/on-top", async function (req, res, next) {
  try {
    const { id, onTop } = req.body;

    if (!id) {
      return res.json({code:-1,message:"Failed"});
    }
    await Festival.updateOne({ _id: id }, { onTop:onTop });
    return res.json({code:0,msg:"success"});
  } catch (err) {
    return res.json({code:-1,msg:err.message})
  }
});

function getSocial(socialK, socialV) {
  if (!Array.isArray(socialK)) {
    socialK = [socialK];
  }
  if (!Array.isArray(socialV)) {
    socialV = [socialV];
  }
  let social = [];
  for (let i = 0; i < socialK.length; i++) {
    if (socialK[i] && socialV[i]) {
      social.push({ k: socialK[i], v: socialV[i] });
    }
  }

  return social;
}

async function updateNameAndSlugDependencies(festivalID, newFestivalName, newFestivalSlug) {
  await Blog.updateMany(
    { "festivals._id": Types.ObjectId(festivalID) },
    { $set: { "festivals.$.name": newFestivalName, "festivals.$.slug": newFestivalSlug } }
  );
  await Dates.updateMany(
    { "festival.id": festivalID },
    { $set: { "festival.name": newFestivalName } }
  );
  await BandDate.updateMany({ dateId: festivalID }, { $set: { dateName: newFestivalName } });
}

module.exports = router;
