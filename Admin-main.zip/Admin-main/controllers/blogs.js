const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const moment = require("moment");

const blogCats = require("../config/blogCats");
const file = require("../services/file");
const helpers = require("../services/helpers");
const { Blog } = require("../models/Blog");
const { Band } = require("../models/Band");
const { Festival } = require("../models/Festival");
const { Designer } = require("../models/Designer");
const { City } = require("../models/City");
const config = require("../config")();
const accessManagement = require("../services/accessManagement");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if (!accessManagement.check(req.admin, "BLOG", "INDEX")) return res.redirect("/admin?code=-10");
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const blogs = await Blog.find({ deleteAt: null });
    return res.view("blogs/list", { operationResult, blogs });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if (id && !accessManagement.check(req.admin, "BLOG", "EDIT")) return res.redirect("/admin/blogs?code=-10");
    if (!id && !accessManagement.check(req.admin, "BLOG", "ADD")) return res.redirect("/admin/blogs?code=-10");
    const bands = await Band.find({ deleteAt: null });
    const festivals = await Festival.find({ deleteAt: null });
    const designers = await Designer.find({ deleteAt: null });
    const cities = await City.find({ deleteAt: null });
    var blog = await Blog.findByIdAndDeleteAt({ id });
    if (id && blog && blog.img) {
      blog.img.path = `${config.uploads.blogImages}/${blog.img.path}`;
    }
    return res.view("blogs/form", {
      operationResult: { code },
      blog: blog,
      bands,
      festivals,
      designers,
      cities,
      blogCats,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.single("img"), async function (req, res, next) {
  try {
    let {
      title,
      author,
      pDate,
      cats,
      meta,
      imgt,
      desc,
      artists,
      cityIDs,
      festivalIDs,
      bandIDs,
      designerIDs,
      keys,
      isTop,
      isFeature,
      isMain,
      rLink,
      view,
    } = req.body;
    festivalIDs = festivalIDs && festivalIDs.split(",");
    bandIDs = bandIDs && bandIDs.split(",");
    cityIDs = cityIDs && cityIDs.split(",");
    designerIDs = designerIDs && designerIDs.split(",");
    if (!accessManagement.check(req.admin, "BLOG", "ADD")) return res.redirect("/admin/blogs?code=-10");
    const cities = await getCities(cityIDs);
    if (cities === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    const festivals = await getFestivals(festivalIDs);
    if (festivals === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    const bands = await getBands(bandIDs);
    if (bands === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    const designers = await getDesigners(designerIDs);
    if (designers === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    let img = req.file;
    if (img) {
      img = await file.save(img, "blogImages");
      img = img[0];
    } else {
      img = null;
    }

    const finalSlug = await helpers.uniqueSlug(Blog, title);

    keys = keys.split(",");
    keys = keys.map((key) => {
      key = key.trim();
    });

    await Blog.create({
      title,
      author,
      pDate: pDate ? pDate + "z" : pDate,
      cats: Array.isArray(cats) ? cats : [cats],
      meta,
      desc,
      img,
      imgt,
      artists,
      cities,
      festivals,
      bands,
      designers,
      slug: finalSlug,
      keys,
      isTop: isTop === "on",
      isFeature: isFeature === "on",
      isMain: isMain === "on",
      rLink,
      view: view || 0,
    });
    return res.redirect("/admin/blogs/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.single("img"), async function (req, res, next) {
  try {
    var {
      id,
      title,
      author,
      pDate,
      rLink,
      cats,
      meta,
      desc,
      artists,
      cityIDs,
      festivalIDs,
      bandIDs,
      designerIDs,
      imgPath,
      imgt,
      keys,
      isTop,
      isFeature,
      isMain,
      view,
    } = req.body;
    festivalIDs = festivalIDs && festivalIDs.split(",");
    bandIDs = bandIDs && bandIDs.split(",");
    cityIDs = cityIDs && cityIDs.split(",");
    designerIDs = designerIDs && designerIDs.split(",");
    if (!accessManagement.check(req.admin, "BLOG", "EDIT")) return res.redirect("/admin/blogs?code=-10");
    if (!id) {
      return res.redirect("/admin/blogs/form/?code=-1");
    }

    const cities = await getCities(cityIDs);
    if (cities === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    const festivals = await getFestivals(festivalIDs);
    if (festivals === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    const bands = await getBands(bandIDs);
    if (bands === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    const designers = await getDesigners(designerIDs);
    if (designers === -2) {
      return res.redirect("/admin/blogs/form?code=-2");
    }

    let blog = await Blog.findById(id);
    if (!blog) {
      return res.redirect("/admin/blogs/form/?code=-2");
    }

    if (title !== blog.title) {
      blog.slug = await helpers.uniqueSlug(Blog, title);
    }

    blog.title = title;
    blog.rLink = rLink;
    blog.author = author;
    blog.pDate = pDate ? pDate + "z" : pDate;
    blog.cats = Array.isArray(cats) ? cats : [cats];
    let splitedKeys = keys.split(",");
    splitedKeys.map((key) => {
      return key.trim();
    });
    blog.keys = splitedKeys;
    blog.imgt = imgt;
    blog.meta = meta;
    blog.desc = desc;
    blog.artists = artists;
    blog.cities = cities;
    blog.festivals = festivals;
    blog.bands = bands;
    blog.designers = designers;
    blog.isTop = isTop === "on";
    blog.isFeature = isFeature === "on";
    blog.isMain = isMain === "on";
    blog.view = view || 0;

    // update blog image
    if (req.file) {
      if (blog.img && blog.img.path) {
        await file.delete(blog.img.path, "blogImages");
      }
      blog.img = await file.save(req.file, "blogImages");
      blog.img = blog.img[0];
    } else if (!imgPath && blog.img && blog.img.path) {
      await file.delete(blog.img.path, "blogImages");
      blog.img = null;
    }

    await Blog.updateOne({ _id: id }, blog);

    return res.redirect("/admin/blogs/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!accessManagement.check(req.admin, "BLOG", "DELETE")) return res.redirect("/admin/blogs?code=-10");
    if (!id) {
      return res.redirect("/admin/blogs/?code=-1");
    }
    const blog = await Blog.findOneAndDelete({ _id: id });
    if (blog.img && blog.img.path) {
      await file.delete(blog.img.path, "blogImages");
    }
    return res.redirect("/admin/blogs/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/blogs/?code=-1");
    }

    await Blog.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/blogs/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

async function getCities(cityIDs) {
  try {
    const cities = [];
    if (cityIDs) {
      if (!Array.isArray(cityIDs)) {
        cityIDs = [cityIDs];
      }
      for (let cityID of cityIDs) {
        const city = await City.findById(cityID, { id: 1, name: 1, slug: 1 });
        if (!city) {
          return -2;
        }
        cities.push(city);
      }
    }
    return cities;
  } catch (err) {
    throw err;
  }
}

async function getFestivals(festivalIDs) {
  try {
    const festivals = [];
    if (festivalIDs) {
      if (!Array.isArray(festivalIDs)) {
        festivalIDs = [festivalIDs];
      }
      for (let festivalID of festivalIDs) {
        const festival = await Festival.findById(festivalID, { id: 1, name: 1, slug: 1 });
        if (!festival) {
          return -2;
        }
        festivals.push(festival);
      }
    }
    return festivals;
  } catch (err) {
    throw err;
  }
}

async function getBands(bandIDs) {
  try {
    const bands = [];
    if (bandIDs) {
      if (!Array.isArray(bandIDs)) {
        bandIDs = [bandIDs];
      }
      for (let bandID of bandIDs) {
        const band = await Band.findById(bandID, { id: 1, name: 1, slug: 1 });
        if (!band) {
          return -2;
        }
        bands.push(band);
      }
    }
    return bands;
  } catch (err) {
    throw err;
  }
}

async function getDesigners(designerIDs) {
  try {
    const designers = [];
    if (designerIDs) {
      if (!Array.isArray(designerIDs)) {
        designerIDs = [designerIDs];
      }
      for (let designerID of designerIDs) {
        const designer = await Designer.findById(designerID, { id: 1, name: 1, slug: 1 });
        if (!designer) {
          return -2;
        }
        designers.push(designer);
      }
    }
    return designers;
  } catch (err) {
    throw err;
  }
}

module.exports = router;
