const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const moment = require("moment");
const imagesPrefix = "eventImages";
const file = require("../services/file");
const helpers = require("../services/helpers");
const { City } = require("../models/City");
const { EventTemp } = require("../models/EventTemp");
const { Event } = require("../models/Event");
const { Dates } = require("../models/Dates");
const { uploads } = require("../config")();
const fs = require('fs');
const accessManagement = require("../services/accessManagement");

router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"EVENT_TEMP","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const events = await EventTemp.find({ deleteAt: null });
    return res.view("eventTemps/list", { operationResult, events });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if(!id && !accessManagement.check(req.admin,"EVENT_TEMP","ADD")) return res.redirect("/admin/eventtemps?code=-10")
    if(id && !accessManagement.check(req.admin,"EVENT_TEMP","EDIT")) return res.redirect("/admin/eventtemps?code=-10")
    const event = await EventTemp.findByIdAndDeleteAt({ id });
    const cities = await City.find({ deleteAt: null }, "_id name region country currency");

    if (event && event.imgs) {
      for (let img of event.imgs) {
        img.path = `${uploads.eventImages}/${img.path}`;
      }
    }
    var currencies=new Set()
    var localCoin='USD'
    cities.map((city)=>{
      if(event && event.city && (city.id===event.city.id)) localCoin=city.currency
      if( city.currency) currencies.add(city.currency)
    })

    const festivalYears = await Dates.find({ deleteAt: null }, "_id festival year");

    return res.view("eventTemps/form", {
      operationResult: { code },
      event,
      cities,
      festivalYears,
      currencies,
      localCoin
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let {
      name,
      types,
      cityID,
      sDateD,
      sDateH,
      sDateM,
      dId,
      canceled,
      eDate,
      eDateH,
      eDateM,
      vName,
      vAddress,
      price,
      link,
      pitch,
      desc,
      mGenre,
      frequency,
      lat,
      lng,
      currency
    } = req.body;
    if (!name) {
      return res.redirect("/admin/eventtemps/form/?code=-1");
    }
    
    if(!accessManagement.check(req.admin,"EVENT_TEMP","ADD")) return res.redirect("/admin/eventtemps?code=-10")
    if(types && !Array.isArray(types)) types=[types]
    let sDate = sDateD
      ? moment(sDateD + " " + sDateH + sDateM, "YYYY-MM-DD HHmm").toDate()
      : null;
    eDate = eDate ? moment(eDate + " " + eDateH + eDateM, "YYYY-MM-DD HHmm").toDate() : null;
    const city = await getCity(cityID);

    let imgs = [];
    if (req.files) {
      imgs = await file.save(req.files, imagesPrefix);
    }
    let finalSlug = await helpers.uniqueSlug(Event, name);
    let location = {
      lat,
      lng,
    };
    await EventTemp.create({
      name,
      types:types || [],
      city,
      sDate,
      imgs,
      dId,
      canceled: Boolean(canceled == "on"),
      slug: finalSlug,
      pitch,
      desc,
      vName,
      vAddress,
      price,
      link,
      mGenre,
      frequency,
      eDate,
      location,
      state: {
        by: `${req.admin._id}`,
        at: new Date(),
      },
      currency
    });
    return res.redirect("/admin/eventtemps/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    let {
      id,
      name,
      types,
      cityID,
      sDateD,
      sDateH,
      sDateM,
      dId,
      canceled,
      vName,
      vAddress,
      price,
      link,
      pitch,
      desc,
      mGenre,
      frequency,
      eDate,
      eDateH,
      eDateM,
      lat,
      lng,
      existImg,
      currency
    } = req.body;
    if(!accessManagement.check(req.admin,"EVENT_TEMP","EDIT")) return res.redirect("/admin/eventtemps?code=-10")
    if (!id || !name) {
      return res.redirect("/admin/eventtemps/form/?code=-1");
    }
    if(types && !Array.isArray(types)) types=[types]

    let event = await EventTemp.findById(id);
    if (!event) {
      return res.redirect("/admin/eventtemps/form/?code=-2");
    }
    const eventOldName = event.name;
    let location = {
      lat,
      lng,
    };
    event.location = location;
    event.mGenre = mGenre;
    event.frequency = frequency;
    event.price = price;
    event.link = link;
    event.pitch = pitch;
    event.desc = desc;
    event.vName = vName;
    event.vAddress = vAddress;
    event.markModified("imgs");
    event.name = name;
    event.sDate = sDateD
      ? moment(sDateD + " " + sDateH + sDateM, "YYYY-MM-DD HHmm").toDate()
      : null;
    event.eDate = eDate
      ? moment(eDate + " " + eDateH + eDateM, "YYYY-MM-DD HHmm").toDate()
      : null;
    event.city = await getCity(cityID);
    event.dId = dId;
    event.canceled = Boolean(canceled == "on");
    event.types = types || []
    event.currency=currency
    if (eventOldName !== event.name) {
      event.slug = await helpers.uniqueSlug(Event, name);
    }
    if(!existImg){
      event.imgs=[]
    }
    let file=req.files && req.files[0]
    if(file && file.buffer){
      let buffer=file.buffer
      let base64=buffer.toString('base64')
      base64=`data:${file.mimetype};base64,${base64}`
      let data={
        data:base64,
        originalname:file.originalname,
        mimeType:file.mimetype
      }
      event.imgs=[data]
    }
    await EventTemp.updateOne({ _id: id }, event);

    return res.redirect("/admin/eventtemps/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"EVENT_TEMP","DELETE")) return res.redirect("/admin/eventtemps?code=-10")
    if (!id) {
      return res.redirect("/admin/eventtemps/?code=-1");
    }
    await EventTemp.deleteOne({ _id: id });
    return res.redirect("/admin/eventtemps/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/confirm", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"EVENT_TEMP","EDIT")) return res.redirect("/admin/eventtemps?code=-10")
    if (id) {
      const eventTemp = await EventTemp.findById(id);
      const slug = await helpers.uniqueSlug(Event, eventTemp.name);
      if (eventTemp) {
        var imgs=eventTemp.imgs && eventTemp.imgs[0]
        if(imgs && imgs.data){
          let base64=imgs.data
          let buffer=decodeBase64Image(base64)
          var data={
            buffer,
            originalname:imgs.originalname,
            mimetype:imgs.mimetype
          }
          imgs=await file.save([data],imagesPrefix)
        }

        await Event.create({
          name: eventTemp.name,
          slug,
          types: eventTemp.types,
          city: eventTemp.city,
          sDate: eventTemp.sDate,
          dId: eventTemp.dId,
          canceled: eventTemp.canceled,
          vName: eventTemp.vName,
          vAddress: eventTemp.vAddress,
          price: eventTemp.price,
          link: eventTemp.link,
          pitch: eventTemp.pitch,
          desc: eventTemp.desc,
          mGenre: eventTemp.mGenre,
          frequency: eventTemp.frequency,
          eDate: eventTemp.eDate,
          lat: eventTemp.lat,
          lng: eventTemp.lng,
          imgs: imgs,
          at: eventTemp.at,
          by: eventTemp.by,
          confirmed: true,
          confirmedBy: req.admin._id.toString(),
        });
      }
      return res.redirect(`/admin/eventtemps/delete?id=${id}`);
    }
    return res.redirect(`/admin/eventtemps/form?id=${id}`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/eventtemps/?code=-1");
    }

    await EventTemp.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/eventtemps/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;

async function getCity(id) {
  if (!id) return null;
  const city = await City.findByIdAndDeleteAt({ id });
  if (!city) return null;
  return { id: city.id, name: city.name };
}
function decodeBase64Image(dataString) {
  try {
    var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/)
    if (matches.length !== 3) {
      return new Error('Invalid input string');
    }
    var buffer = new Buffer(matches[2], 'base64');
  
    return buffer;
  } catch (error) {
    return new Error(error);
  }

}