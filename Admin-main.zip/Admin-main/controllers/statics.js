const express = require("express");
const router = express.Router();
const { Statics } = require("../models/Statics");
const { uniqueSlug } = require("../services/helpers");
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
    try {
        const { code } = req.query;
    if( !accessManagement.check(req.admin,"STATIC","INDEX")) return res.redirect("/admin?code=-10")
        let operationResult = { code };
        if (code == 205) {
            operationResult.msg = `The record has been deleted.`; //`The record has been deleted. <a href="${undo}">Undo</a>`;
        }
        return res.view("statics/list", {
            operationResult,
            statics: await Statics.find({}, "_id title slug client removable")
        })
    } catch (error) {
        return (error, req, res, next);
    }
})

router.get("/form", async function (req, res, next) {
    try {
        const { code, id } = req.query;
        if(id && !accessManagement.check(req.admin,"STATIC","EDIT")) return res.redirect("/admin/statics?code=-10")
        if(!id && !accessManagement.check(req.admin,"STATIC","ADD")) return res.redirect("/admin/statics?code=-10")
        return res.view("statics/form", {
            operationResult: { code },
            static: await Statics.findById(id),
        })
    } catch (error) {
        return (error, req, res, next);
    }
})

router.post("/create", async function (req, res, next) {
    try {
        const { title, content, client } = req.body;
        if( !accessManagement.check(req.admin,"STATIC","ADD")) return res.redirect("/admin/statics?code=-10")
        if (title && content) {
            await Statics.create({ slug: await uniqueSlug(Statics, title), client: Boolean(client == "on"), title, content, removable: true });
            return res.redirect("/admin/statics/?code=201");
        }
        return res.redirect("/admin/statics/form/?code=-1");
    } catch (error) {
        return (error, req, res, next);
    }
})

router.post("/update", async function (req, res, next) {
    try {
        const { id, title, content, client } = req.body;
        if( !accessManagement.check(req.admin,"STATIC","EDIT")) return res.redirect("/admin/statics?code=-10")
        if (id) {
            var page = await Statics.findById(id);
            if (page) {
                if (page.title != title) {
                    page.slug = await uniqueSlug(Statics, title)
                }
                page.title = title;
                page.content = content;
                page.client = Boolean(client == "on");
                await Statics.updateOne({ _id: id }, page);
                return res.redirect("/admin/statics/?code=200");
            }
            return res.redirect("/admin/trades/form/?code=-2");
        }
        return res.redirect("/admin/trades/form/?code=-1");
    } catch (error) {
        return (error, req, res, next);
    }
})

router.get("/delete", async function (req, res, next) {
    try {
        const { id } = req.query;
        if(!accessManagement.check(req.admin,"STATIC","DELETE")) return res.redirect("/admin/statics?code=-10")
        if (id) {
          const static = await Statics.findById(id);
          if(static.removable) {
            await Statics.deleteOne({ _id: id });
            return res.redirect("/admin/statics/?code=200");
          }
        }
        return res.redirect("/admin/statics/?code=-1");
    } catch (error) {
        return (error, req, res, next);
    }
})

module.exports = router;