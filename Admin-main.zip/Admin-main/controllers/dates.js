const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const moment = require("moment");
const fetch = require("node-fetch");

const file = require("../services/file");
const { Dates } = require("../models/Dates");
const { City } = require("../models/City");
const { Festival } = require("../models/Festival");
const { BandDate } = require("../models/BandDate");
const uniqueSlug = require("../services/helpers");
const config = require("../config")();
const accessManagement = require("../services/accessManagement");
const { Band } = require("../models/Band");
var mongoose = require('mongoose');
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "INDEX")) return res.redirect("/admin?code=-10");
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const dates = await Dates.find({ deleteAt: null });
    return res.view("dates/list", { operationResult, dates });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id, fesId } = req.query;
    if (id && !accessManagement.check(req.admin, "FESTIVAL_DATE", "EDIT")) return res.redirect("/admin/dates?code=-10");
    if (!id && !accessManagement.check(req.admin, "FESTIVAL_DATE", "ADD")) return res.redirect("/admin/dates?code=-10");
    let date = await Dates.findByIdAndDeleteAt({ id });
    var parent = {};
    // bands of date
    var bands=[]
    if (date) {
      if (date.paradeGeo && date.paradeGeo.waypoints) {
        date.paradeWaypoints = [];
        for (let waypoint of date.paradeGeo.waypoints) {
          date.paradeWaypoints.push({
            lat: waypoint.location[1],
            lng: waypoint.location[0],
          });
        }
        delete date.paradeGeo;
      }
      if (date.img && date.img.path) {
        date.img.path = `${config.uploads.dateImages}/${date.img.path}`;
      }
      if (date.pImg && date.pImg.path) date.pImg.path = `${config.uploads.dateImages}/${date.pImg.path}`;
      if (date.jImg && date.jImg.path) date.jImg.path = `${config.uploads.dateImages}/${date.jImg.path}`;
      if (date.eventImg && date.eventImg.path) date.eventImg.path = `${config.uploads.dateImages}/${date.eventImg.path}`;
      if (date.childrenImage && date.childrenImage.path) date.childrenImage.path = `${config.uploads.dateImages}/${date.childrenImage.path}`;
    } else if (fesId) {
      parent = await Festival.findById(fesId);
      bands=await Band.find({'festivals._id':mongoose.Types.ObjectId(fesId)},'name')
    }
    var newBands;
    if(id && date) {
      bands=await BandDate.find({dateId:date._id,year:date.year},'year name confirm bandId').lean()
      var listBands=[]
      bands.forEach((b)=>listBands.push(mongoose.Types.ObjectId(b.bandId)))
      newBands= await Band.find({'festivals._id':mongoose.Types.ObjectId(date.festival.id),_id:{$nin:listBands}},'name').lean()
    }
    return res.view("dates/form", {
      operationResult: { code },
      date,
      cities: await City.find({}, "_id name region country latlng").sort(),
      festivals: await Festival.find({}, "_id name").sort(),
      parent: parent,
      bands,
      newBands
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let {
      fId,
      tsk,
      paradeStartD,
      jouvertAddress,
      paradeEndD,
      paradeWaypoints,
      canceled,
      bestStartD,
      bestEndD,
      city,
      year,
      price,
      theme,
      desc,
      meta,
      // lPage,
      // top,
      imgTitle,
      paradeDesc,
      costume,
      result,
      guide,
      event,
      review,
      heading,
      keywords,
      whereToStay,
      jouvertStartDate,
      jouvertEndDate,
      jouvert,
      intro,
      bands,
      confirmedBands,
      //------------
      childrenStartD,
      childrenEndD,
      childrenParadeAddress,
      childrenDesc,
      paradeLocation,
      officialName,
      isActive
    } = req.body;
    if(bands)bands=bands.split(',')
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "ADD")) return res.redirect("/admin/dates?code=-10");
    let referer = req.get("referer");
    if(referer)referer = referer.split("?");
    referer = (referer && referer[1]) || "";
    if (!fId || !year) {
      return res.redirect(`/admin/dates/form?${referer ? referer + "&code=-1" : "code=-1"}`);
    }

    let bestS = bestStartD ? bestStartD + "z" : bestStartD;
    let bestE = bestEndD ? bestEndD + "z" : bestEndD;
    let paradeS = paradeStartD ? paradeStartD + "z" : paradeStartD;
    let paradeE = paradeEndD ? paradeEndD + "z" : paradeEndD;
    childrenStartD = childrenStartD ? childrenStartD + "z" : childrenStartD;
    childrenEndD = childrenEndD ? childrenEndD + "z" : childrenEndD;

    let img = req.files.filter((f) => f.fieldname == "img");
    if (img[0]) {
      img = await file.save(img, "dateImages");
      img = img[0];
    }
    let pImg = req.files.filter((f) => f.fieldname == "pImg");
    if (pImg[0]) {
      pImg = await file.save(pImg, "dateImages");
      pImg = pImg[0];
    }
    let jImg = req.files.filter((f) => f.fieldname == "jImg");
    if (jImg[0]) {
      jImg = await file.save(jImg, "dateImages");
      jImg = jImg[0];
    }
    let eventImg = req.files.filter((f) => f.fieldname == "eventImg");
    if (eventImg[0]) {
      eventImg = await file.save(eventImg, "dateImages");
      eventImg = eventImg[0];
    }
    let childrenImage = req.files.filter((f) => f.fieldname == "childrenImage");
    if (childrenImage[0]) {
      childrenImage = await file.save(childrenImage, "dateImages");
      childrenImage = childrenImage[0];
    }
    // lPage = Boolean(lPage === "on");
    // top = Boolean(top === "on");
    canceled = Boolean(canceled === "on");
    const festival = await Festival.findById(fId, "_id name");
    let createObj = {
      slug: await uniqueSlug.uniqueSlug(Dates, `${festival.name} ${year}`),
      festival: { id: festival._id, name: festival.name },
      tsk,
      heading,
      bestS,
      bestE,
      paradeS,
      paradeE,
      img,
      pImg,
      jImg,
      city,
      price,
      theme,
      desc,
      meta,
      // lPage,
      // top,
      year: Number.parseInt(year),
      canceled,
      imgTitle,
      paradeDesc,
      costume,
      result,
      guide,
      event,
      review,
      keywords,
      whereToStay,
      jouvertAddress,
      jouvertStartDate: jouvertStartDate ? jouvertStartDate + "z" : jouvertStartDate,
      jouvertEndDate: jouvertEndDate ? jouvertEndDate + "z" : jouvertEndDate,
      jouvert,
      intro,

      childrenStartD,
      childrenEndD,
      eventImg ,
      childrenImage,
      childrenParadeAddress,
      childrenDesc,
      paradeLocation,
      officialName,
      isActive:!!isActive
    };
    const paradeGeo = await createParadeGeo(paradeWaypoints);
    if (paradeGeo.code === 0) {
      createObj.paradeGeo = paradeGeo.data;
    }

    var newDate=await Dates.create(createObj);
    // generate auto band dates
      if(bands && bands[0]){
        for(var b of bands){
          let confirm=(confirmedBands && confirmedBands.includes(b))?1:0
          var band=await Band.findById(b,'name')
          if(band && band.lastYear && year > band.lastYear) await Band.update({_id:band._id},{lastYear:year})

          var data={
            name:band.name,
            bandId:b,
            year:year,
            dateId:newDate._id,
            dateName:festival.name,
            slug: await uniqueSlug.uniqueSlug(BandDate, `${band.name} ${year}`),
            confirm
          }
          await BandDate.create(data)
        }
      }
    return res.redirect("/admin/dates/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    var {
      id,
      fId,
      tsk,
      paradeStartD,
      paradeEndD,
      paradeWaypoints,
      canceled,
      bestStartD,
      bestEndD,
      city,
      price,
      year,
      theme,
      // lPage,
      // top,
      desc,
      meta,
      imgPath,
      pImgPath,
      jImgPath,
      imgTitle,
      paradeDesc,
      costume,
      result,
      guide,
      event,
      review,
      keywords,
      whereToStay,
      heading,
      jouvertAddress,
      jouvert,
      jouvertStartDate,
      jouvertEndDate,
      intro,
      confirmedBands,
      oldConfirmedBands,
      newBands,
      newConfirmedBands,
      childrenStartD,
      childrenEndD,
      childrenParadeAddress,
      childrenDesc,
      paradeLocation,
      childrenImgPath,
      evenImgPath,
      officialName,
      isActive
    } = req.body; 
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "EDIT")) return res.redirect("/admin/dates?code=-10");
    if (!id || !fId || !year) {
      return res.redirect("/admin/dates/?code=-1");
    }

    let dates = await Dates.findById(id);
    if (!dates) {
      return res.redirect("/admin/dates/?code=-2");
    }
    if(!Array.isArray(confirmedBands)) confirmedBands=Array(confirmedBands)
    if(oldConfirmedBands) oldConfirmedBands=oldConfirmedBands.split(',')
    // new bands
    if(newConfirmedBands && !Array.isArray(newConfirmedBands)) newConfirmedBands=Array(newConfirmedBands)
    if(newBands) newBands=newBands.split(',')
    
    // update date image
    let img = req.files.filter((f) => f.fieldname == "img");
    if (img[0]) {
      if (dates.img && dates.img.path) {
        await file.delete(dates.img.path);
      }
      const newImage = await file.save(img, "dateImages");
      dates.img = newImage[0];
    } else if (dates.img && !imgPath) {
      await file.delete(dates.img.path);
      dates.img = null;
      dates["imgTitle"] = null;
    }
    dates["imgTitle"] = imgTitle;
    let pImg = req.files.filter((f) => f.fieldname == "pImg");
    if (pImg[0]) {
      if (dates.pImg && dates.pImg.path) {
        await file.delete(dates.pImg.path);
      }
      const newImage = await file.save(pImg, "dateImages");
      dates.pImg = newImage[0];
    } else if (dates.pImg && !pImgPath) {
      await file.delete(dates.pImg.path);
      dates.pImg = null;
    }
    // jouvert image
    let jImg = req.files.filter((f) => f.fieldname == "jImg");
    if (jImg[0]) {
      if (dates.jImg && dates.jImg.path) {
        await file.delete(dates.jImg.path);
      }
      const newImage = await file.save(jImg, "dateImages");
      dates.jImg = newImage[0];
    } else if (dates.jImg && !jImgPath) {
      await file.delete(dates.jImg.path);
      dates.jImg = null;
    }
    // children image childrenImage
    let childrenImage = req.files.filter((f) => f.fieldname == "childrenImage");
    if (childrenImage[0]) {
      if (dates.childrenImage && dates.childrenImage.path) {
        await file.delete(dates.childrenImage.path);
      }
      const newImage = await file.save(childrenImage, "dateImages");
      dates.childrenImage = newImage[0];
    } else if (dates.childrenImage && !childrenImgPath) {
      await file.delete(dates.childrenImage.path);
      dates.childrenImage = null;
    }
    // event image
    let eventImg = req.files.filter((f) => f.fieldname == "eventImg");
    if (eventImg[0]) {
      if (dates.eventImg && dates.eventImg.path) {
        await file.delete(dates.eventImg.path);
      }
      const newImage = await file.save(eventImg, "dateImages");
      dates.eventImg = newImage[0];
    } else if (dates.eventImg && !evenImgPath) {
      await file.delete(dates.eventImg.path);
      dates.eventImg = null;
    }
    const festival = await Festival.findById(fId, "_id name");
    if (dates.festival.name != festival.name || dates.year != Number.parseInt(year)) {
      dates.slug = await uniqueSlug.uniqueSlug(Dates, `${festival.name} ${year}`);
    }
    dates.meta = meta;
    // dates.lPage = Boolean(lPage === "on");
    // dates.top = Boolean(top === "on");
    dates.canceled = Boolean(canceled === "on");

    // dates.img = imgsToDB;
    dates.markModified("img");
    dates.bestS = bestStartD ? bestStartD + "z" : bestStartD;
    dates.bestE = bestEndD ? bestEndD + "z" : bestEndD;
    dates.paradeS = paradeStartD ? paradeStartD + "z" : paradeStartD;
    dates.paradeE = paradeEndD ? paradeEndD + "z" : paradeEndD;
    dates.childrenStartD = childrenStartD ? childrenStartD + "z" : childrenStartD;
    dates.childrenEndD = childrenEndD ? childrenEndD + "z" : childrenEndD;
    dates.price = price;
    dates.theme = theme;
    dates.desc = desc;
    dates.tsk = tsk;
    dates.year = Number.parseInt(year);
    dates.city = city;
    dates.festival = { id: festival._id, name: festival.name };
    const paradeGeo = await createParadeGeo(paradeWaypoints);
    if (paradeGeo.code === 0) {
      dates.paradeGeo = paradeGeo.data;
    }
    dates.paradeDesc = paradeDesc;
    dates.costume = costume;
    dates.result = result;
    dates.event = event;
    dates.review = review;
    dates.guide = guide;
    dates.keywords = keywords;
    dates.whereToStay = whereToStay;
    dates.heading = heading;
    dates.jouvertAddress = jouvertAddress;
    dates.jouvertStartDate = jouvertStartDate ? jouvertStartDate + "z" : jouvertStartDate;
    dates.jouvertEndDate = jouvertEndDate ? jouvertEndDate + "z" : jouvertEndDate;
    dates.jouvert = jouvert;
    dates.intro = intro;
    dates.childrenParadeAddress=childrenParadeAddress;
    dates.childrenDesc=childrenDesc;
    dates.paradeLocation=paradeLocation;
    dates.officialName=officialName;
    dates.isActive=!!isActive
    await Dates.updateOne({ _id: id }, dates);

    //band confirm
    if(confirmedBands && confirmedBands[0]){
      
      for(let b of confirmedBands){
        if(!oldConfirmedBands.includes(b)){
          await BandDate.updateOne({_id:mongoose.Types.ObjectId(b)},{confirm:1})
        }
      }
    }
    // band change confirm
    if(oldConfirmedBands && oldConfirmedBands[0]){
      for(let b of oldConfirmedBands){
        if(!confirmedBands.includes(b)){
          await BandDate.updateOne({_id:mongoose.Types.ObjectId(b)},{confirm:0})
        }
      }
    }
    if(newBands && newBands[0]){
      // generate auto new bands
      for(var b of newBands){
        let confirm=(newConfirmedBands && newConfirmedBands.includes(b))?1:0
        var band=await Band.findById(b,'name')
        if(band && band.lastYear && year > band.lastYear) await Band.update({_id:band._id},{lastYear:year})

        var data={
          name:band.name,
          bandId:b,
          year:year,
          dateId:id,
          dateName:dates.name,
          slug: await uniqueSlug.uniqueSlug(BandDate, `${band.name} ${year}`),
          confirm
        }
        await BandDate.create(data)
      }
    }

    return res.redirect("/admin/dates/?code=200");
  } catch (err) {
    console.log(err)
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "DELETE")) return res.redirect("/admin/dates?code=-10");
    if (!id) {
      return res.redirect("/admin/dates/?code=-1");
    }
    const dateExists = await Dates.findOne({ _id: id }, "_id img");
    if (dateExists) {
      if (dateExists.img) {
        await file.delete(dateExists.img.path);
      }
      await Dates.deleteOne({ _id: id });
      return res.redirect("/admin/dates/?code=205");
    }
    return res.redirect("/admin/dates/?code=-1");
    // await Dates.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    // return res.redirect(
    //   "/admin/dates/?code=205&undo=" + encodeURIComponent("/admin/dates/undoDelete?id=" + id)
    // );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/dates/?code=-1");
    }

    await Dates.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/dates/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

// Travelers Should Know Controllers

router.post("/travel/create", async function (req, res, next) {
  try {
    const { date } = req.query;
    const { tsk } = req.body;
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "EDIT")) return res.redirect("/admin/dates?code=-10");
    const festivalDate = await Dates.findById(date);
    if (festivalDate) {
      festivalDate.tsk.push(tsk);
      await Dates.updateOne({ _id: date }, festivalDate);
      return res.redirect(`/admin/dates/form?id=${date}&code=200`);
    }
    return res.redirect(`/admin/dates/form`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/travel/update", async function (req, res, next) {
  try {
    const { date, index } = req.query;
    const { tsk } = req.body;
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "EDIT")) return res.redirect("/admin/dates?code=-10");
    var festivalDate = await Dates.findById(date);
    if (festivalDate) {
      festivalDate.tsk[index] = tsk;
      await Dates.updateOne({ _id: date }, festivalDate);
    }
    return res.redirect(`/admin/dates/form?id=${date}&code=200`);
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/travel/delete", async function (req, res, next) {
  try {
    const { date, index } = req.query;
    if (!accessManagement.check(req.admin, "FESTIVAL_DATE", "EDIT")) return res.redirect("/admin/dates?code=-10");
    var festivalDate = await Dates.findById(date);
    if (festivalDate && festivalDate.tsk) {
      festivalDate.tsk.splice(index, 1);
      await Dates.updateOne({ _id: date }, festivalDate);
    }
    return res.redirect(`/admin/dates/form?id=${date}&code=200`);
  } catch (err) {
    return err, req, res, next;
  }
});
router.post("/active",async function(req,res,next){
  try {
    var {id,isActive}=req.body
    console.log(typeof isActive)
    console.log(!!isActive)
    isActive=!!isActive
    if(!id) return res.json({code:1,msg:"Not found festival date"})
    var update=await Dates.updateOne({_id:mongoose.Types.ObjectId(id)},{isActive})
    if(update.n ==0)return res.json({code:2,msg:"Not found festival date"})
    return res.json({code:0,msg:"Success"})
  } catch (error) {
    console.log(error)
    return res.json({code:-1,msg:error.message})
  }
})
module.exports = router;

async function createParadeGeo(paradeWaypoints) {
  try {
    paradeWaypoints = JSON.parse(paradeWaypoints);
    let osrmQuery = "";
    for (let waypoint of paradeWaypoints) {
      osrmQuery += `${waypoint.lng},${waypoint.lat};`;
    }

    osrmQuery = osrmQuery.replace(/;$/gi, "");
    const osrmRes = await fetch(
      `https://routing.openstreetmap.de/routed-foot/route/v1/driving/${osrmQuery}?overview=false&steps=true&geometries=geojson&generate_hints=false`
    );
    const osrmResult = await osrmRes.json();
    if (osrmResult.code === "Ok") {
      return { code: 0, data: osrmResult };
    }
    return { code: 0, data: null };
  } catch (error) {
    return { code: -1, data: null };
  }
}
