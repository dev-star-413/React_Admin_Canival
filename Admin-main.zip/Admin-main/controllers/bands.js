const express = require("express");
const router = express.Router();

const multer = require("multer");
const { uploads } = require("../config")();
const file = require("../services/file");
const helpers = require("../services/helpers");
const { Band } = require("../models/Band");
const { Blog } = require("../models/Blog");
const { Designer } = require("../models/Designer");
const { User } = require("../models/User");
const { BandDate } = require("../models/BandDate");
const { Types } = require("mongoose");
const { deleteBandDateDependencies } = require("../services/deleteDependencies");
const accessManagement = require("../services/accessManagement");
const { Festival } = require("../models/Festival");
var mongoose = require('mongoose');

router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    let operationResult = { code };
    if (!accessManagement.check(req.admin, "BAND", "INDEX")) return res.redirect("/admin?code=-10");
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const bands = await Band.find({ deleteAt: null });
    return res.view("bands/list", { operationResult, bands });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if (id && !accessManagement.check(req.admin, "BAND", "EDIT")) return res.redirect("/admin/bands?code=-10");
    if (!id && !accessManagement.check(req.admin, "BAND", "ADD")) return res.redirect("/admin/bands?code=-10");

    const bands = await Band.find({ deleteAt: null });
    const users = await User.find({ deleteAt: null });
    const band = await Band.findByIdAndDeleteAt({ id });
    const festivals=await Festival.find({},'name')
    if (band && band.img) {
      band.img.path = `${uploads.bandImages}/${band.img.path}`;
    }

    return res.view("bands/form", {
      operationResult: { code },
      band,
      bands,
      users,
      festivals,
    });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", multer().any(), async function (req, res, next) {
  try {
    let { name, foundY, fNames, partners, about, users, unique ,festivalIDs,contactPhone,contactEmail} = req.body;
    if (!accessManagement.check(req.admin, "BAND", "ADD")) return res.redirect("/admin/bands?code=-10");
    if (!name) {
      return res.redirect("/admin/bands/form/?code=-1");
    }
    
    if (!Array.isArray(users)) {
      users = [users];
    }
    if (!Array.isArray(fNames)) {
      fNames = [fNames];
    }
    if (!Array.isArray(partners)) {
      partners = [partners];
    }
    festivalIDs = festivalIDs?.split(",");
    
    const usersFromDB = await User.find({ _id: { $in: users } }, { _id: 1, username: 1 });

    const fNamesFromDB = await Band.find({ _id: { $in: fNames } }, { _id: 1, name: 1 });

    const partnersFromDB = await Band.find({ _id: { $in: partners } }, { _id: 1, name: 1 });
    var festivals=[]
    if(festivalIDs[0]) festivals= await getFestivals(festivalIDs);

    let finalSlug = await helpers.uniqueSlug(Band, name);

    let img = req.files;
    if (img && img.length > 0) {
      img = await file.save(img[0], 'bandImages', {});
      img = img[0];
    } else {
      img = null;
    }

    await Band.create({
      name,
      foundY,
      fNames: fNamesFromDB,
      partners: partnersFromDB,
      about,
      users: usersFromDB,
      slug: finalSlug,
      unique,
      img,
      festivals,
      contactEmail,
      contactPhone
    });
    return res.redirect("/admin/bands/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", multer().any(), async function (req, res, next) {
  try {
    let { id, name, foundY, fNames, partners, about, users, unique, imgPath ,festivalIDs ,contactPhone,contactEmail} = req.body;
    if (!accessManagement.check(req.admin, "BAND", "EDIT")) return res.redirect("/admin/bands?code=-10");
    if (!id || !name) {
      return res.redirect("/admin/bands/form/?code=-1");
    }
    let band = await Band.findById(id);
    if (!band) {
      return res.redirect("/admin/bands/form/?code=-2");
    }
    const bandOldName = band.name;
    
    if (!Array.isArray(users)) {
      users = [users];
    }
    if (!Array.isArray(fNames)) {
      fNames = [fNames];
    }
    if (!Array.isArray(partners)) {
      partners = [partners];
    }
    
    festivalIDs = festivalIDs?.split(",");
    const usersFromDB = await User.find({ _id: { $in: users } }, { _id: 1, username: 1 });
    const fNamesFromDB = await Band.find({ _id: { $in: fNames } }, { _id: 1, name: 1 });
    const partnersFromDB = await Band.find({ _id: { $in: partners } }, { _id: 1, name: 1 });
    var festivals=[]
    if(festivalIDs[0]) festivals= await getFestivals(festivalIDs);
    band.name = name;
    band.foundY = foundY;
    band.users = usersFromDB;
    band.fNames = fNamesFromDB;
    band.partners = partnersFromDB;
    band.markModified("users");
    band.about = about;
    band.unique = unique;
    band.festivals = festivals;
    band.contactEmail=contactEmail;
    band.contactPhone=contactPhone

    if (bandOldName !== band.name) {
      band.slug = await helpers.uniqueSlug(Band, name);
    }

    if (req.files && req.files.length > 0) {
      if (band.img && band.img.path) {
        await file.delete(band.img.path, 'bandImages');
      }
      let newImage = await file.save(req.files[0], 'bandImages', {});
      band.img = newImage[0];
    } else if (!imgPath && band.img) {
      await file.delete(band.img.path, 'bandImages');
      band.img = null;
    }

    await band.save();

    if (bandOldName !== band.name) {
      await updateNameAndSlugDependencies(band.id, band.name, band.slug);
    }

    return res.redirect("/admin/bands/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!accessManagement.check(req.admin, "BAND", "DELETE")) return res.redirect("/admin/bands?code=-10");
    if (!id) {
      return res.redirect("/admin/bands/?code=-1");
    }

    await Band.deleteOne({ _id: id });
    const bandDates = await BandDate.find({ bandId: id }, "_id");
    for (const bandDate of bandDates) {
      await deleteBandDateDependencies(bandDate._id);
    }
    return res.redirect("/admin/bands/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/bands/?code=-1");
    }

    await Band.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/bands/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});
router.post("/filter",async function (req,res,next){
  try {
    const {fesId}=req.body
    if(!fesId) return res.json({code:-1,msg:"not found"})
    const bands=await Band.find({'festivals._id':mongoose.Types.ObjectId(fesId)},'name')
    return res.json({code:0,msg:"Success", data:bands})
   } catch (error) {
    return next(err, req, res, next);

  }
})

async function updateNameAndSlugDependencies(bandID, newBandName, newBandSlug) {
  await Band.updateMany({ "fNames.id": bandID }, { $set: { "fNames.$.name": newBandName } });
  await Band.updateMany({ "partners.id": bandID }, { $set: { "partners.$.name": newBandName } });
  // await BandDate.updateMany({ bandId: bandID }, { $set: { name: newBandName } }); This only makes things worse. It hides a lot more problems. Let the error shows itself
  await Designer.updateMany({ "band.id": bandID }, { $set: { "band.name": newBandName } });
  await Blog.updateMany(
    { "bands._id": Types.ObjectId(bandID) },
    { $set: { "bands.$.name": newBandName, "bands.$.slug": newBandSlug } }
  );
  await User.updateMany({'organizeBand._id':Types.ObjectId(bandID)},{$set:{'organizeBand.name':newBandName}})

}


async function getFestivals(festivalIDs) {
  try {
    const festivals = [];
    if (festivalIDs) {
      if (!Array.isArray(festivalIDs)) {
        festivalIDs = [festivalIDs];
      }
      for (let festivalID of festivalIDs) {
        const festival = await Festival.findById(festivalID, { id: 1, name: 1, slug: 1 });
        if (!festival) {
          return -2;
        }
        festivals.push(festival);
      }
    }
    return festivals;
  } catch (err) {
    throw err;
  }
}


module.exports = router;
