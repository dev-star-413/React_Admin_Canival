const express = require("express");
const router = express.Router();

router.get("/", function (req, res, next) {
  const {code}=req.query
  let operationResult = { code };

  res.view('index',{operationResult});
});

module.exports = router;