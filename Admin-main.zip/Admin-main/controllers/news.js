const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();
const imagesPrefix = "newsImages";
const file = require("../services/file");
const { News } = require("../models/News");
const { Dates } = require("../models/Dates");
const { uploads } = require("../config")();
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    let operationResult = { code };
    if(!accessManagement.check(req.admin,"NEWS","INDEX")) return res.redirect("/admin?code=-10")
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const news = await News.find({ deleteAt: null });
    for (let n of news) {
      let dates = await Dates.findById(n.dId, "festival year");
      if (dates) {
        n.dId = `${dates.festival.name} - ${dates.year}`;
      }
    }
    return res.view("news/list", { operationResult, news });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code } = req.query;
    if(id&&!accessManagement.check(req.admin,"NEWS","EDIT")) return res.redirect("/admin/news?code=-10")
    if(!id&&!accessManagement.check(req.admin,"NEWS","ADD")) return res.redirect("/admin/news?code=-10")

    var news = await News.findByIdAndDeleteAt({ id });
    const dates = await Dates.find({ canceled: false }, "festival year");
    if (news && news.img) {
      news.img.path = `${uploads.newsImages}/${news.img.path}`;
    }
    return res.view("news/form", { operationResult: { code }, news, dates });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.single("img"), async function (req, res, next) {
  try {
    const { title, sTitle, sDesc, desc, active, dId } = req.body;
    if(!accessManagement.check(req.admin,"NEWS","ADD")) return res.redirect("/admin/news?code=-10")

    let img = null;
    if (req.file) {
      img = await file.save(req.file, imagesPrefix);
      img = img[0];
    }
    await News.create({ title, sTitle, sDesc, desc, img, active: Boolean(active == "on"), dId });
    return res.redirect("/admin/news/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.single("img"), async function (req, res, next) {
  try {
    let { id, title, sTitle, sDesc, desc, active, dId, imgPath } = req.body;
    if(!accessManagement.check(req.admin,"NEWS","EDIT")) return res.redirect("/admin/news?code=-10")
    if (!id || !dId) {
      return res.redirect("/admin/news/form/?code=-1");
    }

    active = Boolean(active === "on");
    let news = await News.findById(id);
    if (!news) {
      return res.redirect("/admin/news/form/?code=-2");
    }

    // update news image
    if (req.file) {
      if (news.img && news.img.path) {
        await file.delete(news.img.path, imagesPrefix);
      }
      let newImage = await file.save(req.file, imagesPrefix);
      news.img = newImage[0];
    } else if (!imgPath && news.img) {
      await file.delete(news.img.path, imagesPrefix);
      news.img = null;
    }

    // let imgsFromDB = news.imgs;
    // let imgsToDB = [];

    // for (let i in imgsFromDB) {
    //   const imgInDB = imgsFromDB[i];
    //   const paramName = "oldFiles_" + imgInDB.path.split("/").pop().split(".")[0];
    //   const imgInReq = req.files.find((file) => file.fieldname === paramName);
    //   if (imgInReq) {
    //     // keep this image
    //     imgsToDB.push(imgInDB);
    //   } else {
    //     // delete this image
    //     await file.delete(imgInDB.path, "newsImages");
    //   }
    // }

    // if (req.files) {
    //   let newImgs = await file.save(
    //     req.files.filter((file) => file.fieldname === "imgs"),
    //     "newsImages"
    //   );
    //   imgsToDB = imgsToDB.concat(newImgs);
    // }

    // news.imgs = imgsToDB;
    news.dId = dId;
    // news.markModified("imgs");
    news.title = title;
    news.sTitle = sTitle;
    news.sDesc = sDesc;
    news.desc = desc;
    news.active = active;
    await news.save();

    return res.redirect("/admin/news/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if(!accessManagement.check(req.admin,"NEWS","DELETE")) return res.redirect("/admin/news?code=-10")
    if (!id) {
      return res.redirect("/admin/news/?code=-1");
    }
    const news = await News.findById(id, "_id img");
    if (news && news.img) {
      await file.delete(news.img.path, imagesPrefix);
    }
    await News.deleteOne({ _id: id });
    return res.redirect("/admin/news/?code=205");
    // await News.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    // return res.redirect(
    //   "/admin/news/?code=205&undo=" + encodeURIComponent("/admin/news/undoDelete?id=" + id)
    // );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/news/?code=-1");
    }

    await News.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/news/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
