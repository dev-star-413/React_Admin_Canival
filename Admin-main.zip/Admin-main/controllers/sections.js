const express = require("express");
const router = express.Router();
const multer = require("multer");
const { Band } = require("../models/Band");
const { BandDate } = require("../models/BandDate");
const { Designer } = require("../models/Designer");
const { Line } = require("../models/Line");
const { Section } = require("../models/Section");
const file = require("../services/file");
const { uniqueSlug } = require("../services/helpers");
const { Vote } = require("../models/Vote");
const upload = multer();
const imagesPrefix = "sectionImages";
const linesPrefix = "lineImages";
const accessManagement = require("../services/accessManagement");
const { Types } = require("mongoose");

router.post("/create", upload.single("img"), async function (req, res, next) {
  try {
    var { bdId, name, rdDate, lDate, deposit, designers, desc, colors, premiums, soldBy, price, standard, types, dCurrency, localPrice, pricingText } =
      req.body;
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");

    var img = req.file;
    if (img) {
      img = await file.save(img, imagesPrefix);
      img = img[0];
    }

    // generate designers array
    premiums = premiums && premiums.split(",");
    colors = colors && colors.split(",");
    const slug = await uniqueSlug(Section, name);
    types = Array.isArray(types) ? types : [types];
    soldBy = soldBy ? await getSoldByBand(soldBy) : null;
    // modify records on database
    let createObj = {
      bdId,
      name,
      deposit,
      designers: await createDesignerObj(designers),
      desc,
      colors,
      premiums,
      rdDate: null,
      lDate: null,
      soldBy,
      price,
      standard,
      img,
      slug,
      types,
      dCurrency,
      localPrice,
      pricingText
    };

    if (rdDate) {
      createObj.rdDate = rdDate + "z";
    }
    if (lDate) {
      createObj.lDate = lDate + "z";
    }

    await Section.create(createObj);
    await BandDate.updateOne({ _id: bdId }, { $inc: { sections: 1 } });
    await updateDesignersLastYear(designers);

    return res.redirect(`/admin/banddates/form?id=${bdId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.post("/update", upload.single("img"), async function (req, res, next) {
  try {
    let {
      id,
      bdId,
      name,
      rdDate,
      lDate,
      deposit,
      designers,
      desc,
      colors,
      premiums,
      soldBy,
      price,
      oldImgPath,
      standard,
      types,
      dCurrency,
      localPrice,
      pricingText
    } = req.body;
    premiums = premiums && premiums.split(",");
    colors = colors && colors.split(",");

    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.redirect("/admin/banddate?code=-10");
    var section = await Section.findById(id);
    if (!section) {
      return res.redirect("/admin/banddate?code=-11");
    }

    let oldDesigners = convertDesigners(section);
    let designersChange = JSON.stringify(designers.split(",")) !== JSON.stringify(oldDesigners);

    if (section.name != name) {
      section.slug = await uniqueSlug(Section, name);
    }
    section.name = name;

    if (rdDate) {
      section.rdDate = rdDate + "z";
    } else {
      section.rdDate = null;
    }
    if (lDate) {
      section.lDate = lDate + "z";
    } else {
      section.lDate = null;
    }

    section.dCurrency = dCurrency;
    section.localPrice = localPrice;
    section.price = price;
    section.desc = desc;
    section.standard = standard;
    section.pricingText=pricingText
    section.types = Array.isArray(types) ? types : [types];
    if (designersChange) {
      await updateDesignersLastYear(oldDesigners);
      section.designers = await createDesignerObj(designers);
      await updateDesignersLastYear(designers.split(","));
    }
    section.colors = Array.isArray(colors) ? colors : [colors];
    section.premiums = Array.isArray(premiums) ? premiums : [premiums];
    section.soldBy = soldBy ? await getSoldByBand(soldBy) : null;
    // update main image
    var img = req.file;
    if ((section.img && oldImgPath !== section.img.path) || (section.img && img)) {
      await file.delete(section.img.path, imagesPrefix);
      section.img = null;
    }
    if (img) {
      const imgSaved = (await file.save(img, imagesPrefix))[0];
      section.img = imgSaved;
    }

    await Section.updateOne({ _id: id }, section);

    return res.redirect(`/admin/banddates/form?id=${bdId}`);
  } catch (error) {
    return next(error, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id, bdId } = req.query;
    if (!accessManagement.check(req.admin, "BAND_DATE", "EDIT")) return res.json({code:-1,msg:"Don't have access."})
    const section = await Section.findById(id);
    if (!section) {
      return res.json({code:1,msg:"Not found section."})
    }
    let oldDesigners = convertDesigners(section);
    // delete section gallery images
    if (section.img) {
      await file.delete(section.img.path, imagesPrefix);
    }
    // delete line dependencies
    const lines = await Line.find({ sId: id });
    for (let line of lines) {
      if (line.gallery) {
        for (let gallery of line.gallery) {
          if (gallery.path) {
            await file.delete(gallery.path, linesPrefix);
          }
        }
      }
    }
    await Line.deleteMany({ sId: id });
    await Vote.deleteMany({ docID: id, docType: "section" });
    await Section.deleteOne({ _id: id });
    await updateDesignersLastYear(oldDesigners);
    await BandDate.updateOne({ _id: bdId }, { $inc: { sections: -1 } });
    return res.json({code:0,msg:"success"})
  } catch (error) {
    return next(error, req, res, next);
  }
});

async function createDesignerObj(designerParams) {
  if (!designerParams) {
    return null;
  }
  let designers = designerParams && designerParams.split(",");
  if (!Array.isArray(designers)) {
    return null;
  }

  let designersToDB = [];
  for (let designer of designers) {
    if (designer) {
      designersToDB.push(await Designer.findById(designer, "_id name slug"));
    }
  }

  return designersToDB;
}

async function getSoldByBand(bandId) {
  const band = await Band.findById(bandId, "_id name");
  return band
    ? {
        id: `${band._id}`,
        name: band.name,
      }
    : null;
}

function convertDesigners(section) {
  let idArr = [];
  if (Array.isArray(section.designers)) {
    for (let designer of section.designers) {
      if(designer && designer._id)
        idArr.push(designer._id);
    }
  }
  return idArr;
}

async function updateDesignersLastYear(designerIDs) {
  if (!designerIDs) {
    return;
  }
  if (!Array.isArray(designerIDs)) {
    designerIDs = [designerIDs];
  }
  for (let designerID of designerIDs) {
    if (!designerID) continue;
    if (typeof designerID === "string") {
      designerID = Types.ObjectId(designerID);
    }
    let designerSections = await Section.find({ "designers._id": designerID }, { bdId: 1 });
    let lastYear = 0;
    for (let section of designerSections) {
      let bandDate = await BandDate.findById(section.bdId, { year: 1 });
      if (bandDate && bandDate.year && bandDate.year > lastYear) {
        lastYear = bandDate.year;
      }
    }
    await Designer.updateOne({ _id: Types.ObjectId(designerID) }, { $set: { lastYear } });
  }
}

module.exports = router;
