const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const { hashPassword } = require("../services/auth");
const { User } = require("../models/User");
const { Admin } = require("../models/Admin");
const { Role } = require("../models/Role");

router.get("/login", async function (req, res, next) {
  try {
    const { code } = req.query;
    return res.view("login", { operationResult: { code }, _layoutFile: false });
  } catch (err) {
    return next(err, req, res, next)
  }
});

router.post("/login", async function (req, res, next) {
  try {
    const { username, password, tz } = req.body;
    if (!username || !password) return res.redirect("/admin/account/login/?code=-1")

    const admin = await Admin.findAndValidatePass({ username, password });
    if (!admin) {
      return res.redirect("/admin/account/login/?code=-2")
    }

    req.session.adminID = admin.id;
    req.session.tz = tz;
    return res.redirect("/admin")
  } catch (err) {
    return next(err, req, res, next)
  }
});
router.get("/logout",async function (req,res,next){
  try {
    req.session.adminID=null
    req.session.tz=null
    return res.redirect("/admin/account/login")
  } catch (err) {
    return next(err,req,res,next)
  }
})
router.get("/password",async function(req,res,next){
  try {
    const { adminID, tz } = req.session;
    if (!adminID) {
      return res.redirect("/admin/account/login");
    }

    let admin = await Admin.findById(adminID).lean();
    if (!admin) {
      return res.redirect("/admin/account/login");
    }

    var role=await Role.findById(admin.role)
    if(!role) return res.redirect("/admin/account/login");

    admin.roleObj = role;

    // https://stackoverflow.com/a/14529888/10278427
    req.session._garbage = Date();
    req.session.touch();
    req.admin = admin;
    return res.view("/password",data={})
  } catch (err) {
    return next(err,req,res,next)
  }
})
router.post("/password",async function(req,res,next){
  try {
    const { password, newPassword, confirmNewPassword } = req.body;
    if(!password || !newPassword || !confirmNewPassword) res.view("/password",data={code:-2}) 
    var adminID=req.session.adminID
    var admin=await Admin.findById(adminID)
    if(!admin){
      req.session.adminID=null
      req.session.tz=null
      return res.redirect("/admin/account/login")
    }
    var passwordIsCorrect=bcrypt.compareSync(password, admin.password);
    if(!passwordIsCorrect || newPassword!=confirmNewPassword) return res.view("/password",data={code:-2})
    await Admin.updateOne({_id:adminID}).set({password:hashPassword(newPassword)})
    return res.view("/password",data={code:1})
  } catch (err) {
    return next(err,req,res,next)
  }
})

module.exports = router;