const express = require("express");
const router = express.Router();

const multer = require("multer");
const upload = multer();

const file = require("../services/file");
const { Gallery } = require("../models/Gallery");
const { Dates } = require("../models/Dates");
const accessManagement=require("../services/accessManagement");
const { Band } = require("../models/Band");
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    if(!accessManagement.check(req.admin,"GALLERY","INDEX")) return res.redirect("/admin?code=-10")
    let operationResult = { code };
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const allGallery = await Gallery.find({ deleteAt: null });
    for (let slide of allGallery) {
      let slug = await Dates.findById(slide.dateId, "slug");
      slide.dateSlug = slug.slug;
    }
    return res.view("gallery/list", { operationResult, allGallery });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { code, id } = req.query;
    if(!id && !accessManagement.check(req.admin,"GALLERY","ADD")) return res.redirect("/admin/gallery?code=-10")
    if(id && !accessManagement.check(req.admin,"GALLERY","EDIT")) return res.redirect("/admin/gallery?code=-10")
    const gallery = await Gallery.findByIdAndDeleteAt({ id });
    const dates = await Dates.find({}, "slug");
    const bands=await Band.find({},'name')
    if (gallery && gallery.imgs) {
      for (let img of gallery.imgs) {
        let mime = img.mime;
        img.path =
          mime && mime.includes("video") ? "/videos/" + img.path : "/admin/images/gallery/200/200/c/" + img.path;
      }
    }
    return res.view("gallery/form", { operationResult: { code }, gallery, dates, bands });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", upload.any(), async function (req, res, next) {
  try {
    let { title, desc, dateId, active, bandsID } = req.body;
    if( !accessManagement.check(req.admin,"GALLERY","ADD")) return res.redirect("/admin/gallery?code=-10")
    bandsID = (bandsID)?bandsID.split(","):[];
    active = Boolean(active === "on");
    let imgs = [];
    if (req.files) {
      for (let i = 0; i < req.files.length; i++) {
        let f = req.files[i];
        let mimetype = f.mimetype;
        let isVideo = mimetype.includes("video");
        let newImg = isVideo ? await file.save(req.files[i], "videos") : await file.save(req.files[i], "galleryImages");
        if (newImg && newImg[0]) {
          newImg[0].text = req.body["textImg-" + i];
          imgs.push(newImg[0]);
        }
      }
    }
    const bands=[]
    for(var b of bandsID){
      let band=await Band.findById(b,'name slug ')
      bands.push(band)
    }
    await Gallery.create({ title, desc, dateId, active, imgs ,bands});
    return res.redirect("/admin/gallery/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", upload.any(), async function (req, res, next) {
  try {
    var params = req.body;
    if( !accessManagement.check(req.admin,"GALLERY","EDIT")) return res.redirect("/admin/gallery?code=-10")
    let { id, title, desc, dateId, active ,bandsID} = params;
    if (!id) {
      return res.redirect("/admin/gallery/form/?code=-1");
    }
    bandsID = (bandsID)?bandsID.split(","):[];
    active = Boolean(active === "on");
    let gallery = await Gallery.findById(id);
    if (!gallery) {
      return res.redirect("/admin/gallery/form/?code=-2");
    }

    let imgsFromDB = gallery.imgs;
    let imgsToDB = [];

    for (let i in imgsFromDB) {
      var imgInDB = imgsFromDB[i];
      if (typeof params[`textImg-${imgInDB._id}`] === "undefined") {
        if (imgInDB.mime.includes("video")) {
          await file.delete(imgInDB.path, "videos");
        } else await file.delete(imgInDB.path, "galleryImages");
        continue;
      }
      imgInDB.text = params[`textImg-${imgInDB._id}`];
      const imgInReq = req.files.find((file) => file.fieldname === `img-${imgInDB._id}`);
      if (imgInReq) {
        if (imgInDB.mime && imgInDB.mime.includes("video")) await file.delete(imgInDB.path, "videos");
        else await file.delete(imgInDB.path, "galleryImages");
        let mimetype = imgInReq.mimetype;
        let isVideo = mimetype.includes("video");
        let updateImg = isVideo ? await file.save(imgInReq, "videos") : await file.save(imgInReq, "galleryImages");
        req.files = req.files.filter((file) => file.fieldname != `img-${imgInDB._id}`);
        if (updateImg && updateImg[0]) imgInDB = { ...imgInDB.toObject(), ...updateImg[0] };
        else continue;
      }
      imgsToDB.push(imgInDB);
    }

    if (req.files && req.files[0]) {
      for (let image of req.files) {
        let n = image.fieldname.split("-")[1] || null;
        let mimetype = image.mimetype;
        let isVideo = mimetype.includes("video");
        let newImg = isVideo ? await file.save(image, "videos") : await file.save(image, "galleryImages");
        if (newImg && newImg[0]) {
          newImg[0].text = params["textImg-" + n];
          imgsToDB.push(newImg[0]);
        }
      }
    }
    var bands=[]
    var oldBands=gallery.bands || []
    for(var b of bandsID){      
      let include=oldBands.find((ba)=>ba._id==b)
      if(include && include._id){
        bands.push(include)
        continue
      }
      let band=await Band.findById(b,'name slug')
      bands.push(band)      
    }
    gallery.imgs = imgsToDB;
    gallery.markModified("imgs");
    gallery.title = title;
    gallery.desc = desc;
    gallery.dateId = dateId;
    gallery.active = active;
    gallery.bands = bands;

    await gallery.save();

    return res.redirect("/admin/gallery/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if( !accessManagement.check(req.admin,"GALLERY","DELETE")) return res.redirect("/admin/gallery?code=-10")
    if (!id) {
      return res.redirect("/admin/gallery/?code=-1");
    }
    var slide = await Gallery.findById({ _id: id }, "imgs");
    var imgs = slide && slide.imgs;
    for (let img of imgs) {
      if (img.mime && img.mime.includes("video")) await file.delete(img.path, "videos");
      else await file.delete(img.path, "galleryImages");
    }
    await Gallery.deleteOne({ _id: id });
    return res.redirect("/admin/gallery/?code=205");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/gallery/?code=-1");
    }

    await Gallery.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/gallery/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
