const express = require("express");
const router = express.Router();
const config = require("../config")();

const { Role } = require("../models/Role");
const accessManagement=require("../services/accessManagement")
router.get("/", async function (req, res, next) {
  try {
    const { code, undo } = req.query;
    let operationResult = { code };
    if(!accessManagement.check(req.admin,"ROLE","INDEX")) return res.redirect("/admin?code=-10")
    if (code == 205) {
      operationResult.msg = `The record has been deleted`;
    }
    const roles = await Role.find({ deleteAt: null });
    return res.view("roles/list", { operationResult, roles });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/form", async function (req, res, next) {
  try {
    const { id, code } = req.query;
    if(!id && !accessManagement.check(req.admin,"ROLE","ADD")) return res.redirect("/admin/roles?code=-10")
    if(id && !accessManagement.check(req.admin,"ROLE","EDIT")) return res.redirect("/admin/roles?code=-10")
    const accessControl=config.accessControl
    const role = await Role.findByIdAndDeleteAt({ id });
    return res.view("roles/form", { operationResult: { code }, role ,accessControl });
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/create", async function (req, res, next) {
  try {
    let { name, access } = req.body;
    if( !accessManagement.check(req.admin,"ROLE","ADD")) return res.redirect("/admin/roles?code=-10")
    if (!name) {
      return res.redirect("/admin/roles/form/?code=-1");
    }

    if (!Array.isArray(access)) {
      access = [access];
    }

    await Role.create({ name, access });
    return res.redirect("/admin/roles/?code=201");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.post("/update", async function (req, res, next) {
  try {
    let { id, name, access } = req.body;
    if( !accessManagement.check(req.admin,"ROLE","EDIT")) return res.redirect("/admin/roles?code=-10")
    if (!id || !name) {
      return res.redirect("/admin/roles/form/?code=-1");
    }

    if (!Array.isArray(access)) {
      access = [access];
    }

    await Role.updateOne({ _id: id }, { $set: { name, access } });
    return res.redirect("/admin/roles/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/delete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if( !accessManagement.check(req.admin,"ROLE","DELETE")) return res.redirect("/admin/roles?code=-10")
    // can not delete role
    return res.redirect("/admin/roles")
    if (!id) {
      return res.redirect("/admin/roles/?code=-1");
    }

    await Role.deleteOne({ _id: id });
    return res.redirect("/admin/roles/?code=205");
    await Role.updateOne({ _id: id }, { $set: { deleteAt: new Date() } });
    return res.redirect(
      "/admin/roles/?code=205&undo=" + encodeURIComponent("/admin/roles/undoDelete?id=" + id)
    );
  } catch (err) {
    return next(err, req, res, next);
  }
});

router.get("/undoDelete", async function (req, res, next) {
  try {
    const { id } = req.query;
    if (!id) {
      return res.redirect("/admin/roles/?code=-1");
    }

    await Role.updateOne({ _id: id }, { $unset: { deleteAt: 1 } });
    return res.redirect("/admin/roles/?code=200");
  } catch (err) {
    return next(err, req, res, next);
  }
});

module.exports = router;
