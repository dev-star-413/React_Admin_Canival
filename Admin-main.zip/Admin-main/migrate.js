const { Migrate } = require("./models/Migrate");

module.exports = {
  runNotDone: async function () {
    try {
      const doneFuncs = await Migrate.find();
      for (let i in migrateFunctions) {
        try {
          if (!doneFuncs.find((item) => item.funcName === i)) {
            const { code: resCode } = await migrateFunctions[i]();
            await Migrate.create({ funcName: i, resCode });
          }
        } catch (err) {
          console.log("======================== Migrate Fai ========================");
          console.log(err);
        }
      }
      console.log("======================== Migrate End ========================");
    } catch (err) {
      console.log("======================== Migrate Err ========================");
      console.log(err);
    }
  },
};

const migrateFunctions = {
  v1: async function () {
    try {
      const { Award } = require("./models/Award");
      const { BandDate } = require("./models/BandDate");

      const awards = await Award.find();
      for (let award of awards) {
        if (Array.isArray(award.cats)) {
          for (let cat of award.cats) {
            if (Array.isArray(cat.positions)) {
              for (let position of cat.positions) {
                if (Array.isArray(position.bands)) {
                  for (let band of position.bands) {
                    const dbBand = await BandDate.findById(band._id);
                    if (dbBand) {
                      band.slug = dbBand.slug;
                    }
                  }
                }
              }
            }
          }
        }
        award.markModified("cats");
        await award.save();
      }

      return { code: 0 };
    } catch (err) {
      console.log(err);
      return { code: -1 };
    }
  },
  v2: async function () {
    try {
      const { Role } = require("./models/Role");
      const { User } = require("./models/User");
      await Role.updateMany({ access: "SUPER_ADMIN" }, { $set: { name: "Super Admin" } });
      await User.deleteMany({ role: "admin" });

      return { code: 0 };
    } catch (err) {
      console.log(err);
      return { code: -1 };
    }
  },
  v3: async function () {
    try {
      const { BandDate } = require("./models/BandDate");
      const { Band } = require("./models/Band");
      var bands = await Band.find();
      for (var band of bands) {
        let dates = await BandDate.find({ bandId: band._id }).sort({ year: -1 }).limit(1);
        var lastYear = dates && dates[0] && dates[0].year;
        await Band.update({ _id: band._id }, { lastYear });
      }
      return { code: 0 };
    } catch (error) {
      console.log(error);
      return { code: -1 };
    }
  },
  v4: async function () {
    try {
      const { Section } = require("./models/Section");
      const { BandDate } = require("./models/BandDate");
      const { Designer } = require("./models/Designer");

      let designers = await Designer.find();
      for (let designer of designers) {
        let designerSections = await Section.find({ "designers._id": designer._id }, { bdId: 1 });
        let lastYear = 0;
        for (let section of designerSections) {
          let bandDate = await BandDate.findById(section.bdId, { year: 1 });
          if (bandDate && bandDate.year && bandDate.year > lastYear) {
            lastYear = bandDate.year;
          }
        }
        await Designer.updateOne({ _id: designer._id }, { $set: { lastYear } });
      }

      return { code: 0 };
    } catch (error) {
      console.log(error);
      return { code: -1 };
    }
  },
  v5:async function(){
    try {
      const {getCountries} =require("./services/helpers");
      const { City } = require("./models/City");
      const { CurrencyRate } = require("./models/CurrencyRate");
      const {getCurrencyRate}  =require("./services/helpers");
      var cities=await City.find()
      for(var city of cities){
        var country=getCountries().find((co)=>co.id==city.code)
        if(!country) console.log(city)
        city.currency=country && country.currencyId
        await city.save()
        if(country && country.currencyId != 'USD'){
          let rate=await CurrencyRate.findOne({from:country.currencyId}) 
          if(!rate){
            rate=await getCurrencyRate(country.currencyId) // Number of Requests per Hour: 100
            await CurrencyRate.create({
              country:country.name,
              from:country.currencyId,
              rate
            })
          }
        }
      }
      return { code: 0 };
    } catch (error) {
      console.log(error)      
      return {code:-1}
    }
  },
  v6:async function(){
    try {
      const { BandDate } = require("./models/BandDate");
      const { Event } = require("./models/Event");
      const { EventTemp } = require("./models/EventTemp");
      const { Line } = require("./models/Line");
      const { Section } = require("./models/Section");

      await BandDate.updateMany({},{rdCurrency:"USD"})
      await Event.updateMany({},{currency:"USD"})
      await EventTemp.updateMany({},{currency:"USD"})
      await Line.updateMany({},{
        currency:"USD",
      })
      // update gallery 
      await Line.updateMany({
        'gallery.price': { $exists: true}
        },{
        $set:{'gallery.$.currency':"USD"} //  Just update index 0 of array gallery
      })
      await Line.updateMany({},{currency:"USD"})
      await Section.updateMany({},{dCurrency:"USD",pCurrency:"USD"})
      return {code:0}
    } catch (error) {
      console.log(error)      
      return {code:-1}
    }
  },
  v7:async function(){
    try {
      const { Line } = require("./models/Line");
      await Line.updateMany({
        'gallery.price': { $exists: true}
        },{
        $set:{'gallery.$[].currency':"USD"} //  Just update all index of array gallery
      })
      return {code:0}
    } catch (error) {
      return {code:-1}
    }
  },
  v8:async function(){
    try {
      const {getCountries} =require("./services/helpers");
      const { CurrencyRate } = require("./models/CurrencyRate");
      var rates=await CurrencyRate.find()
      var countries=getCountries()
      for(var rate of rates){
        let country=countries.find((co)=>co.currencyId===rate.from)
        rate.symbol=country.currencySymbol;
        await rate.save()
      }
      return {code:0}
    } catch (error) {
      return {code:-1}
    }
  },
  v9:async function(){
    try {
      const { BandDate } = require("./models/BandDate");
      var bands=await BandDate.find({'imgs.0':{$exists:true},mainImg:{$exists:false}})
      for(var band of bands){
        await BandDate.updateOne({_id:band._id},{mainImg:band.imgs[0]})
      }
      return {code:0}
    } catch (error) {
      return {code:-1}
    }
  },
  // v10:async function(){
  //   try {
  //     const { BandDate } = require("./models/BandDate");
  //     var bands=await BandDate.find({mainImg:{$exists:true},jImg:{$exists:false}})
  //     for(var band of bands){
  //       await BandDate.updateOne({_id:band._id},{jImg:band.imgs[0]})
  //     }
  //     return {code:0}
  //   } catch (error) {
  //     return {code:-1}
  //   }
  // },
  v11:async function(){
    try {
      const { BandDate } = require("./models/BandDate");
      await BandDate.update({'services.0':""},{services:[]})
      await BandDate.update({'jouvertServices.0':""},{jouvertServices:[]})
      await BandDate.update({'childrenServices.0':""},{childrenServices:[]})
      return {code:0}
    } catch (error) {
      return {code:-1}
    }
  },
  v12:async function(){
    try {
      const { BandDate } = require("./models/BandDate");
      await BandDate.updateMany({$and:[{'theme':{$exists:true}},{'theme':{$ne:""}},{'theme':{$ne:null}}]},{showAdult:true})
      await BandDate.updateMany({$and:[{'jouvertTheme':{$exists:true}},{'jouvertTheme':{$ne:""}},{'jouvertTheme':{$ne:null}}]},{showJouvert:true})
      await BandDate.updateMany({$and:[{'childrenTheme':{$exists:true}},{'childrenTheme':{$ne:""}},{'childrenTheme':{$ne:null}}]},{showChildren:true})
      return {code:0}
    } catch (error) {
      return {code:-1}
    }
  },
  v13:async function(){
    try {
      const { BandDate } = require("./models/BandDate");
      await BandDate.updateMany({'services.0':""},{services:[]})
      await BandDate.updateMany({'jouvertServices.0':""},{jouvertServices:[]})
      await BandDate.updateMany({'childrenServices.0':""},{childrenServices:[]})
      return {code:0}
    } catch (error) {
      return {code:-1}
    }
  },
};
