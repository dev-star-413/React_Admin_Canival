const bcrypt = require("bcryptjs");
const { Statics } = require("./models/Statics");
const { hashPassword } = require("./services/auth");
const config = require("./config")();
const staticPages = require("./config/staticPages");
const migrate = require("./migrate");
const { Admin } = require("./models/Admin");
const { Role } = require("./models/Role");
const { CurrencyRate } = require("./models/CurrencyRate");
const { getCurrencyRate } = require("./services/helpers");

module.exports = async function () {
  // let superRole = await Role.findOne({ access: "SUPER_ADMIN" });
  // if (!superRole) {
  //   superRole = await Role.create({ name: "Super Admin", access: ["SUPER_ADMIN"] });
  // }
  // const { username, password } = config.adminUser;
  // const adminUser = await Admin.findOne({ username });
  // if (!adminUser) {
  //   await Admin.create({ username, password: hashPassword(password), role: superRole.id, name: "admin" });
  // }

  if (staticPages && staticPages[0]) {
    for (let static of staticPages) {
      const found = await Statics.findOne({ slug: static.slug });
      if (!found) {
        await Statics.create(static);
      }
    }
  }

  await migrate.runNotDone();

  let rate=await CurrencyRate.findOne({from:"USD"}) 
  if(!rate){
    rate=await getCurrencyRate("USD") // Number of Requests per Hour: 100
    await CurrencyRate.create({
      from:"USD",
      ...rate
    })
  }

  // update rate of currency per hour
  setInterval(async()=>{
    var rates=await CurrencyRate.find().sort({updateAt:1}).limit(90)
    var now=new Date().getHours()
    for(var rate of rates){
      if(new Date(rate.updateAt).getHours() < now){
        let newRate=await getCurrencyRate(rate.from)
        if(newRate && Object.keys(newRate)[0] )
          {
            rate.rate=newRate
            rate.updateAt=new Date().getDate()
            rate.save()
          }
      }
    }
  },90*60*1000) // 1.5 hr
};
