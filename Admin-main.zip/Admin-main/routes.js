const express = require("express");
const router = express.Router();

const loginMiddleWare = require("./middleWares/login");
const localsMiddleWare = require("./middleWares/locals");

const accountRouter = require("./controllers/accounts");
const userRouter = require("./controllers/users");
const roleRouter = require("./controllers/roles");
const cityRouter = require("./controllers/cities");
const festivalRouter = require("./controllers/festivals");
const datesRouter = require("./controllers/dates");
const eventRouter = require("./controllers/events");
const bandRouter = require("./controllers/bands");
const newsRouter = require("./controllers/news");
const galleryRouter = require("./controllers/gallery");
const tradesRouter = require("./controllers/trades");
const designersRouter = require("./controllers/designers");
const blogsRouter = require("./controllers/blogs");
const adsRouter = require("./controllers/ads");
const commentsRouter = require("./controllers/comments");
const faqsRouter = require("./controllers/faqs");
const awardsRouter = require("./controllers/awards");
const indexRouter = require("./controllers/index");
const bandDateRouter = require("./controllers/bandDates");
const dynamicsController = require("./controllers/dynamics");
const sectionsController = require("./controllers/sections");
const staticsController = require("./controllers/statics");
const linesController = require("./controllers/lines");
const eventTempController = require("./controllers/eventTemp");
const bandTempController = require("./controllers/bandTemp");
const comparesController =require('./controllers/compares')
const froalaController =require('./controllers/froala')
const adminsController =require('./controllers/admin')

router.use("/account", localsMiddleWare, accountRouter);
router.use("/users", loginMiddleWare, localsMiddleWare, userRouter);
router.use("/roles", loginMiddleWare, localsMiddleWare, roleRouter);
router.use("/cities", loginMiddleWare, localsMiddleWare, cityRouter);
router.use("/festivals", loginMiddleWare, localsMiddleWare, festivalRouter);
router.use("/dates", loginMiddleWare, localsMiddleWare, datesRouter);
router.use("/events", loginMiddleWare, localsMiddleWare, eventRouter);
router.use("/bands", loginMiddleWare, localsMiddleWare, bandRouter);
router.use("/news", loginMiddleWare, localsMiddleWare, newsRouter);
router.use("/gallery", loginMiddleWare, localsMiddleWare, galleryRouter);
router.use("/trades", loginMiddleWare, localsMiddleWare, tradesRouter);
router.use("/designers", loginMiddleWare, localsMiddleWare, designersRouter);
router.use("/blogs", loginMiddleWare, localsMiddleWare, blogsRouter);
router.use("/ads", loginMiddleWare, localsMiddleWare, adsRouter);
router.use("/comments", loginMiddleWare, localsMiddleWare, commentsRouter);
router.use("/faqs", loginMiddleWare, localsMiddleWare, faqsRouter);
router.use("/awards", loginMiddleWare, localsMiddleWare, awardsRouter);
router.use("/banddates", loginMiddleWare, localsMiddleWare, bandDateRouter);
router.use("/dynamics", loginMiddleWare, localsMiddleWare, dynamicsController);
router.use("/", loginMiddleWare, localsMiddleWare, indexRouter);
router.use("/sections", loginMiddleWare, localsMiddleWare, sectionsController);
router.use("/statics", loginMiddleWare, localsMiddleWare, staticsController);
router.use("/lines", loginMiddleWare, localsMiddleWare, linesController);
router.use("/eventtemps", loginMiddleWare, localsMiddleWare, eventTempController);
router.use("/bandtemps", loginMiddleWare, localsMiddleWare, bandTempController);
router.use("/compares", loginMiddleWare, localsMiddleWare, comparesController);
router.use("/froala", loginMiddleWare,localsMiddleWare, froalaController);
router.use("/admins", loginMiddleWare,localsMiddleWare, adminsController);

router.use(function (req, res, next) {
  return res.status(404).view("404", { _layoutFile: false });
});

module.exports = router;
