module.exports = {
  apps: [
    {
      name: "festival-admin",
      namespace: "prod",
      script: "./bin/www.js",
      watch: false,
      // ignore_watch:['node_modules','views','public'],
      env: {
        NODE_ENV: "production",
      },
    },
  ],
};
