module.exports={
    
    check(admin,controller,action){
        try {
            var role=admin.roleObj
            var all=role.access || null
            if(Array.isArray(all) && all.includes("SUPER_ADMIN") ) return true
            var access=controller+"_"+action
            if(Array.isArray(all) && all.includes(access)) return true
            return false
        } catch (error) {
            throw error
        }
    }
}