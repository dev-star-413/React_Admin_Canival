const util = require("util");
const { existsSync, mkdir, writeFile, unlink, constants,readdirSync } = require("fs");
const { access } = require("fs/promises");
const asyncUnlink = util.promisify(unlink);
const asyncWriteFile = util.promisify(writeFile);
const asyncMkdir = util.promisify(mkdir);
const uniqid = require("uniqid");
const { join } = require("path");

const config = require("../config")();

module.exports = {
  /**
   *
   * @param {Object[]} files
   * @param {String} dest
   * @param {Object} otherOptions
   * @returns {Promise<Object[]>} saved files info
   */
  save: async function (files, dest, otherOptions) {
    if (!Array.isArray(files)) {
      files = [files];
    }

    let output = [];
    for (let file of files) {
      const prefix = config.uploads[dest] || config.uploads["defaultImages"];
      const subFolder = otherOptions && otherOptions.subFolder ? otherOptions.subFolder : "";
      const filename = file.originalname; //uniqid() + "." + file.originalname.split(".").pop();
      const pathToWrite = join("public", prefix, subFolder);
      const { originalFileName, finalFileName } = await writeTheFirstPossible(
        pathToWrite,
        filename,
        file.buffer
      );
      //await asyncWriteFile(pathToWrite, file.buffer);
      output.push({ name: file.originalname, path: finalFileName, mime: file.mimetype });
    }

    return output;
  },

  /**
   * Deletes files with name specified in path, and subfolder specified in dest
   * @param {string} paths
   * @param {string} dest
   * @returns nothing
   */
  delete: async function (paths, dest) {
    if (!Array.isArray(paths)) {
      paths = [paths];
    }
    const prefix = dest
      ? config.uploads[dest] || config.uploads["defaultImages"]
      : "";
    if (!prefix) return false;
    for (let path of paths) {
      if (!path.startsWith("public")) {
        path = join("public", prefix, path);
      }
      try {
        await asyncUnlink(path);
      } catch (err) {
        if (err.code === "ENOENT") {
          // Do nothing here!
        } else {
          throw err;
        }
      }
    }
  },

  createDir: async function (dest, otherOptions) {
    const subFolder = otherOptions && otherOptions.subFolder ? otherOptions.subFolder : "";
    if (!existsSync(join("public", config.uploads[dest], subFolder))) {
      await asyncMkdir(join("public", config.uploads[dest], subFolder), {
        recursive: true,
      });
    }
  },

  createRequireDirs: async function () {
    for (let i in config.uploads) {
      if (!existsSync(join("public", config.uploads[i]))) {
        await asyncMkdir(join("public", config.uploads[i]), { recursive: true });
      }
    }
  },

  readDirectory:async function(dest){
    try {
      let dir=config.uploads[dest] || config.uploads["other"];
      dir='public'+dir
      let files=await readdirSync(dir)
      return files
    } catch (error) {
      throw error
    }
  },

  isFileExists:async function(path){
    return await promiseExists(path)
  }
};

async function writeTheFirstPossible(path, fileName, data) {
  try {
    const originalFileName = fileName;
    let noDuplicateFileName = originalFileName;
    let noDuplicateNumber = 1;
    let writePath = join(path, noDuplicateFileName);
    while (await promiseExists(writePath)) {
      const beforeExtension = originalFileName.substring(0, originalFileName.lastIndexOf("."));
      const extension = originalFileName.split(".").pop();
      noDuplicateFileName = beforeExtension + "-" + noDuplicateNumber + "." + extension;
      noDuplicateNumber++;
      writePath = join(path, noDuplicateFileName);
    }

    await asyncWriteFile(writePath, data);
    return { originalFileName, finalFileName: noDuplicateFileName };
  } catch (err) {
    throw err;
  }
}

async function promiseExists(path) {
  try {
    await access(path, constants.R_OK);
    return true;
  } catch (err) {
    if (err.code === "ENOENT") {
      return false;
    } else {
      throw err;
    }
  }
}
