const { Dynamics } = require("../models/Dynamics")

module.exports = async function () {
    try {
        const dynamicsExist = await Dynamics.findOne()
        if (!dynamicsExist) {
            await Dynamics.create({ styles: [] })
            console.info("Database initilized successfully")
        }
    } catch (error) {
        console.error("Eror occured while initilizing the database")
    }
}