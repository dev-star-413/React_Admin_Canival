const { BandDate } = require("../models/BandDate");
const { Line } = require("../models/Line");
const { Section } = require("../models/Section");
const { Vote } = require("../models/Vote");
const { Comment } = require("../models/Comment");
const fileHandler = require("../services/file");
const file = require("../services/file");
const imagesPrefix = "bandImages";
const commentsPrefix = "commentImages";
const videosPrefix = "videos";
const linesPrefix = "lineImages";
const sectionsPrefix = "sectionImages";


/**
 * 
 * @param {String} id 
 * Pass the band date id and delete all sections, lines, comments, votes and images.
 */
exports.deleteBandDateDependencies = async function (id) {
    try {
        const band = await BandDate.findById(id);
        if (band) {
            // delete video
            if (band.video && band.video.path) {
                await fileHandler.delete(band.video.path, videosPrefix);
            }
            // delete images
            if (band.imgs && band.imgs.length) {
                for (let image of band.imgs) {
                    await fileHandler.delete(image.path, imagesPrefix);
                }
            }
            // delete jouvert image
            if (band.jImg && band.jImg.path) {
                await fileHandler.delete(band.jImg.path, imagesPrefix);
            }
            // delete main image
            if (band.mainImg && band.mainImg.path) {
                await fileHandler.delete(band.mainImg.path, imagesPrefix);
            }
            // delete costume image
            if (band.costumeImg && band.childrenImg.path) {
                await fileHandler.delete(band.costumeImg.path, imagesPrefix);
            }
            // delete children image
            if (band.childrenImg && band.childrenImg.path) {
                await fileHandler.delete(band.childrenImg.path, imagesPrefix);
            }
            const sections = await Section.find({ bdId: id }, "_id bdId img");
            for (let section of sections) {
                // delete section hot or not votes
                await Vote.deleteMany({ docID: section._id, docType: 'section' });
                // delete section main image
                if (section.img && section.img.path) {
                    await fileHandler.delete(section.img.path, sectionsPrefix);
                }
                // delete lines and their gallery images
                const lines = await Line.find({ sId: section._id }, 'gallery');
                for (let line of lines) {
                    if (line.gallery) {
                        for (let item of line.gallery) {
                            if (item.path) {
                                await fileHandler.delete(item.path, linesPrefix);
                            }
                        }
                    }
                }
                await Line.deleteMany({ sId: section._id });
            }
            await Section.deleteMany({ bdId: id });
            // delete band date comments and their images
            const comments = await Comment.find({ docID: id, collName: 'band' });
            for (let comment of comments) {
                if (comment.imgs) {
                    for (let image of comment.imgs) {
                        image.path && await file.delete(image.path, commentsPrefix)
                    }
                }
            }
            await Comment.deleteMany({ docID: id, collName: 'band' });
            await Vote.deleteMany({ docID: id, docType: 'band' });
            await BandDate.deleteOne({ _id: id });
        }
    } catch (error) {
        console.error(error);
    }
}