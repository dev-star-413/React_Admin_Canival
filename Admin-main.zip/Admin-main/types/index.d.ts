export declare global {
  namespace Express {
    interface Response {
      /**
       * Use express res.render function to render view file inside layout file.
       *
       * @param {string} view The path of the view file, relative to view root dir.
       * @param {object} options The options to send to view file for ejs to use when rendering.
       * @returns {Express.Response.render} .
       */
      view(view: string, options?: object): Express.Response.render;
    }
    interface Request {
      /**
       * Logged in use base on session id.
       */
      user: {
        _id: string;
        username: string;
        password: string;
        role?: string;
        name?: string;
        createAt: Date;
        deleteAt?: Date;
      };
    }
  }
}
