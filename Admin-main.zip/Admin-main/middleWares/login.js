const { Admin } = require("../models/Admin");
const { Role } = require("../models/Role");

module.exports = async (req, res, next) => {
  try {
    const { adminID, tz } = req.session;
    if (!adminID) {
      return res.redirect("/admin/account/login");
    }

    let admin = await Admin.findById(adminID).lean();
    if (!admin) {
      return res.redirect("/admin/account/login");
    }

    var role=await Role.findById(admin.role)
    if(!role) return res.redirect("/admin/account/login");
    
    admin.roleObj = role;

    // https://stackoverflow.com/a/14529888/10278427
    req.session._garbage = Date();
    req.session.touch();
    req.admin = admin;
    next();
  } catch (err) {
    next(err, req, res, next);
  }
};
