const moment = require("moment");
require("moment-timezone"); // is enough
const config = require("../config")();

module.exports = async (req, res, next) => {
  try {
    res.locals.moment = moment;

    if (req.admin) {
      res.locals.loggedInUser = req.admin;
      // res.locals.moment.tz.setDefault(req.admin.tz || "GMT");
    }

    res.locals.froalaKey = config.froalaKey;
    res.locals.froalaOptions = config.froalaOptions;

    next();
  } catch (err) {
    next(err, req, res, next);
  }
}