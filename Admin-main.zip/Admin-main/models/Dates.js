const mongoose = require("mongoose");

const datesSchema = new mongoose.Schema({
  slug: { type: String, unique: true },
  festival: { type: Object }, // id, name
  bestS: { type: Date },
  bestE: { type: Date },
  paradeS: { type: Date },
  paradeE: { type: Date },
  paradeGeo: { type: mongoose.Schema.Types.Mixed },
  img: { type: mongoose.Schema.Types.Mixed },
  price: { type: Number },
  theme: { type: String, trim: true },
  desc: { type: String, trim: true },
  meta: { type: String, trim: true },
  canceled: { type: Boolean, default: false },
  year: { type: Number },
  tsk: { type: Array, default: [] },
  todo: { type: mongoose.Schema.Types.Mixed },
  city: { type: String },// cityID
  likeC: { type: Number },
  commentC: { type: Number },
  lPage: { type: Boolean },
  top: { type: Boolean },
  pImg: { type: Object },
  comments: { type: mongoose.Schema.Types.Mixed },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  heading:{type:String},
  imgTitle: { type: String },
  paradeDesc: { type: String },
  costume: { type: String },
  event: { type: String },
  result: { type: String },
  review: { type: String },
  guide: { type: String }, // travel should know
  keywords: { type: String },
  whereToStay: { type: String },
  jouvert:{type:String},
  jouvertAddress:{type:String},
  jouvertStartDate:{type:Date},
  jouvertEndDate:{type:Date},
  jImg:{type:Object},
  intro:{type:String},
  //-----------
  childrenStartD:{type:Date},
  childrenEndD:{type:Date},
  eventImg:{ type: Object },
  childrenImage:{type:Object},
  childrenParadeAddress:{type:String},
  childrenDesc:{type:String},
  paradeLocation:{type:String},
  officialName:{type:String},
  isActive:{type:Boolean,default:false}
});

datesSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let date = await DatesModel.findById(id);
  if (!date || date.deleteAt) {
    return null;
  } else {
    return date;
  }
};

const DatesModel = mongoose.model("Dates", datesSchema);
exports.Dates = DatesModel;
