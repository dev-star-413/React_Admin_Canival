const mongoose = require("mongoose");

const CurrencyRate = new mongoose.Schema({
    country:{type:String}, // country (to) 
    from:{type:String},
    to:{type:String, default:"USD"},
    rate:{type:String}, 
    symbol:{type:String}, 
    updateAt:{type:Date ,default:Date.now},
    createAt: { type: Date, default: Date.now },
    deleteAt: { type: Date }
});
const CurrencyRateModel = mongoose.model("currencyRate", CurrencyRate);
exports.CurrencyRate = CurrencyRateModel;