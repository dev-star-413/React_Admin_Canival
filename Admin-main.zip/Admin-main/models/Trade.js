const mongoose = require("mongoose");

const tradeSchema = new mongoose.Schema({
  // _id,
  title: { type: String },
  type: { type: String },
  costume: { type: mongoose.Schema.Types.Mixed },
  price: { type: String },
  imgs: { type: mongoose.Schema.Types.Mixed },
  desc: { type: String },
  eDate: { type: Date },
  private: { type: Boolean },
  contact: { type: mongoose.Schema.Types.Mixed },
  active: { type: Boolean },
  fyID: { type: String },

  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

tradeSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let trade = await TradeModel.findById(id);
  if (!trade || trade.deleteAt) {
    return null;
  } else {
    return trade;
  }
};

const TradeModel = mongoose.model("Trade", tradeSchema);
exports.Trade = TradeModel;
