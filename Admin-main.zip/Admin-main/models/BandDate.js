const mongoose = require("mongoose");

const bandDateSchema = new mongoose.Schema({
  // band date
  bandId: { type: String },
  name: { type: String },
  dateId: { type: String },
  dateName: { type: String },
  year: { type: Number },
  themeType: { type: String },
  theme: { type: String },
  lDate: { type: Date },
  rdDate: { type: String },
  preRegisPrice: {type: Number},
  localPrice: {type: Number},
  price: {type: Number},
  preRegisDeadLine: {type: String},
  video: { type: Object },
  imgs: { type: mongoose.Schema.Types.Mixed },
  deposit: { type: Number },
  desc: { type: String },
  sectionOptions: { type: String },
  reveller: { type: String },
  locals: { type: Number },
  slug: { type: String },
  agree: { type: Number, default: 0 },
  resultText: { type: String },
  disagree: { type: Number, default: 0 },
  notsure: { type: Number, default: 0 },
  likeC: { type: Number }, // like count
  commentC: { type: Number }, // comment count
  avgScore: { type: Number, default: 0 },
  sumOfReviews: { type: Number, default: 0 },
  comments: { type: mongoose.Schema.Types.Mixed }, // last 10 comments
  hot: { type: Number },
  compares: { type: mongoose.Schema.Types.Mixed, default: [] },
  scores: { type: mongoose.Schema.Types.Mixed, default: [] },
  score: { type: Number, default: 0 },
  reviews: { type: mongoose.Schema.Types.Mixed },
  services: { type: Array, default: [] }, // costume services 
  jouvertServices:{ type: Array, default: [] },
  isCustomeService:{type:Boolean,default:false},
  isJouvertService:{type:Boolean,default:false},
  sections: { type: Number, default: 0 },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  reviewText: { type: String },
  meta: { type: String },
  link:{type:String},
  jImg: { type: mongoose.Schema.Types.Mixed },  // {name, path, mime}
  jlImg: { type: mongoose.Schema.Types.Mixed },
  rdCurrency:{type:String}, // registration deposit currency
  confirm:{type:Number,default:0},
  complete:{type:Boolean,default:false},
  // ___________________________________________________
  mainImg: { type: mongoose.Schema.Types.Mixed },
  isChildrenService:{type:Boolean,default:false},
  childrenServices:{ type: Array, default: [] },
  costumeImg:{ type: mongoose.Schema.Types.Mixed },
  costumeLImg:{ type: mongoose.Schema.Types.Mixed },
  jouvertTheme:{type:String},
  jouvertLaunchDate:{type:Date},
  jouvertDeadlineDate:{type:Date},
  childrenImg:{type:mongoose.Schema.Types.Mixed},
  childrenlImg:{type:mongoose.Schema.Types.Mixed},
  childrenTheme:{type:String},
  childrenLaunchDate:{type:Date},
  childrenDeadlineDate:{type:Date},
  details:{type:String},
  showAdult:{type:Boolean,default:false}, 
  showJouvert:{type:Boolean,default:false}, 
  showChildren:{type:Boolean,default:false}, 

});

bandDateSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let band = await BandDateModel.findById(id);
  if (!band || band.deleteAt) {
    return null;
  } else {
    return band;
  }
};

const BandDateModel = mongoose.model("BandDate", bandDateSchema);
exports.BandDate = BandDateModel;
