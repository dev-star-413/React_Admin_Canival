const mongoose = require("mongoose");

const newsSchema = new mongoose.Schema({
  // _id,
  dId: { type: String }, // festival date Id
  title: { type: String },
  sTitle: { type: String },
  sDesc: { type: String },
  desc: { type: String },
  img: { type: mongoose.Schema.Types.Mixed },
  active: { type: Boolean },

  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

newsSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let news = await NewsModel.findById(id);
  if (!news || news.deleteAt) {
    return null;
  } else {
    return news;
  }
};

const NewsModel = mongoose.model("News", newsSchema);
exports.News = NewsModel;