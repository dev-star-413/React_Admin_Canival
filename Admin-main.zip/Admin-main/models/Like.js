const mongoose = require("mongoose");

const likeSchema = new mongoose.Schema({
  // _id,
  user: { type: mongoose.Schema.Types.Mixed }, //{id: userID, name: user_name}
  isLike: { type: Boolean },
  collName: { type: String }, // reference to collection
  docID: { type: String }, //reference to one document

  confirmedAt: { type: Date },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

likeSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let like = await LikeModel.findById(id);
  if (!like || like.deleteAt) {
    return null;
  } else {
    return like;
  }
};

const LikeModel = mongoose.model("Like", likeSchema);
exports.Like = LikeModel;
