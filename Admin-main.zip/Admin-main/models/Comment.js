const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
  // _id,
  userId: { type: mongoose.Schema.Types.Mixed }, // {id: userID, name: user_name}
  name: { type: String },
  title: { type: String },
  comment: { type: String },
  collName: { type: String }, // reference to collection
  docID: { type: String }, // reference to one document
  imgs: { type: mongoose.Schema.Types.Mixed, default: [], maxlength: 5 },
  score: { type: Object },
  isFeatured: { type: Boolean },
  pId: { type: String },
  confirmedAt: { type: Date },
  createAt: { type: Date, default: new Date() },
  deleteAt: { type: Date },
  avatar:{type:String},
  isOrganizer:{type:Boolean}
});

commentSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let comment = await CommentModel.findById(id);
  if (!comment || comment.deleteAt) {
    return null;
  } else {
    return comment;
  }
};

const CommentModel = mongoose.model("Comment", commentSchema);
exports.Comment = CommentModel;
