const mongoose = require("mongoose");

const eventTempSchema = new mongoose.Schema({
    slug: { type: String },
    dId: { type: String },
    name: { type: String },
    vName: { type: String, trim: true },
    vAddress: { type: String, trim: true },
    pitch: { type: String, trim: true },
    desc: { type: String, trim: true },
    city: { type: mongoose.Schema.Types.Mixed },
    sDate: { type: Date },
    eDate: { type: Date },
    // type: { type: String },
    types: {  type: mongoose.Schema.Types.Mixed, default: [] },
    mGenre: { type: String },
    imgs: { type: mongoose.Schema.Types.Mixed }, // {data,mimetype,orginalname}
    canceled: { type: Boolean, default: false },
    likeC: { type: Number, default: 0 },
    commentC: { type: Number, default: 0 },
    comments: { type: mongoose.Schema.Types.Mixed, default: [] },
    price: { type: Number },
    link: { type: String },
    location: { type: mongoose.Schema.Types.Mixed },
    by: { type: String },
    at: { type: Date, default: new Date() },
    confirmed: { type: Boolean, default: false },
    confirmedDate: { type: Date },
    confirmedBy: { type: String },
    createAt: { type: Date, default: Date.now },
    currency:{type:String}
});

eventTempSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
    let event = await EventTempModel.findById(id);
    if (!event || event.deleteAt) {
        return null;
    } else {
        return event;
    }
};

const EventTempModel = mongoose.model("EventTemp", eventTempSchema);
exports.EventTemp = EventTempModel;
