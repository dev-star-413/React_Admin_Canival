const mongoose = require("mongoose");
const eventSchema = new mongoose.Schema({
  dId: { type: String },
  name: { type: String },
  vName: { type: String, trim: true },
  vAddress: { type: String, trim: true },
  pitch: { type: String, trim: true },
  desc: { type: String, trim: true },
  city: { type: mongoose.Schema.Types.Mixed },
  sDate: { type: Date },
  eDate: { type: Date },
  frequency: { type: String },
  // type: { type: String },
  types: {  type: mongoose.Schema.Types.Mixed, default: [] },
  mGenre: { type: String },
  imgs: { type: mongoose.Schema.Types.Mixed, default: [] },
  canceled: { type: Boolean, default: false },
  likeC: { type: Number, default: 0 },
  commentC: { type: Number, default: 0 },
  comments: { type: mongoose.Schema.Types.Mixed, default: [] },
  price: { type: Number },
  link: { type: String },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  slug: { type: String },
  location: { type: mongoose.Schema.Types.Mixed },  // {lat,lng}
  by: { type: String },
  at: { type: Date, default: new Date() },
  confirmed: { type: Boolean, default: true },
  confirmedDate: { type: Date, default: new Date() },
  confirmedBy: { type: String },
  tags:{type: mongoose.Schema.Types.Mixed }, // [{value,id,coll,slug}]
  currency:{type:String},
  isActive:{type:Boolean,default:false}
});

eventSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let event = await EventModel.findById(id);
  if (!event || event.deleteAt) {
    return null;
  } else {
    return event;
  }
};

const EventModel = mongoose.model("Event", eventSchema);
exports.Event = EventModel;
