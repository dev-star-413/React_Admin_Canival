const mongoose = require("mongoose");

const voteSchema = new mongoose.Schema({
    docID: { type: String },
    docType: { type: String, trim: true },
    subId: { type: String },
    userId: { type: String },
    vote: { type: String },
    rate: { type: Number },
});

const VoteModel = mongoose.model("Vote", voteSchema);
exports.Vote = VoteModel;
