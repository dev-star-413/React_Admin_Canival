const mongoose = require("mongoose");

const adSchema = new mongoose.Schema({
  // _id,
  title: { type: String },
  header: { type: String },
  footer: { type: String },
  imgs: { type: mongoose.Schema.Types.Mixed },
  content: { type: String },
  pages:{type:Array},
  nodes:{type:Array},
  image: { type: mongoose.Schema.Types.Mixed },
  text:{type:String},
  code:{type:String},
  startDate:{type:Date},
  endDate:{type:Date},
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

adSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let ad = await AdModel.findById(id);
  if (!ad || ad.deleteAt) {
    return null;
  } else {
    return ad;
  }
};

const AdModel = mongoose.model("Ad", adSchema);
exports.Ad = AdModel;
