const mongoose = require("mongoose");

const dynamicsSchema = new mongoose.Schema({
    themes: { type: Array, default: [] },
    colors: { type: Array, default: [] },
    premiums: { type: Array, default: [] },
    categories: { type: Array, default: [] },
    services: { type: Array, default: [] }, // costume services
    jouvertServices: { type: Array, default: [] }, // costume services
    childrenServices: { type: Array, default: [] }, // children services
    addOns: { type: Array, default: [] },
    standards: { type: Array, default: [] },
    revellers: { type: Array, default: [] },
    styles: { type: Array, default: [] },
    awardTypes: { type: Array, default: [] },
    festivalTypes: { type: Array, default: [] },
    faqCategories: { type: Array, default: [] },
    catTags: { type: Array, default: [] },
    regions: { type: Array, default: [] },
    bandDateDetails:{type:String}
});

const DynamicsModel = mongoose.model("Dynamics", dynamicsSchema);
exports.Dynamics = DynamicsModel;
