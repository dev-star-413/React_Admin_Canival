const mongoose = require("mongoose");

const citySchema = new mongoose.Schema({
  // _id,
  name: { type: String, trim: true },
  code: { type: String, trim: true },
  country: { type: String, trim: true },
  region: { type: String, trim: true },
  state: { type: String, trim: true },
  tz: { type: Number },
  currencyCode: {type: String },
  slug: { type: String, trim: true },
  currency: { type: String, trim: true }, // currency country
  latlng: { type: Object },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date }
});

citySchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let city = await CityModel.findById(id);
  if (!city || city.deleteAt) {
    return null;
  } else {
    return city;
  }
};

const CityModel = mongoose.model("City", citySchema);
exports.City = CityModel;
