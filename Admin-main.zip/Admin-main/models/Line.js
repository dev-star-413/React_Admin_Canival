const mongoose = require("mongoose");
const imgSchema = new mongoose.Schema({
  name: String,
  path: String,
  mime: String,
  text: String,
  localPrice: Number,
  price: Number,
  isAddOn: Boolean,
  includes: String,
});
const lineSchema = new mongoose.Schema({
  sId: { type: String },
  type: { type: String, trim: true },
  desc: { type: String, trim: true },
  styles: { type: mongoose.Schema.Types.Mixed, default: [] },
  link: { type: String, trim: true },
  img: { type: imgSchema },
  gallery: { type: [imgSchema] },
});

const LineModel = mongoose.model("Line", lineSchema);
exports.Line = LineModel;
