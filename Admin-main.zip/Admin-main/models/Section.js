const mongoose = require("mongoose");
const file = require("../services/file");

const sectionSchema = new mongoose.Schema({
    bdId: { type: String },
    name: { type: String, trim: true },
    slug: { type: String },
    types: { type: Array, default: [] },
    lDate: { type: Date },
    rdDate: { type: Date },
    deposit: { type: Number },
    desc: { type: String, trim: true },
    designers: { type: mongoose.Schema.Types.Mixed, default: [] },
    colors: { type: mongoose.Schema.Types.Mixed },
    premiums: { type: mongoose.Schema.Types.Mixed },
    soldBy: { type: Object },
    price: { type: Number },
    sold: { type: Number, default: 0 },
    standard: { type: String },
    reviews: { type: mongoose.Schema.Types.Mixed, default: [] },
    average: { type: Number, default: 0 },
    count: { type: Number, default: 0 },
    img: { type: mongoose.Schema.Types.Mixed },
    createAt: { type: Date, default: Date.now },
    deleteAt: { type: Date },
    dCurrency:{type:String}, // deposit currency
    // pCurrency:{type:String}, // price deposit todo: to be deleted
    localPrice:{ type: Number },
    pricingText:{type:String}, // pricing text

})

sectionSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
    let section = await SectionModel.findById(id);
    if (!section || section.deleteAt) {
        return null;
    } else {
        return section;
    }
}

sectionSchema.statics.deleteSectionAndFiles = async function ({ id }) {
    let section = await SectionModel.findById(id)
    if (section) {
        for (let img of section.imgs) {
            await file.delete(img.path)
        }
        for (let addOn of section.addOns) {
            await file.delete(addOn.img.path)
        }
        await SectionModel.deleteOne({ _id: id })
        return true
    }
    return false
}

const SectionModel = mongoose.model("Section", sectionSchema);
exports.Section = SectionModel;
