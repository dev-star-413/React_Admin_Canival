const mongoose = require("mongoose");

const festivalYearSchema = new mongoose.Schema({
  festival: { type: mongoose.Schema.Types.Mixed }, //{id, name, slug}
  year: { type: Number },
  tsk: { type: String }, // travelers should know
  city: { type: mongoose.Schema.Types.Mixed }, //{id, name, region}
  likeC: { type: Number }, // like count
  commentC: { type: Number }, // comment count
  comments: { type: mongoose.Schema.Types.Mixed }, // last 10 comments

  createAt: { type: Date, default: Date.now },
});

const FestivalYearModel = mongoose.model("FestivalYear", festivalYearSchema);
exports.FestivalYear = FestivalYearModel;
