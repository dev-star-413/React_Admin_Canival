const mongoose = require("mongoose");

const faqSchema = new mongoose.Schema({
  // _id,
  q: { type: String },
  a: { type: String },
  cat: { type: String },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

faqSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let faq = await FaqModel.findById(id);
  if (!faq || faq.deleteAt) {
    return null;
  } else {
    return faq;
  }
};

const FaqModel = mongoose.model("Faq", faqSchema);
exports.Faq = FaqModel;
