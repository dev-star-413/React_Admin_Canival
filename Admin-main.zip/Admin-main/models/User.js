const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema({
  // _id,
  username: { type: String },
  password: { type: String },
  role: { type: String },
  name: { type: String },
  tz: { type: String },
  uName: { type: String },
  dName: { type: String },
  insta: { type: String },
  tz: { type: String },
  email: { type: String },
  pic: { type: String },
  bDate: { type: Date },
  desc: { type: String },

  web: { type: String },
  twitter: { type: String },
  facebook: { type: String },  
  otherSocial: { type: String },
  
  countries: { type: Array, default: [] },
  organizeBand: { type: Object },//{_id, name, isVerify} 
  img: { type: Object },// {name, path , mime}
  
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

userSchema.statics.findAndValidatePass = async function ({ username, password }) {
  let user = await UserModel.findOne({ username });
  if (!user) return null;
  let passwordIsCorrect = bcrypt.compareSync(password, user.password);
  if (passwordIsCorrect) return user;
  return null;
};

userSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let user = await UserModel.findById(id);
  if (!user || user.deleteAt) {
    return null;
  } else {
    return user;
  }
};

const UserModel = mongoose.model("User", userSchema);
exports.User = UserModel;
