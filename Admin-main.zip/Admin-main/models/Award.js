const mongoose = require("mongoose");

const awardSchema = new mongoose.Schema({
  // _id,
  name: { type: String },
  keywords: { type: String },
  date: { type: Date },
  desc: { type: String },
  cats: { type: mongoose.Schema.Types.Mixed, default: [] },
  canceled: { type: Boolean },
  cReason: { type: String },
  city: { type: mongoose.Schema.Types.Mixed },
  fId: { type: String }, // festival Id
  dId: { type: String }, // festival year ID
  keywords: { type: String },
  slug: { type: String, unique: true },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

awardSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let award = await AwardModel.findById(id);
  if (!award || award.deleteAt) {
    return null;
  } else {
    return award;
  }
};

const AwardModel = mongoose.model("Award", awardSchema);
exports.Award = AwardModel;
