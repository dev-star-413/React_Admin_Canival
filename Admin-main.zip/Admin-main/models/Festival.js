const mongoose = require("mongoose");

const festivalSchema = new mongoose.Schema({
  name: { type: String },
  oName: { type: String },
  desc: { type: String },
  history: { type: String },
  social: { type: mongoose.Schema.Types.Mixed },
  type: { type: String },
  active: { type: Boolean },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  meta:{type:String},
  heading:{type:String},
  keyWord:{type:String},
  introText: { type: String },
  city: { type: String },
  price: { type: String },
  theme: { type: String },
  jouvertAddress: { type: String },
  slug: {type: String},
  costume:{type:String},
  event:{type:String},
  result:{type:String},
  review:{type:String},
  guide:{type:String}, // travel should know
  paradeDesc:{type:String},
  whereToStay:{type:String},
  mainImage: { type: mongoose.Schema.Types.Mixed },
  evenImage: { type: mongoose.Schema.Types.Mixed },
  paradeImage: { type: mongoose.Schema.Types.Mixed },
  jouvertImage: { type: mongoose.Schema.Types.Mixed },
  jouvert:{type:String},
  lPage:{type: Boolean},//landing page 
  onTop:{type: Boolean}, // on Top 
  paradeLocation:{type:String},
  // children
  childrenImage:{type:mongoose.Schema.Types.Mixed },
  childrenParadeAddress:{type:String},
  childrenDesc:{type:String},



});

festivalSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let festival = await FestivalModel.findById(id);
  if (!festival || festival.deleteAt) {
    return null;
  } else {
    return festival;
  }
};

const FestivalModel = mongoose.model("Festival", festivalSchema);
exports.Festival = FestivalModel;
