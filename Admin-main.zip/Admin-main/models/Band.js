const mongoose = require("mongoose");

const bandSchema = new mongoose.Schema({
  // _id,
  name: { type: String },
  foundY: { type: String },
  uID: { type: String },
  fNames: { type: mongoose.Schema.Types.Mixed }, //former names
  partners: { type: mongoose.Schema.Types.Mixed },
  unique: { type: String },
  about: { type: String },
  users: { type: mongoose.Schema.Types.Mixed },
  slug: { type: String },
  likeC: { type: Number }, // like count
  commentC: { type: Number }, // comment count
  comments: { type: mongoose.Schema.Types.Mixed }, // last 10 comments
  lastYear:{type:String}, // last year of band-date
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  img: { type: Object },
  festivals: { type: mongoose.Schema.Types.Mixed },
  contactPhone:{ type:String },
  contactEmail:{type:String}
});

bandSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let band = await BandModel.findById(id);
  if (!band || band.deleteAt) {
    return null;
  } else {
    return band;
  }
};

const BandModel = mongoose.model("Band", bandSchema);
exports.Band = BandModel;
