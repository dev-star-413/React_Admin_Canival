const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const adminSchema = new mongoose.Schema({
  // _id,
  username: { type: String },
  password: { type: String },
  role: { type: String },
  name: { type: String },
  createAt: { type: Date, default: Date.now },
});

adminSchema.statics.findAndValidatePass = async function ({ username, password }) {
  let user = await AdminModel.findOne({ username });
  if (!user) return null;
  let passwordIsCorrect = bcrypt.compareSync(password, user.password);
  if (passwordIsCorrect) return user;
  return null;
};

const AdminModel = mongoose.model("Admin", adminSchema);
exports.Admin = AdminModel;
