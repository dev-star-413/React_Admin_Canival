const mongoose = require("mongoose");

const migrateSchema = new mongoose.Schema({
  funcName: { type: String },
  resCode: { type: Number },
  createAt: { type: Date, default: Date.now },
});

const MigrateModel = mongoose.model("Migrate", migrateSchema);
exports.Migrate = MigrateModel;
