const mongoose = require("mongoose");

const roleSchema = new mongoose.Schema({
  // _id,
  name: { type: String },
  access: { type: mongoose.Schema.Types.Mixed },

  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

roleSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let role = await RoleModel.findById(id);
  if (!role || role.deleteAt) {
    return null;
  } else {
    return role;
  }
};

const RoleModel = mongoose.model("Role", roleSchema);
exports.Role = RoleModel;
