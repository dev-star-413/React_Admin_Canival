const mongoose = require("mongoose");

const bandTempSchema = new mongoose.Schema({
    bandId: { type: String },
    name: { type: String },
    dateId: { type: String },
    dateName: { type: String },
    year: { type: Number },
    themeType: { type: String },
    theme: { type: String },
    lDate: { type: Date },
    rdDate: { type: String },
    video: { type: Object },
    imgs: { type: mongoose.Schema.Types.Mixed },
    deposit: { type: Number },
    desc: { type: String },
    sectionOptions: { type: String },
    reveller: { type: String },
    locals: { type: Number },
    slug: { type: String },
    agree: { type: Array, default: [] },
    resultText: { type: String },
    disagree: { type: Array, default: [] },
    notsure: { type: Array, default: [] },
    likeC: { type: Number }, // like count
    commentC: { type: Number }, // comment count
    comments: { type: mongoose.Schema.Types.Mixed }, // last 10 comments
    hot: { type: Number },
    scores: { type: mongoose.Schema.Types.Mixed, default: [] },
    score: { type: Number, default: 0 },
    reviews: { type: mongoose.Schema.Types.Mixed },
    services: { type: Array, default: [] },
    sections: { type: Number, default: 0 },
    createAt: { type: Date, default: Date.now },
    deleteAt: { type: Date },
    by: { type: String },
    at: { type: Date, default: new Date() },
    confirmed: { type: Boolean, default: false },
    confirmedBy: { type: String },
    confirmedAt: { type: Date },
});

bandTempSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
    let band = await BandTempModel.findById(id);
    if (!band || band.deleteAt) {
        return null;
    } else {
        return band;
    }
};

const BandTempModel = mongoose.model("BandTemp", bandTempSchema);
exports.BandTemp = BandTempModel;
