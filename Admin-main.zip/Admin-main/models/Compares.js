const mongoose = require("mongoose");

const comparesSchema = new mongoose.Schema({
  dateIdA:{type:String},
  bandDateIdA:{type:String},
  sectionIdA:{type:String},
  dateIdB:{type:String},
  bandDateIdB:{type:String},
  sectionIdB:{type:String},
  inLanding:{type:Boolean,default:false}, 
  inCarnivalPage:{type:Boolean,default:false}, 
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date }
});
const ComparesModel = mongoose.model("Compares", comparesSchema);
exports.Compares = ComparesModel;