const mongoose = require("mongoose");

const designerSchema = new mongoose.Schema({
  // _id,
  name: { type: String },
  carnivals: { type: mongoose.Schema.Types.Mixed },
  city: { type: String },
  band: { type: mongoose.Schema.Types.Mixed },
  img: { type: Object },
  about: { type: String },
  slug: { type: String },
  coName: String,
  lastYear: Number,

  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
});

designerSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let designer = await DesignerModel.findById(id);
  if (!designer || designer.deleteAt) {
    return null;
  } else {
    return designer;
  }
};

const DesignerModel = mongoose.model("Designer", designerSchema);
exports.Designer = DesignerModel;
