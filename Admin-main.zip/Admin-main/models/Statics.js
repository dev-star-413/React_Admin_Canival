const mongoose = require("mongoose");

const staticsSchema = new mongoose.Schema({
    slug: { type: String },
    title: { type: String },
    content: { type: String },
    client: { type: Boolean, default: false },
    removable: { type: Boolean },
    createAt: { type: Date, default: Date.now }
});

const StaticsModel = mongoose.model("Statics", staticsSchema);
exports.Statics = StaticsModel;
