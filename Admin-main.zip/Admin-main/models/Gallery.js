const mongoose = require("mongoose");

const img=new mongoose.Schema({
  name:String,
  path:String,
  mime:String,
  text:String,
})
const gallerySchema = new mongoose.Schema({
  // _id,
  title: { type: String },
  // link: { type: String },
  desc: { type: String },
  imgs: { type: [img] },
  active: { type: Boolean },
  dateId:{type:String},
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  bands: { type: mongoose.Schema.Types.Mixed }
});


gallerySchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let gallery = await galleryModel.findById(id);
  if (!gallery || gallery.deleteAt) {
    return null;
  } else {
    return gallery;
  }
};

const galleryModel = mongoose.model("Gallery", gallerySchema);
exports.Gallery = galleryModel;