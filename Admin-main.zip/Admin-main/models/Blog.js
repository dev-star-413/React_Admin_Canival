const mongoose = require("mongoose");

const blogSchema = new mongoose.Schema({
  // _id,
  title: { type: String },
  author: { type: String },
  pDate: { type: Date },
  cats: { type: mongoose.Schema.Types.Mixed },
  meta: { type: String },
  desc: { type: String }, // content
  img: { type: Object },
  imgt: { type: String },
  keys: { type: Array, default: [] },
  cities: { type: mongoose.Schema.Types.Mixed },
  festivals: { type: mongoose.Schema.Types.Mixed },
  bands: { type: mongoose.Schema.Types.Mixed },
  designers: { type: mongoose.Schema.Types.Mixed },
  artists: { type: mongoose.Schema.Types.Mixed },
  slug: { type: String },
  likeC: { type: Number, default: 0 }, // like count
  commentC: { type: Number, default: 0 }, // comment count
  comments: { type: mongoose.Schema.Types.Mixed, default: [] }, // last 10 comments
  isTop: {type: Boolean},
  isFeature: {type: Boolean},
  isMain: {type: Boolean},
  rLink: { type: String },
  createAt: { type: Date, default: Date.now },
  deleteAt: { type: Date },
  view: { type: Number, default: 0 },
});

blogSchema.statics.findByIdAndDeleteAt = async function ({ id }) {
  let blog = await BlogModel.findById(id);
  if (!blog || blog.deleteAt) {
    return null;
  } else {
    return blog;
  }
};

const BlogModel = mongoose.model("Blog", blogSchema);
exports.Blog = BlogModel;
