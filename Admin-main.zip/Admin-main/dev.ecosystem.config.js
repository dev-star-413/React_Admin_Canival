module.exports = {
  apps: [
    {
      name: "dev-admin",
      namespace: "dev",
      script: "./bin/www.js",
      watch: ["app.js"],
      env: {
        NODE_ENV: "development",
      },
    },
  ],
};
