const express = require("express");
const { join } = require("path");
const expressSession = require("express-session");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const redis = require("redis");

const config = require("./config")();
const routes = require("./routes");
const file = require("./services/file");
const initDatabase = require("./services/initDatabase");

const app = express();

mongoose
  .connect(config.db.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  })
  .catch((err) => {
    throw err;
  });

var RedisStore = require("connect-redis")(expressSession);
var redisClient = redis.createClient({
  host: config.redis.host,
  port: config.redis.port,
});
app.use(
  expressSession({
    store: new RedisStore({ client: redisClient }),
    secret: config.session.secret,
    resave: false,
    saveUninitialized: false,
    cookie: { secure: config.session.secure, maxAge: 3 * 60 * 60 * 1000 },
  })
);
// view engine setup
app.set("views", join(__dirname, "views"));
app.set("view engine", "ejs");
app.set("layoutFile", "layout.ejs");

app.use(express.json());
app.use(bodyParser.urlencoded({ limit: "256mb", extended: true }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(join(__dirname, "public")));
app.use(bodyParser.json({ limit: "256mb" }));

app.use(function (req, res, next) {
  res.view = function (path, obj) {
    let layoutFile = app.get("layoutFile");
    if (obj && typeof obj._layoutFile !== "undefined") {
      layoutFile = obj._layoutFile;
    }
    path = join(app.get("views"), path);
    if (layoutFile) {
      return res.render(layoutFile, { _bodyFile: path, ...obj, admin: req.admin || null }); // send admin for use in layout
    } else {
      return res.render(path, { ...obj });
    }
  };
  next();
});

const sharp = require("sharp");
app.use("/admin/images/:foldername/:width/:height/:strategy/:filename", async function (req, res, next) {
  try {
    const { foldername, width, height, strategy, filename } = req.params;

    if (strategy == "c") {
      //main image
      let resizeObj = {
        fit: sharp.fit.contain,
        background: { r: 0, g: 0, b: 0, alpha: 0 },
      };
      if (width && width !== "0") {
        resizeObj.width = Number(width) - 2;
      }
      if (height && height !== "0") {
        resizeObj.height = Number(height) - 2;
      }
      if (!(await file.isFileExists(`public/images/${foldername}/${filename}`))) {
        return res.sendStatus(404);
      }
      const buffer = await sharp(`public/images/${foldername}/${filename}`)
        .toFormat("png")
        .resize(resizeObj)
        .toBuffer();

      //background
      let resizeObj2 = {
        fit: sharp.fit.cover,
      };
      if (width && width !== "0") {
        resizeObj2.width = Number(width);
      }
      if (height && height !== "0") {
        resizeObj2.height = Number(height);
      }
      const buffer2 = await sharp(`public/images/${foldername}/${filename}`)
        .resize(resizeObj2)
        .blur(10)
        .composite([
          {
            input: buffer, // Pass in the buffer data to the composite function
          },
        ])
        .webp()
        .toBuffer();

      res.writeHead(200, [["Content-Type", "image/webp"]]);
      res.end(buffer2);
    } else {
      let resizeObj = {
        fit: sharp.fit.cover,
        position: strategy === "a" ? sharp.strategy.attention : sharp.strategy.entropy,
      };
      if (width && width !== "0") {
        resizeObj.width = Number(width);
      }
      if (height && height !== "0") {
        resizeObj.height = Number(height);
      }
      const buffer = await sharp(`public/images/${foldername}/${filename}`).resize(resizeObj).webp().toBuffer();

      res.writeHead(200, [["Content-Type", "image/webp"]]);
      res.end(buffer);
    }
  } catch (err) {
    console.log(err);
    return res.writeHead(500).end();
  }
});

app.get("/", function (req, res, next) {
  return res.redirect("/admin");
});
app.use("/admin", routes);

// error handler
app.use(function (req, res, next) {
  return res.status(404).view("404", { _layoutFile: false });
});

app.use(function (err, req, res, next) {
  console.error(err);
  res.locals.err = process.env.NODE_ENV === "development" ? err : null;
  return res.status(500).view("500", { _layoutFile: false });
});

file.createRequireDirs();

initDatabase();

module.exports = app;
