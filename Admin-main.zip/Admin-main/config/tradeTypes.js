module.exports = [
  { name: "Ticket" },
  { name: "Accommodation" },
  { name: "Transportation" },
  { name: "Food" },
  { name: "Hair/Makeup" },
  { name: "Costume" },
  { name: "Other" },
]