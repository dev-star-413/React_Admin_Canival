module.exports = [
  { name: "Costumes" },
  { name: "Event" },
  { name: "Guides" },
  { name: "Reviews" },
  { name: "News" },
  { name: "Things to Do" },
  { name: "Food/Drinks" },
  { name: "First Timers" },
  { name: "Fanatics" },
]