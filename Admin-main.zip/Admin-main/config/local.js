require("dotenv").config();
const domain = "";
const rootToWrite = "";

module.exports = {
  db: {
    url: "mongodb://localhost/festivals-local",
  },
  session: {
    secret: process.env.SESSION_SECRET || "secret",
    secure: false,
  },
  redis: {
    host: "127.0.0.1",
    port: 6379,
  },
  adminUser: {
    username: "admin",
    password: process.env.ADMIN_PASS || "12345-6",
  },
  uploads: {
    read: {
      defaultImages: `${domain}/images/defaults`,
      designerImages: `${domain}/images/designers`,
      dateImages: `${domain}/images/dates`,
      eventImages: `${domain}/images/events`,
      newsImages: `${domain}/images/news`,
      slideImages: `${domain}/images/slides`,
      galleryImages: `${domain}/images/gallery`,
      tradeImages: `${domain}/images/trades`,
      blogImages: `${domain}/images/blogs`,
      awardCatImages: `${domain}/images/awardCats`,
      adsImages: `${domain}/images/ads`,
      addOnsImages: `${domain}/images/addOns`,
      sectionImages: `${domain}/images/sections`,
      lineImages: `${domain}/images/lines`,
      festivalImages: `${domain}/images/festivals`,
      bandImages: `${domain}/images/bands`,
      videos: `${domain}/videos`,
      other:`${domain}/other`
    },
    write: {
      defaultImages: `${rootToWrite}/images/defaults`,
      designerImages: `${rootToWrite}/images/designers`,
      dateImages: `${rootToWrite}/images/dates`,
      eventImages: `${rootToWrite}/images/events`,
      newsImages: `${rootToWrite}/images/news`,
      slideImages: `${rootToWrite}/images/slides`,
      galleryImages: `${rootToWrite}/images/gallery`,
      tradeImages: `${rootToWrite}/images/trades`,
      blogImages: `${rootToWrite}/images/blogs`,
      awardCatImages: `${rootToWrite}/images/awardCats`,
      adsImages: `${rootToWrite}/images/ads`,
      addOnsImages: `${rootToWrite}/images/addOns`,
      sectionImages: `${rootToWrite}/images/sections`,
      lineImages: `${rootToWrite}/images/lines`,
      festivalImages: `${rootToWrite}/images/festivals`,
      bandImages: `${rootToWrite}/images/bands`,
      videos: `${rootToWrite}/videos`,
      other:`${rootToWrite}/other`
    },
  },
  port: 3000,
  froalaKey: "RGI4oB7D6D6A3B3B3fH-7ynjvvg1npH3ugucjcD-8ueaA-16dxC-11tB1vyzdD5B4A4D3H3I3F3B7A4A2==",
  bandDateScores: [
    { method: "design", title: "Design" },
    { method: "food", title: "Food, Drinks" },
    { method: "entertainment", title: "Entertainment" },
    { method: "service", title: "Customer Service" },
  ],
  sectionTypes: ["Adult Costume",`Children/Junior`, `Jouvert`, "Day || Wear", "Others"],
  // url project image
  imgUrl:"http://localhost:4003/images/other/0/0/c/",
  // option for froala manage image 
  froalaOptions : {
    placeholderText: 'Type page content here...',
    key:"RGI4oB7D6D6A3B3B3fH-7ynjvvg1npH3ugucjcD-8ueaA-16dxC-11tB1vyzdD5B4A4D3H3I3F3B7A4A2==",
    imageUploadURL:"/admin/froala/upload",
    imageManagerDeleteURL:"/admin/froala/remove",
    imageUploadMethod:"POST",
    imageMaxSize:15 * 1024 * 1024,
    imageManagerLoadURL:"/admin/froala",
    imageManagerPageSize: 10,
    wordAllowedStyleProps:['font-family', 'font-size', 'background', 'color', 'width', 'text-align', 'vertical-align', 'background-color', 'padding', 'margin', 'height', 'margin-top', 'margin-left', 'margin-right', 'margin-bottom', 'text-decoration', 'font-weight', 'font-style', 'text-indent', 'border', 'border-.*'],
    imageAddNewLine:true

  },
  apiKeyCurrency:'a3cf9654a0bb3e921ce3', //https://free.currconv.com
  accessControl:[
    // "SUPER_ADMIN", //ACCESS ALL + USER & ROLE
    "ADVERTISMENT_ADD","ADVERTISMENT_EDIT","ADVERTISMENT_DELETE","ADVERTISMENT_INDEX",
    "AWARD_ADD","AWARD_EDIT","AWARD_DELETE","AWARD_INDEX",
    "BAND_DATE_ADD","BAND_DATE_EDIT","BAND_DATE_DELETE","BAND_DATE_INDEX",
    "BAND_ADD","BAND_EDIT","BAND_DELETE","BAND_INDEX",
    "BAND_TEMP_ADD","BAND_TEMP_EDIT","BAND_TEMP_DELETE","BAND_TEMP_INDEX",
    "BLOG_ADD","BLOG_EDIT","BLOG_DELETE","BLOG_INDEX",
    "CITY_ADD","CITY_EDIT","CITY_DELETE","CITY_INDEX",
    "COMMENT_SET_CONFIRM","COMMENT_SET_FEATURE","COMMENT_INDEX",
    "COMPARE_ADD","COMPARE_EDIT","COMPARE_DELETE","COMPARE_INDEX",
    "DESIGNER_ADD","DESIGNER_EDIT","DESIGNER_DELETE","DESIGNER_INDEX",
    "DYNAMIC_INDEX",
    "EVENT_ADD","EVENT_EDIT","EVENT_DELETE","EVENT_INDEX",
    "EVENT_TEMP_ADD","EVENT_TEMP_EDIT","EVENT_TEMP_DELETE","EVENT_TEMP_INDEX",
    "FAQ_ADD","FAQ_EDIT","FAQ_DELETE","FAQ_INDEX",
    "FESTIVAL_DATE_ADD","FESTIVAL_DATE_EDIT","FESTIVAL_DATE_DELETE","FESTIVAL_DATE_INDEX",
    "FESTIVAL_ADD","FESTIVAL_EDIT","FESTIVAL_DELETE","FESTIVAL_INDEX",
    "GALLERY_ADD","GALLERY_EDIT","GALLERY_DELETE","GALLERY_INDEX",
    "NEWS_ADD","NEWS_EDIT","NEWS_DELETE","NEWS_INDEX",
    "STATIC_ADD","STATIC_EDIT","STATIC_DELETE","STATIC_INDEX",
    "TRADE_ADD","TRADE_EDIT","TRADE_DELETE","TRADE_INDEX",
    "USER_INDEX","USER_VERIFY_ORGANIZER","USER_REMOVE_ORGANIZER",
  ]
};
