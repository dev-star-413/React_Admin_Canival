module.exports = () => {
  if (process.env.NODE_ENV === "development") {
    return require("./dev");
  } else if (process.env.NODE_ENV === "production") {
    return require("./prod");
  }
  return null;
};
